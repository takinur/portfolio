<template>
    <Head title="Takinur -PHP Web Developer" />

    <div class="wrapper">
        <!-- header -->
        <header
            class="header py-4 h-16 md:sticky md:top-0 md:z-50 bg-gray-200 opacity-100 dark:bg-slate-800"
        >
            <!-- container -->
            <div class="container px-4 sm:px-8 lg:px-16 xl:px-20 mx-auto">
                <!-- header wrapper -->
                <div class="header-wrapper flex items-center justify-between">
                    <!-- header logo -->
                    <div class="header-logo w-12">
                        <a href="/">
                            <img
                                v-bind:src="'/images/' + 'LOGO_T_256.png'"
                                alt="Logo of Takinur"
                                class="bg-cover"
                            />
                        </a>
                    </div>
                    <!-- mobile toggle -->
                    <div class="toggle md:hidden">
                        <button @click="toggleNav">
                            <svg
                                class="h-6 w-6 fill-current text-black dark:text-white"
                                fill="none"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                            >
                                <path d="M4 6h16M4 12h16M4 18h16"></path>
                            </svg>
                        </button>
                    </div>
                    <!-- Navbar -->
                    <nav class="navbar hidden md:block">
                        <ul class="flex space-x-8 text-sm font-semibold">
                            <li>
                                <!-- Toggle Dark -->
                                <div
                                    v-if="!isMobile()"
                                    class="flex items-center justify-center w-full"
                                >
                                    <label
                                        for="toggleDark"
                                        class="flex items-center cursor-pointer"
                                    >
                                        <span class="mr-2">
                                            <svg
                                                class="h-6 w-6 text-yellow-600 dark:text-white"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                stroke="currentColor"
                                            >
                                                <path
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                    stroke-width="2"
                                                    d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"
                                                />
                                            </svg>
                                        </span>
                                        <!-- toggle -->
                                        <div class="relative">
                                            <!-- input -->
                                            <input
                                                type="checkbox"
                                                id="toggleDark"
                                                class="sr-only"
                                            />
                                            <!-- line -->
                                            <div
                                                class="block bg-gray-700 w-16 h-7 rounded-full"
                                            ></div>
                                            <!-- dot -->
                                            <div
                                                class="dot absolute left-1 top-1 bg-white w-5 h-5 rounded-full transition"
                                            ></div>
                                        </div>
                                        <span class="ml-2">
                                            <svg
                                                class="h-6 w-6 text-gray-500 dark:text-cyan-400"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                stroke="currentColor"
                                            >
                                                <path
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                    stroke-width="2"
                                                    d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
                                                />
                                            </svg>
                                        </span>
                                    </label>
                                    <!-- label -->
                                </div>
                            </li>
                            <li>
                                <button
                                    @click="sayHello"
                                    class="-mt-1 py-2 px-6 text-[#7510F7] dark:text-white rounded-full border-2 border-[#7510F7] shadow-lg block hover:text-white md:inline-block hover:bg-[#7510F7]"
                                >
                                    Say Hello
                                </button>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </header>
        <!-- end header -->
        <!-- hero -->
        <div class="hero bg-gray-200 pb-24 pt-28 h-screen dark:bg-slate-800">
            <!-- container -->
            <div class="container px-4 sm:px-8 lg:px-16 xl:px-20 mx-auto">
                <!-- hero wrapper -->
                <div
                    class="hero-wrapper grid grid-cols-1 md:grid-cols-12 gap-8 items-center"
                >
                    <!-- hero text -->
                    <div class="hero-text col-span-6">
                        <h1
                            data-aos="zoom-in-left"
                            data-aos-once="false"
                            data-aos-delay="50"
                            data-aos-duration="600"
                            data-aos-easing="ease-in-out"
                            class="font-bold uppercase text-4xl md:text-5xl max-w-xl text-gray-900 leading-tight dark:text-gray-300"
                        >
                            Full-Stack PHP Web Developer
                        </h1>
                        <hr
                            class="w-12 h-1 bg-gray-500 rounded-full mt-8 dark:bg-white"
                        />
                        <p
                            data-aos="zoom-out-up"
                            class="text-gray-800 text-base leading-relaxed mt-8 font-semibold dark:text-gray-100"
                        >
                            I develop Modern, Responsive and SEO Friendly
                            Websites with clean code, and I love what I do.
                        </p>
                    </div>

                    <!-- hero image -->
                    <div
                        class="hero-image col-span-6"
                        data-aos="fade-down-left"
                    >
                        <img
                            v-bind:src="'/images/' + 'hero.svg'"
                            alt=""
                            class="bg-cover"
                        />
                    </div>
                </div>
            </div>
        </div>
        <!-- end hero -->
        <!-- mobile navbar -->
        <div class="mobile-navbar">
            <transition name="slide-fade">
                <!-- navbar wrapper -->
                <div
                    class="navbar-wrapper fixed md:hidden top-0 left-0 h-full bg-white z-30 w-64 shadow-lg p-5"
                    v-show="showNav"
                >
                    <div class="close">
                        <button
                            class="absolute top-0 right-0 mt-4 mr-4"
                            @click="toggleNav"
                        >
                            <svg
                                class="w-6 h-6"
                                fill="none"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                            >
                                <path d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                    <ul class="divide-y">
                        <li>
                            <button
                                @click="sayHello"
                                class="-mt-2 py-1 px-6 text-[#7510F7] rounded-full border-2 border-[#7510F7] shadow-lg block hover:text-white md:inline-block hover:bg-[#7510F7]"
                            >
                                Say Hello
                            </button>
                            <a
                                href="#intro"
                                class="my-4 inline-block active font-bold mt-8"
                                >Introduction</a
                            >
                        </li>
                        <li>
                            <a
                                href="#projects"
                                class="my-4 inline-block hover:text-orange-500"
                                >Porfolio</a
                            >
                        </li>
                        <li>
                            <a
                                href="#frameworks"
                                class="my-4 inline-block hover:text-orange-500"
                                >Frameworks</a
                            >
                        </li>
                        <li>
                            <a
                                href="#tools"
                                class="my-4 inline-block hover:text-orange-500"
                                >Tools</a
                            >
                        </li>
                        <li>
                            <a
                                href="#other"
                                class="my-4 inline-block hover:text-orange-500"
                                >Other</a
                            >
                        </li>
                        <li>
                            <!-- Toggle Dark -->
                            <div
                                class="flex items-center justify-center w-full mt-4"
                            >
                                <label
                                    for="toggleDark"
                                    class="flex items-center cursor-pointer"
                                >
                                    <span class="mr-2">
                                        <svg
                                            class="h-6 w-6 text-yellow-600 dark:text-gray-400"
                                            fill="none"
                                            viewBox="0 0 24 24"
                                            stroke="currentColor"
                                        >
                                            <path
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                                stroke-width="2"
                                                d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"
                                            />
                                        </svg>
                                    </span>
                                    <!-- toggle -->
                                    <div class="relative">
                                        <!-- input -->
                                        <input
                                            type="checkbox"
                                            id="toggleDark"
                                            class="sr-only"
                                        />
                                        <!-- line -->
                                        <div
                                            class="block bg-gray-700 w-16 h-7 rounded-full"
                                        ></div>
                                        <!-- dot -->
                                        <div
                                            id="mobileDot"
                                            class="dot absolute left-1 top-1 bg-white w-5 h-5 rounded-full transition"
                                        ></div>
                                    </div>
                                    <span class="ml-2">
                                        <svg
                                            class="h-6 w-6 text-gray-500 dark:text-cyan-400"
                                            fill="none"
                                            viewBox="0 0 24 24"
                                            stroke="currentColor"
                                        >
                                            <path
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                                stroke-width="2"
                                                d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
                                            />
                                        </svg>
                                    </span>
                                </label>
                                <!-- label -->
                            </div>
                        </li>
                    </ul>

                    <!-- follow us -->
                    <!-- <div class="follow">
                        <p class="italic font-semibold">follow us:</p>
                        <div class="social flex space-x-5 mt-4">
                            <a href="#">
                                <svg
                                    aria-hidden="true"
                                    focusable="false"
                                    data-prefix="fab"
                                    data-icon="twitter"
                                    class="h-5 w-5 fill-current text-gray-600"
                                    role="img"
                                    xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 512 512"
                                >
                                    <path
                                        fill="currentColor"
                                        d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"
                                    ></path>
                                </svg>
                            </a>
                            <a href="#">
                                <svg
                                    aria-hidden="true"
                                    focusable="false"
                                    data-prefix="fab"
                                    data-icon="facebook-f"
                                    class="h-5 w-5 fill-current text-gray-600"
                                    role="img"
                                    xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 320 512"
                                >
                                    <path
                                        fill="currentColor"
                                        d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"
                                    ></path>
                                </svg>
                            </a>
                            <a href="#">
                                <svg
                                    aria-hidden="true"
                                    focusable="false"
                                    data-prefix="fab"
                                    data-icon="instagram"
                                    class="h-5 w-5 fill-current text-gray-600"
                                    role="img"
                                    xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 448 512"
                                >
                                    <path
                                        fill="currentColor"
                                        d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"
                                    ></path>
                                </svg>
                            </a>
                            <a href="#">
                                <svg
                                    aria-hidden="true"
                                    focusable="false"
                                    data-prefix="fab"
                                    data-icon="youtube"
                                    class="h-5 w-5 fill-current text-gray-600"
                                    role="img"
                                    xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 576 512"
                                >
                                    <path
                                        fill="currentColor"
                                        d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"
                                    ></path>
                                </svg>
                            </a>
                        </div>
                    </div> -->
                </div>
            </transition>
        </div>
        <section id="intro">
            <!-- hero -->
            <div
                class="hero bg-[#7510F7] py-16 h-[700px] md:h-[500px] dark:bg-gray-900"
            >
                <!-- container -->
                <div class="container px-4 sm:px-8 lg:px-16 xl:px-20 mx-auto">
                    <!-- hero wrapper -->
                    <div
                        class="hero-wrapper grid grid-cols-1 md:grid-cols-12 gap-8 items-center justify-items-center"
                    >
                        <!-- hero text -->
                        <div
                            data-aos="fade-up"
                            class="hero-text text-center col-span-12 items-center content-center md:w-2/3"
                        >
                            <h1
                                class="font-bold text-4xl md:text-3xl text-white leading-tight"
                            >
                                Hi, I’m Takinur. Nice to meet you.
                            </h1>
                            <p
                                class="text-white text-lg text-center leading-relaxed mt-8 font-semibold"
                            >
                                Since beginning my journey as a freelance
                                webdeveloper nearly 3 years ago, I've done
                                remote work for agencies, consulted for
                                startups, and collaborated with talented people
                                to create digital products for both business and
                                consumer use. I'm quietly confident, naturally
                                curious, and perpetually working on improving my
                                chops one design problem at a time.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end hero -->
        </section>
        <!--Skills Section-->
        <section class="md:-mt-56 -mt-48">
            <div
                data-aos="fade-up"
                data-aos-once="false"
                data-aos-delay="50"
                data-aos-duration="600"
                Fdata-aos-easing="ease-in-out"
                class="container px-6 py-10 mx-auto md:mt-11 bg-gray-50 rounded-2xl w-4/5 pb-9 dark:bg-gray-800"
            >
                <h1 class="text-dark text-3xl text-center dark:text-gray-100">
                    PROFEESIONAL SKILLS
                </h1>
                <!-- CARD BODY-->
                <div
                    class="grid grid-cols-1 gap-8 mt-8 xl:mt-12 xl:gap-12 md:grid-cols-2 xl:grid-cols-3 content-center"
                >
                    <!--Card Item-->
                    <div class="p-8 space-y-3 rounded-xl">
                        <svg
                            class="text-gray-900 fill-current h-16 w-14 mx-auto dark:text-cyan-500"
                            viewBox="0 0 100 100"
                        >
                            <circle
                                class="cls-1"
                                cx="49.74"
                                cy="66.94"
                                r="4.44"
                            />
                            <path
                                class="cls-1"
                                d="M65.14,39.71C65.14,31.71,58,27,49.7,27c-7.11,0-11.1,2.74-14.46,7.09l-.06.08a1.9,1.9,0,0,0,.48,2.64l2.08,1.45a1.9,1.9,0,0,0,2.58-.38c2.38-3,4.76-4.55,9.38-4.55,6.29,0,9.1,3.2,9.1,6.37,0,6.92-12.27,5.85-12.27,17v.06a1.9,1.9,0,0,0,1.9,1.9H51l0,0a1.9,1.9,0,0,0,1.9-1.9v-.06C52.86,49.83,65.14,50.39,65.14,39.71Z"
                            />
                            <path
                                class="cls-1"
                                d="M29.74,31,26.53,27.4a.86.86,0,0,0-1.21-.08l-25,22a.86.86,0,0,0-.09,1.21l.09.09,25,22.08a.88.88,0,0,0,1.23-.09l0,.07L29.74,69a.86.86,0,0,0-.07-1.21L8.66,50l21-17.79A.86.86,0,0,0,29.74,31Z"
                            />
                            <path
                                class="cls-1"
                                d="M99.67,49.37l-25-22.06a.89.89,0,0,0-1.23.07L70.22,31a.86.86,0,0,0,.07,1.21L91.32,50l-21,17.79A.86.86,0,0,0,70.22,69l3.21,3.63a.86.86,0,0,0,1.21.12l0,0,25-22.08a.86.86,0,0,0,.09-1.21Z"
                            />
                        </svg>
                        <h1
                            class="text-2xl text-center font-semibold text-gray-900 uppercase dark:text-white"
                        >
                            PHP
                        </h1>

                        <p class="text-gray-500 dark:text-gray-300 text-center">
                            I use PHP 7 language to develop web applications
                        </p>
                    </div>
                    <!--end Card Item -->
                    <!--Card Item-->
                    <div class="p-8 space-y-3 rounded-xl">
                        <svg
                            class="text-gray-900 fill-current h-16 w-12 mx-auto dark:text-cyan-500"
                            viewBox="0 0 100 100"
                        >
                            <path
                                class="cls-1"
                                d="M64.62,6.82,60.28,5.59h-.07A1,1,0,0,0,59,6.32L34.6,91.93V92a1,1,0,0,0,.73,1.17l4.34,1.23h.05l.08,0a1,1,0,0,0,1.2-.75L65.35,8.1V8A1,1,0,0,0,64.62,6.82Z"
                            />
                            <path
                                class="cls-1"
                                d="M8.67,50l21-17.79A.86.86,0,0,0,29.76,31l-3.21-3.63a.86.86,0,0,0-1.21-.08l-25,22A.86.86,0,0,0,.25,50.5l.09.09,25,22.08a.88.88,0,0,0,1.23-.09l0,.07L29.76,69a.86.86,0,0,0-.07-1.21Z"
                            />
                            <path
                                class="cls-1"
                                d="M99.69,49.34l-25-22.06a.89.89,0,0,0-1.23.07L70.24,31a.86.86,0,0,0,.07,1.21L91.33,50l-21,17.79A.86.86,0,0,0,70.24,69l3.21,3.63a.86.86,0,0,0,1.21.12l0,0,25-22.08a.86.86,0,0,0,.09-1.21Z"
                            />
                        </svg>

                        <h1
                            class="text-2xl text-center font-semibold text-gray-900 uppercase dark:text-white"
                        >
                            html
                        </h1>

                        <p class="text-gray-500 dark:text-gray-300 text-center">
                            I use HTML 5 markup language to show data in the
                            browser
                        </p>
                    </div>
                    <!--end Card Item -->
                    <!--Card Item-->
                    <div class="p-8 space-y-3 rounded-xl">
                        <svg
                            class="text-gray-900 fill-current h-16 w-12 mx-auto dark:text-cyan-500"
                            viewBox="0 0 100 100"
                        >
                            <path
                                class="cls-1"
                                d="M27.93,89.41a9.1,9.1,0,0,1-4-1.67,5.78,5.78,0,0,1-1.93-3,15.81,15.81,0,0,1-.57-4.32q0-4.79.31-9.17T22,61.56q0-5.11-2-7.76T12.6,50.21v-.42Q18,48.86,20,46.2t2-7.76q0-4.9-.31-9.64t-.31-9.22a15.81,15.81,0,0,1,.52-4.32,5.78,5.78,0,0,1,1.93-3,9.1,9.1,0,0,1,4-1.67,33.56,33.56,0,0,1,6.51-.52h5.36V5.17H33.39a47.35,47.35,0,0,0-8.54.68,16.51,16.51,0,0,0-6,2.24,9.33,9.33,0,0,0-3.54,4.22A17,17,0,0,0,14.16,19q0,5.42.47,10.26t.47,9.84a7.23,7.23,0,0,1-.62,3,6.29,6.29,0,0,1-2.29,2.55,14.2,14.2,0,0,1-4.64,1.88A32.42,32.42,0,0,1,0,47.29v5.42a32.54,32.54,0,0,1,7.6.69,14.3,14.3,0,0,1,4.64,1.88,6.31,6.31,0,0,1,2.29,2.55,7.24,7.24,0,0,1,.62,3q0,2.6-.16,5l-.31,4.79-.31,4.95q-.16,2.55-.16,5.36a17,17,0,0,0,1.15,6.72,9.34,9.34,0,0,0,3.54,4.22,16.52,16.52,0,0,0,6,2.24,47.35,47.35,0,0,0,8.54.68l6.42,0v-4.9H34.44A33.5,33.5,0,0,1,27.93,89.41Z"
                            />
                            <path
                                class="cls-1"
                                d="M87.81,44.72a6.28,6.28,0,0,1-2.29-2.55,7.23,7.23,0,0,1-.62-3q0-5,.47-9.84t.47-10.26a17,17,0,0,0-1.15-6.72,9.35,9.35,0,0,0-3.54-4.22,16.5,16.5,0,0,0-6-2.24,46.47,46.47,0,0,0-8.49-.68H60.31v4.86h5.28a33.57,33.57,0,0,1,6.51.52,9.54,9.54,0,0,1,4,1.67,5.67,5.67,0,0,1,2,3,15.87,15.87,0,0,1,.52,4.32q0,4.48-.31,9.22T78,38.44q0,5.11,2,7.76t7.4,3.59v.42Q82,51.14,80,53.8t-2,7.76q0,5.28.34,9.66t.31,9.17a15.87,15.87,0,0,1-.52,4.32,5.67,5.67,0,0,1-2,3,9.54,9.54,0,0,1-4,1.67,33.54,33.54,0,0,1-6.51.52H60.31v4.89l6.35.08a46.49,46.49,0,0,0,8.49-.68,16.51,16.51,0,0,0,6-2.24,9.36,9.36,0,0,0,3.54-4.22A17,17,0,0,0,85.84,81q0-2.81-.16-5.36t-.31-4.95l-.31-4.79q-.16-2.39-.16-5a7.23,7.23,0,0,1,.62-3,6.29,6.29,0,0,1,2.29-2.55,14.28,14.28,0,0,1,4.64-1.88,32.53,32.53,0,0,1,7.55-.73V47.33a32.43,32.43,0,0,1-7.55-.73A14.19,14.19,0,0,1,87.81,44.72Z"
                            />
                        </svg>

                        <h1
                            class="text-2xl text-center font-semibold text-gray-900 uppercase dark:text-white"
                        >
                            css
                        </h1>

                        <p class="text-gray-500 dark:text-gray-300 text-center">
                            I use CSS to make look and feel better
                        </p>
                    </div>
                    <!--end Card Item -->
                    <!--Card Item-->
                    <div class="p-8 space-y-3 rounded-xl">
                        <div
                            class="text-gray-700 dark:text-cyan-400 w-12 mx-auto"
                        >
                            <i class="fab fa-js-square fa-3x"></i>
                        </div>

                        <h1
                            class="text-2xl text-center font-semibold text-gray-900 dark:text-white"
                        >
                            JavaScript
                        </h1>

                        <p class="text-gray-500 dark:text-gray-300 text-center">
                            I use JavaScript to make user experience better
                        </p>
                    </div>
                    <!--end Card Item -->
                    <!--Card Item-->
                    <div class="p-8 space-y-3 rounded-xl">
                        <div
                            class="text-gray-700 dark:text-cyan-400 w-12 mx-auto"
                        >
                            <i class="fas fa-database fa-3x"></i>
                        </div>

                        <h1
                            class="text-2xl text-center font-semibold text-gray-900 dark:text-white"
                        >
                            Database
                        </h1>

                        <p class="text-gray-500 dark:text-gray-300 text-center">
                            I use relational databases MySQL and MariaDB to
                            store data
                        </p>
                    </div>
                    <!--end Card Item -->
                    <!--Card Item-->
                    <div class="p-8 pt-3 space-y-3 rounded-xl">
                        <svg
                            class="text-gray-900 fill-current h-16 w-12 mx-auto dark:text-cyan-500"
                            viewBox="0 0 100 100"
                        >
                            <path
                                class="cls-1"
                                d="M67.62.48C66,1.4,63.45,4,60.33,7.82h0L63.2,13.2a70.43,70.43,0,0,1,6.09-7.65l.24-.26-.24.26a63.79,63.79,0,0,0-5.73,7.76,107.48,107.48,0,0,0,11.11-1.37C75.77,5.82,73.6,3,73.6,3S70.85-1.43,67.62.48Z"
                            />
                            <path
                                class="cls-1"
                                d="M57.46,45.89l.56-.11-.84.15h0Z"
                            />
                            <path
                                class="cls-2"
                                d="M57.46,45.89l.56-.11-.84.15h0Z"
                            />
                            <polygon
                                class="cls-1"
                                points="59.2 41.06 59.91 40.93 59.16 41.05 59.15 41.06 59.2 41.06"
                            />
                            <polygon
                                class="cls-2"
                                points="59.2 41.06 59.91 40.93 59.16 41.05 59.15 41.06 59.2 41.06"
                            />
                            <path
                                class="cls-1"
                                d="M60.33,7.83l-.64.79c-.82,1-1.68,2.13-2.56,3.3s-2,2.73-3,4.21-1.92,2.8-2.89,4.28c-.82,1.26-1.65,2.56-2.47,3.89l-.09.15L52.4,31.8q1.15-2.36,2.37-4.65t2.64-4.76q1.34-2.33,2.8-4.66l.17-.27q1.4-2.21,2.82-4.25h0Z"
                            />
                            <polygon
                                class="cls-1"
                                points="60.33 7.83 63.19 13.21 63.2 13.2 60.34 7.82 60.33 7.83"
                            />
                            <path
                                class="cls-1"
                                d="M41.17,67.46l-3,.33v0h0l-.32.78q-.74,2-1.48,4.14v.06l-.21.6-1.29,3.75a7.33,7.33,0,0,1,2.81,3.31,6,6,0,0,0-1.94-4.12c5.4.24,10.06-1.12,12.46-5.07a10,10,0,0,0,.59-1.12c-1.09,1.39-2.45,2-5,1.83,3.76-1.68,5.64-3.3,7.31-6,.4-.63.78-1.33,1.17-2.1a11.77,11.77,0,0,1-11.1,3.61h0l-.15,0Z"
                            />
                            <path
                                class="cls-1"
                                d="M37.26,67v0q.74-2,1.52-4l.44-1.19q1-2.52,2-5.09t2-5q1-2.49,2.12-5l2.25-5.07q1.13-2.49,2.3-5L50.78,35q.74-1.52,1.49-3l.08-.16-3.72-7.35-.18.3q-1.3,2.11-2.58,4.34c-.85,1.48-1.7,3-2.52,4.56q-1,2-2,3.94l-.39.8c-.81,1.67-1.54,3.28-2.21,4.83q-1.13,2.63-2,5c-.38,1-.73,2.06-1,3s-.51,1.66-.74,2.48q-.83,2.92-1.43,5.82l2.63,5.3L37.27,67Z"
                            />
                            <path
                                class="cls-1"
                                d="M35.34,72.21q.75-2.08,1.56-4.25l.36-1-1.05-2.12-2.67-5.28-.06.26a57.38,57.38,0,0,0-1,7.05v.25c-1.17-1.87-4.29-3.69-4.28-3.68,2.24,3.24,3.93,6.46,4.19,9.62a9.44,9.44,0,0,1-4.73-.81,9.51,9.51,0,0,0,4,2.45c-1.81.11-3.71,1.36-5.61,2.8,2.78-1.14,5-1.59,6.65-1.22C30.18,83.53,27.62,91.52,25,100a2.23,2.23,0,0,0,1.52-1.47C27,97,30,86.92,34.81,73.67l.41-1.14Z"
                            />
                            <polygon
                                class="cls-1"
                                points="37.27 66.96 36.21 64.86 37.26 66.98 37.27 66.96"
                            />
                            <path
                                class="cls-1"
                                d="M62.91,31.28l2.76-.3-2.76.3h-.06l-.42.07h.07l-9.45,1-.12.07-.32.66-1,2q-.54,1.13-1.08,2.3L50,38.62q-.83,1.81-1.69,3.75-1.05,2.38-2.15,4.94T44,52.37q-1,2.48-2,5.13-.93,2.36-1.87,4.85l-.09.24q-.94,2.47-1.89,5.08v.09l3-.33c3.58-.5,8.27-3.15,11.32-6.42a28.51,28.51,0,0,0,3.91-5.44,47,47,0,0,0,2.52-5.24c.7-1.68,1.36-3.51,2-5.49a10.91,10.91,0,0,1-2.82,1l-.56.11-.57.09.22-.1-.27,0,.29-.05a13.09,13.09,0,0,0,6.76-6.72,11.94,11.94,0,0,1-4,1.77l-.71.13H59l.08,0h0l.06,0h0A13.65,13.65,0,0,0,62,39.43c.18-.14.36-.28.53-.43s.51-.46.74-.71.3-.32.44-.49a11.66,11.66,0,0,0,.94-1.29l.26-.44.32-.63c.47-.94.84-1.78,1.14-2.52.15-.37.28-.71.39-1l.13-.37c.12-.35.22-.67.29-.95a9.31,9.31,0,0,0,.22-1,3.65,3.65,0,0,1-.39.27A14.16,14.16,0,0,1,62.91,31.28Z"
                            />
                            <path class="cls-1" d="M59.08,41.07h0Z" />
                            <path class="cls-1" d="M57.16,45.94h0l-.29.05Z" />
                            <polygon
                                class="cls-1"
                                points="59.02 41.08 59.08 41.07 59.02 41.07 59.02 41.08"
                            />
                            <polygon
                                class="cls-1"
                                points="59.02 41.06 59.02 41.07 59.08 41.07 59.14 41.06 59.02 41.06"
                            />
                            <polygon
                                class="cls-1"
                                points="59.15 41.06 59.16 41.05 59.14 41.06 59.15 41.06"
                            />
                            <path
                                class="cls-1"
                                d="M38.17,67.79l3-.33H41l.15,0-3,.33Z"
                            />
                            <path
                                class="cls-1"
                                d="M60.83,17.73l-.16.26Q59.39,20.14,58,22.73,56.72,25,55.39,27.55,54.22,29.79,53,32.32l9.45-1,.15-.07h0a11.48,11.48,0,0,0,5-4c.32-.46.64-.93,1-1.43A50.67,50.67,0,0,0,71.42,21a50.26,50.26,0,0,0,2.1-4.62,24.27,24.27,0,0,0,.83-2.5c.17-.66.31-1.28.41-1.87a107.68,107.68,0,0,1-11.19,1.33C62.73,14.61,61.81,16.07,60.83,17.73Z"
                            />
                        </svg>

                        <h1
                            class="text-2xl text-center font-semibold text-gray-900 uppercase dark:text-white"
                        >
                            Apache Server
                        </h1>

                        <p class="text-gray-500 dark:text-gray-300 text-center">
                            I use Apache server to serve sites
                        </p>
                    </div>
                    <!--end Card Item -->
                </div>
                <!--End Card Body -->
            </div>
        </section>
        <!--Project Section-->
        <section id="projects" class="py-24 bg-gray-200 dark:bg-slate-800">
            <div
                class="container px-2 py-10 mx-auto md:mt-11 bg-gray-200 rounded-2xl w-4/5 pb-9 dark:bg-slate-800"
            >
                <h1
                    class="text-dark text-3xl text-center mb-7 dark:text-gray-200"
                >
                    MY RECENT WORKS
                </h1>
                <div class="flex flex-wrap -mx-4">
                    <div
                        class="w-full md:w-1/2 xl:w-1/3 px-4"
                        data-aos="zoom-in-left"
                        data-aos-once="false"
                        data-aos-delay="50"
                        data-aos-duration="600"
                        Fdata-aos-easing="ease-in-out"
                    >
                        <div class="bg-white rounded-lg overflow-hidden mb-10">
                            <img
                                v-bind:src="
                                    '/images/projects/' + 'portfolio.webp'
                                "
                                alt="image"
                                class="w-full"
                            />
                            <div
                                class="p-8 sm:p-9 md:p-7 xl:p-9 text-center cursor-default mt-1"
                            >
                                <h3>
                                    <p
                                        class="capitalize font-semibold text-dark text-xl sm:text-[22px] md:text-xl lg:text-[22px] xl:text-xl 2xl:text-[22px] mb-4 block hover:text-primary"
                                    >
                                        A portfolio website with dark mode
                                    </p>
                                </h3>

                                <a
                                    href="https://www.takinur.com/"
                                    class="disabled:cursor-default mx-auto opacity-75 py-2 px-6 text-[#7510F7] font-semibold rounded-full border-2 border-[#7510F7] shadow-lg block md:inline-block hover:bg-[#7510F7] hover:text-gray-100"
                                >
                                    Visit Website
                                    <i class="fas fa-chevron-right ml-2"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div
                        class="w-full md:w-1/2 xl:w-1/3 px-4"
                        data-aos="zoom-in-left"
                        data-aos-once="false"
                        data-aos-delay="50"
                        data-aos-duration="600"
                        Fdata-aos-easing="ease-in-out"
                    >
                        <div class="bg-white rounded-lg overflow-hidden mb-10">
                            <img
                                v-bind:src="
                                    '/images/projects/' + 'driverless01.webp'
                                "
                                alt="image"
                                class="w-full"
                            />
                            <div
                                class="p-8 sm:p-9 md:p-7 xl:p-9 text-center cursor-default mt-2"
                            >
                                <h3>
                                    <p
                                        class="font-semibold text-dark text-xl sm:text-[22px] md:text-xl lg:text-[22px] xl:text-xl 2xl:text-[22px] mb-4 block hover:text-primary"
                                    >
                                        Dynamic Website For Driverless Company
                                    </p>
                                </h3>

                                <a
                                    href="javascript:void(0)"
                                    class="disabled:cursor-default mx-auto opacity-75 py-2 px-6 text-[#7510F7] font-semibold rounded-full border-2 border-[#7510F7] shadow-lg block md:inline-block hover:bg-[#7510F7] hover:text-gray-100"
                                >
                                    Visit Website
                                    <i class="fas fa-chevron-right ml-2"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="w-full md:w-1/2 xl:w-1/3 px-4">
                        <div
                            class="bg-white rounded-lg overflow-hidden mb-10"
                            data-aos="zoom-in-left"
                            data-aos-once="false"
                            data-aos-delay="50"
                            data-aos-duration="600"
                            Fdata-aos-easing="ease-in-out"
                        >
                            <img
                                v-bind:src="
                                    '/images/projects/' + 'axietech.webp'
                                "
                                alt="image"
                                class="w-full"
                            />
                            <div class="p-8 sm:p-9 md:p-7 xl:p-9 text-center">
                                <h3>
                                    <p
                                        href="https://www.axietech.com/"
                                        target="_blank"
                                        class="font-semibold text-dark text-xl sm:text-[22px] md:text-xl lg:text-[22px] xl:text-xl 2xl:text-[22px] mb-4 block hover:text-primary"
                                    >
                                        Developed a Complete E-Commerce Website
                                        with Advance SEO
                                    </p>
                                </h3>
                                <a
                                    href="https://www.axietech.com/"
                                    target="_blank"
                                    class="mx-auto opacity-75 py-2 px-6 text-[#7510F7] font-semibold rounded-full border-2 border-[#7510F7] shadow-lg block md:inline-block hover:bg-[#7510F7] hover:text-gray-100"
                                >
                                    Visit Website
                                    <i class="fas fa-chevron-right ml-2"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="w-full md:w-1/2 xl:w-1/3 px-4">
                        <div
                            class="bg-white rounded-lg overflow-hidden mb-10"
                            data-aos="zoom-in-left"
                            data-aos-once="false"
                            data-aos-delay="50"
                            data-aos-duration="600"
                            Fdata-aos-easing="ease-in-out"
                        >
                            <img
                                v-bind:src="
                                    '/images/projects/' + 'job-platform.webp'
                                "
                                alt="image"
                                class="w-full"
                            />
                            <div
                                class="p-8 sm:p-9 md:p-7 xl:p-9 text-center cursor-default mt-6"
                            >
                                <h3>
                                    <p
                                        class="font-semibold text-dark text-xl sm:text-[22px] md:text-xl lg:text-[22px] xl:text-xl 2xl:text-[22px] mb-4 block hover:text-primary"
                                    >
                                        A job platform for an consultancy farm
                                    </p>
                                </h3>
                                <a
                                    href="javascript:void(0)"
                                    class="disabled:cursor-default mx-auto opacity-75 py-2 px-6 text-[#7510F7] font-semibold rounded-full border-2 border-[#7510F7] shadow-lg block md:inline-block hover:bg-[#7510F7] hover:text-gray-100"
                                >
                                    Visit Website
                                    <i class="fas fa-chevron-right ml-2"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="w-full md:w-1/2 xl:w-1/3 px-4">
                        <div
                            class="bg-white rounded-lg overflow-hidden mb-10"
                            data-aos="zoom-in-left"
                            data-aos-once="false"
                            data-aos-delay="50"
                            data-aos-duration="600"
                            Fdata-aos-easing="ease-in-out"
                        >
                            <img
                                v-bind:src="
                                    '/images/projects/' + 'art_site.webp'
                                "
                                alt="image"
                                class="w-full"
                            />
                            <div
                                class="p-8 sm:p-9 md:p-7 xl:p-9 text-center cursor-default mt-2"
                            >
                                <h3>
                                    <p
                                        class="font-semibold text-dark text-xl sm:text-[22px] md:text-xl lg:text-[22px] xl:text-xl 2xl:text-[22px] mb-4 block hover:text-primary"
                                    >
                                        Art Website with wordpress CMS
                                    </p>
                                </h3>
                                <a
                                    href="https://originalpaintingsoilcanvas.com/"
                                    target="_blank"
                                    class="disabled:cursor-default mx-auto opacity-75 py-2 px-6 text-[#7510F7] font-semibold rounded-full border-2 border-[#7510F7] shadow-lg block md:inline-block hover:bg-[#7510F7] hover:text-gray-100"
                                >
                                    Visit Website
                                    <i class="fas fa-chevron-right ml-2"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="w-full md:w-1/2 xl:w-1/3 px-4">
                        <div
                            class="bg-white rounded-lg overflow-hidden mb-10"
                            data-aos="zoom-in-left"
                            data-aos-once="false"
                            data-aos-delay="50"
                            data-aos-duration="600"
                            Fdata-aos-easing="ease-in-out"
                        >
                            <img
                                v-bind:src="'/images/projects/' + 'Courier.webp'"
                                alt="image"
                                class="w-full"
                            />
                            <div
                                class="p-8 sm:p-9 md:p-7 xl:p-9 text-center cursor-default mt-2"
                            >
                                <h3>
                                    <p
                                        class="font-semibold text-dark text-xl sm:text-[22px] md:text-xl lg:text-[22px] xl:text-xl 2xl:text-[22px] mb-4 block hover:text-primary"
                                    >
                                        E-courier Web application with booking
                                        and payments
                                    </p>
                                </h3>
                                <a
                                    href="http://courierinmoscow.com/"
                                    target="_blank"
                                    class="disabled:cursor-default mx-auto opacity-75 py-2 px-6 text-[#7510F7] font-semibold rounded-full border-2 border-[#7510F7] shadow-lg block md:inline-block hover:bg-[#7510F7] hover:text-gray-100"
                                >
                                    Visit Website
                                    <i class="fas fa-chevron-right ml-2"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Frameworks Section-->
        <section id="frameworks" class="pb-24 bg-gray-100 dark:bg-gray-700">
            <div
                class="container px-6 py-10 mx-auto md:mt-11 bg-gray-100 rounded-2xl w-4/5 pb-9 dark:bg-gray-700"
            >
                <h1 class="text-dark text-3xl text-center dark:text-zinc-50">
                    FRAMEWORKS
                </h1>
                <h4 class="text-gray-600 text-center dark:text-zinc-200">
                    On the shoulders of giants
                </h4>
                <!-- CARD BODY-->
                <div
                    class="grid grid-cols-2 gap-8 mt-8 xl:mt-12 xl:gap-12 md:grid-cols-4 xl:grid-cols-6 content-center"
                >
                    <!--Card Item-->
                    <div
                        class="py-2 rounded-xl bg-white shadow-2xl dark:bg-gray-900"
                    >
                        <div
                            class="bg-cover h-18 w-16 md:w-16 md:mt-3 mx-auto md:grayscale hover:grayscale-0 dark:grayscale-0"
                        >
                            <img
                                v-bind:src="'/images/icons/' + 'laravel.svg'"
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-5 md:mt-3 text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Laravel
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            PHP Framework
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div
                        class="py-2 rounded-xl bg-white shadow-2xl dark:bg-gray-900"
                    >
                        <div
                            class="bg-cover h-18 w-28 mx-auto md:mt-3 md:grayscale hover:grayscale-0 dark:grayscale-0"
                        >
                            <img
                                v-bind:src="
                                    '/images/icons/' + 'tailwindcss.svg'
                                "
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Tailwind CSS
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            CSS Framework
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div
                        class="py-2 rounded-xl bg-white shadow-2xl dark:bg-gray-900"
                    >
                        <div
                            class="bg-cover h-18 w-20 md:w-20 mx-auto md:mt-2 md:grayscale hover:grayscale-0 dark:grayscale-0"
                        >
                            <img
                                v-bind:src="
                                    '/images/icons/' + 'bootstrap-icon.svg'
                                "
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-3 text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Bootstrap
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            HTML, CSS and JS library
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div
                        class="py-2 rounded-xl bg-white shadow-2xl dark:bg-gray-900"
                    >
                        <div
                            class="bg-cover mt-2 h-18 w-20 md:w-16 mx-auto md:grayscale hover:grayscale-0 dark:grayscale-0"
                        >
                            <img
                                v-bind:src="'/images/icons/' + 'jquery.png'"
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-7 text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            JQuery
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            JavaScript library
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div
                        class="py-2 rounded-xl bg-white shadow-2xl dark:bg-gray-900"
                    >
                        <div
                            class="bg-cover h-18 w-20 md:mt-4 mx-auto md:grayscale hover:grayscale-0 dark:grayscale-0"
                        >
                            <img
                                v-bind:src="'/images/icons/' + 'vue-js-1.svg'"
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-3 text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            VUE JS
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            JavaScript Framework
                        </p>
                    </div>
                    <!-- END card ITEM -->

                    <!--Card Item-->
                    <div
                        class="py-2 rounded-xl bg-white shadow-2xl dark:bg-gray-900"
                    >
                        <div
                            class="bg-cover mt-5 h-18 w-28 md:w-32 mx-auto md:grayscale hover:grayscale-0 dark:grayscale-0"
                        >
                            <img
                                v-bind:src="
                                    '/images/icons/' + 'laravel-livewire.png'
                                "
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-7 text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Livewire
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            Laravel library
                        </p>
                    </div>
                    <!-- END card ITEM -->
                </div>
                <!--End Card Body -->
            </div>
        </section>
        <!-- TOOls Section-->
        <section id="tools" class="pb-24 bg-gray-200 dark:bg-gray-800">
            <div class="container px-6 py-10 mx-auto md:mt-1 w-4/5 pb-9">
                <h1 class="text-dark text-3xl text-center dark:text-zinc-200">
                    TOOLS AND PRINCIPLES
                </h1>
                <h4 class="text-gray-600 text-center dark:text-zinc-300">
                    I use daily
                </h4>
                <!-- CARD BODY-->
                <div
                    class="grid grid-cols-3 gap-8 mt-8 xl:mt-12 xl:gap-12 md:grid-cols-4 xl:grid-cols-6 content-center"
                >
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="bg-cover grayscale h-18 w-16 md:w-16 md:mt-3 mx-auto dark:grayscale-0"
                        >
                            <img
                                v-bind:src="'/images/icons/' + 'vscode.svg'"
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-5 md:mt-3 text-xl md:text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            VScode IDE
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            Development Environment
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div class="bg-cover h-18 w-16 md:w-16 md:mt-3 mx-auto">
                            <svg
                                class="text-gray-900 fill-current h-16 w-18 mx-auto dark:text-cyan-200"
                                viewBox="0 0 100 100"
                            >
                                <path
                                    class="cls-1"
                                    d="M4.35,15.25,37.69,48.58a1.9,1.9,0,0,1,0,2.68L4.35,84.6a1.9,1.9,0,0,1-2.68,0L.56,83.49a1.9,1.9,0,0,1,0-2.68L31.44,49.92.56,19a1.9,1.9,0,0,1,0-2.68L1.68,15.2A1.9,1.9,0,0,1,4.35,15.25ZM100,83.41V81.83a1.9,1.9,0,0,0-1.9-1.9H46.29a1.9,1.9,0,0,0-1.9,1.9h0v1.58a1.9,1.9,0,0,0,1.9,1.9H98.1a1.9,1.9,0,0,0,1.9-1.9Z"
                                />
                            </svg>
                        </div>
                        <h1
                            class="mt-5 md:mt-3 text-xl md:text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Terminal
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            Command Line Interface
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div class="bg-cover h-18 w-16 md:w-16 md:mt-3 mx-auto">
                            <svg
                                class="fill-current h-16 w-18 mx-auto grayscale dark:grayscale-0"
                                viewBox="-26.4 -44 228.8 264"
                            >
                                <defs>
                                    <linearGradient
                                        y2="44.354"
                                        x2="81.837"
                                        y1="75.021"
                                        x1="29.337"
                                        gradientUnits="userSpaceOnUse"
                                        id="f"
                                        xlink:href="#a"
                                    />
                                    <linearGradient
                                        y2="130.33"
                                        x2="52.538"
                                        y1="164.5"
                                        x1="110.87"
                                        gradientUnits="userSpaceOnUse"
                                        id="g"
                                        xlink:href="#b"
                                    />
                                    <linearGradient
                                        y2="114.13"
                                        x2="136.55"
                                        y1="49.804"
                                        x1="121.86"
                                        gradientUnits="userSpaceOnUse"
                                        id="j"
                                        xlink:href="#c"
                                    />
                                    <linearGradient
                                        y2="114.13"
                                        x2="136.55"
                                        y1="49.804"
                                        x1="121.86"
                                        gradientUnits="userSpaceOnUse"
                                        id="k"
                                        xlink:href="#c"
                                    />
                                    <linearGradient
                                        y2="44.354"
                                        x2="81.837"
                                        y1="75.021"
                                        x1="29.337"
                                        gradientUnits="userSpaceOnUse"
                                        id="n"
                                        xlink:href="#a"
                                    />
                                    <linearGradient
                                        y2="130.33"
                                        x2="52.538"
                                        y1="164.5"
                                        x1="110.87"
                                        gradientUnits="userSpaceOnUse"
                                        id="r"
                                        xlink:href="#b"
                                    />
                                    <circle r="88" cx="96" cy="96" id="d" />
                                </defs>
                                <clipPath id="e">
                                    <use
                                        height="100%"
                                        xlink:href="#d"
                                        overflow="visible"
                                        width="100%"
                                    />
                                </clipPath>
                                <g
                                    clip-path="url(#e)"
                                    transform="translate(-8 -8)"
                                >
                                    <path
                                        fill="#db4437"
                                        d="M21.97 8v108h39.39L96 56h88V8z"
                                    />
                                    <linearGradient
                                        x1="29.337"
                                        x2="81.837"
                                        y1="75.021"
                                        gradientUnits="userSpaceOnUse"
                                        y2="44.354"
                                        id="a"
                                    >
                                        <stop
                                            offset="0"
                                            stop-opacity=".6"
                                            stop-color="#A52714"
                                        />
                                        <stop
                                            offset=".66"
                                            stop-opacity="0"
                                            stop-color="#A52714"
                                        />
                                    </linearGradient>
                                    <path
                                        fill="url(#f)"
                                        d="M21.97 8v108h39.39L96 56h88V8z"
                                    />
                                </g>
                                <path
                                    fill="#3e2723"
                                    transform="translate(-8 -8)"
                                    d="M62.31 115.65L22.48 47.34l-.58 1 39.54 67.8z"
                                    fill-opacity=".15"
                                    clip-path="url(#e)"
                                />
                                <g
                                    clip-path="url(#e)"
                                    transform="translate(-8 -8)"
                                >
                                    <path
                                        fill="#0f9d58"
                                        d="M8 184h83.77l38.88-38.88V116H61.36L8 24.48z"
                                    />
                                    <linearGradient
                                        x1="110.87"
                                        x2="52.538"
                                        y1="164.5"
                                        gradientUnits="userSpaceOnUse"
                                        y2="130.33"
                                        id="b"
                                    >
                                        <stop
                                            offset="0"
                                            stop-opacity=".4"
                                            stop-color="#055524"
                                        />
                                        <stop
                                            offset=".33"
                                            stop-opacity="0"
                                            stop-color="#055524"
                                        />
                                    </linearGradient>
                                    <path
                                        fill="url(#g)"
                                        d="M8 184h83.77l38.88-38.88V116H61.36L8 24.48z"
                                    />
                                </g>
                                <path
                                    fill="#263238"
                                    transform="translate(-8 -8)"
                                    d="M129.84 117.33l-.83-.48L90.62 184h1.15l38.1-66.64z"
                                    fill-opacity=".15"
                                    clip-path="url(#e)"
                                />
                                <g
                                    clip-path="url(#e)"
                                    transform="translate(-8 -8)"
                                >
                                    <defs>
                                        <path
                                            d="M8 184h83.77l38.88-38.88V116H61.36L8 24.48z"
                                            id="h"
                                        />
                                    </defs>
                                    <clipPath id="i">
                                        <use
                                            height="100%"
                                            xlink:href="#h"
                                            overflow="visible"
                                            width="100%"
                                        />
                                    </clipPath>
                                    <g clip-path="url(#i)">
                                        <path
                                            fill="#ffcd40"
                                            d="M96 56l34.65 60-38.88 68H184V56z"
                                        />
                                        <linearGradient
                                            x1="121.86"
                                            x2="136.55"
                                            y1="49.804"
                                            gradientUnits="userSpaceOnUse"
                                            y2="114.13"
                                            id="c"
                                        >
                                            <stop
                                                offset="0"
                                                stop-opacity=".3"
                                                stop-color="#EA6100"
                                            />
                                            <stop
                                                offset=".66"
                                                stop-opacity="0"
                                                stop-color="#EA6100"
                                            />
                                        </linearGradient>
                                        <path
                                            fill="url(#j)"
                                            d="M96 56l34.65 60-38.88 68H184V56z"
                                        />
                                    </g>
                                </g>
                                <g
                                    clip-path="url(#e)"
                                    transform="translate(-8 -8)"
                                >
                                    <path
                                        fill="#ffcd40"
                                        d="M96 56l34.65 60-38.88 68H184V56z"
                                    />
                                    <path
                                        fill="url(#k)"
                                        d="M96 56l34.65 60-38.88 68H184V56z"
                                    />
                                </g>
                                <g
                                    clip-path="url(#e)"
                                    transform="translate(-8 -8)"
                                >
                                    <defs>
                                        <path
                                            d="M96 56l34.65 60-38.88 68H184V56z"
                                            id="l"
                                        />
                                    </defs>
                                    <clipPath id="m">
                                        <use
                                            height="100%"
                                            xlink:href="#l"
                                            overflow="visible"
                                            width="100%"
                                        />
                                    </clipPath>
                                    <g clip-path="url(#m)">
                                        <path
                                            fill="#db4437"
                                            d="M21.97 8v108h39.39L96 56h88V8z"
                                        />
                                        <path
                                            fill="url(#n)"
                                            d="M21.97 8v108h39.39L96 56h88V8z"
                                        />
                                    </g>
                                </g>
                                <radialGradient
                                    r="84.078"
                                    gradientTransform="translate(-576)"
                                    cx="668.18"
                                    cy="55.948"
                                    gradientUnits="userSpaceOnUse"
                                    id="o"
                                >
                                    <stop
                                        offset="0"
                                        stop-opacity=".2"
                                        stop-color="#3E2723"
                                    />
                                    <stop
                                        offset="1"
                                        stop-opacity="0"
                                        stop-color="#3E2723"
                                    />
                                </radialGradient>
                                <path
                                    fill="url(#o)"
                                    transform="translate(-8 -8)"
                                    d="M96 56v20.95L174.4 56z"
                                    clip-path="url(#e)"
                                />
                                <g
                                    clip-path="url(#e)"
                                    transform="translate(-8 -8)"
                                >
                                    <defs>
                                        <path
                                            d="M21.97 8v40.34L61.36 116 96 56h88V8z"
                                            id="p"
                                        />
                                    </defs>
                                    <clipPath id="q">
                                        <use
                                            height="100%"
                                            xlink:href="#p"
                                            overflow="visible"
                                            width="100%"
                                        />
                                    </clipPath>
                                    <g clip-path="url(#q)">
                                        <path
                                            fill="#0f9d58"
                                            d="M8 184h83.77l38.88-38.88V116H61.36L8 24.48z"
                                        />
                                        <path
                                            fill="url(#r)"
                                            d="M8 184h83.77l38.88-38.88V116H61.36L8 24.48z"
                                        />
                                    </g>
                                </g>
                                <radialGradient
                                    r="78.044"
                                    gradientTransform="translate(-576)"
                                    cx="597.88"
                                    cy="48.52"
                                    gradientUnits="userSpaceOnUse"
                                    id="s"
                                >
                                    <stop
                                        offset="0"
                                        stop-opacity=".2"
                                        stop-color="#3E2723"
                                    />
                                    <stop
                                        offset="1"
                                        stop-opacity="0"
                                        stop-color="#3E2723"
                                    />
                                </radialGradient>
                                <path
                                    fill="url(#s)"
                                    transform="translate(-8 -8)"
                                    d="M21.97 48.45l57.25 57.24L61.36 116z"
                                    clip-path="url(#e)"
                                />
                                <radialGradient
                                    r="87.87"
                                    gradientTransform="translate(-576)"
                                    cx="671.84"
                                    cy="96.138"
                                    gradientUnits="userSpaceOnUse"
                                    id="t"
                                >
                                    <stop
                                        offset="0"
                                        stop-opacity=".2"
                                        stop-color="#263238"
                                    />
                                    <stop
                                        offset="1"
                                        stop-opacity="0"
                                        stop-color="#263238"
                                    />
                                </radialGradient>
                                <path
                                    fill="url(#t)"
                                    transform="translate(-8 -8)"
                                    d="M91.83 183.89l20.96-78.2L130.65 116z"
                                    clip-path="url(#e)"
                                />
                                <g
                                    clip-path="url(#e)"
                                    transform="translate(-8 -8)"
                                >
                                    <circle
                                        fill="#f1f1f1"
                                        r="40"
                                        cx="96"
                                        cy="96"
                                    />
                                    <circle
                                        fill="#4285f4"
                                        r="32"
                                        cx="96"
                                        cy="96"
                                    />
                                </g>
                                <g
                                    clip-path="url(#e)"
                                    transform="translate(-8 -8)"
                                >
                                    <path
                                        fill="#3e2723"
                                        d="M96 55c-22.09 0-40 17.91-40 40v1c0-22.09 17.91-40 40-40h88v-1z"
                                        fill-opacity=".2"
                                    />
                                    <path
                                        fill="#fff"
                                        d="M130.6 116c-6.92 11.94-19.81 20-34.6 20-14.8 0-27.69-8.06-34.61-20h-.04L8 24.48v1L61.36 117h.04c6.92 11.94 19.81 20 34.61 20 14.79 0 27.68-8.05 34.6-20h.05v-1z"
                                        fill-opacity=".1"
                                    />
                                    <path
                                        fill="#3e2723"
                                        d="M97 56c-.17 0-.33.02-.5.03C118.36 56.3 136 74.08 136 96c0 21.92-17.64 39.7-39.5 39.97.17 0 .33.03.5.03 22.09 0 40-17.91 40-40s-17.91-40-40-40z"
                                        opacity=".1"
                                    />
                                    <path
                                        fill="#fff"
                                        d="M131 117.33c3.4-5.88 5.37-12.68 5.37-19.96 0-4.22-.66-8.28-1.87-12.09.95 3.42 1.5 7.01 1.5 10.73 0 7.28-1.97 14.08-5.37 19.96l.02.04-38.88 68h1.16l38.09-66.64z"
                                        fill-opacity=".2"
                                    />
                                </g>
                                <g
                                    clip-path="url(#e)"
                                    transform="translate(-8 -8)"
                                >
                                    <path
                                        fill="#fff"
                                        d="M96 9c48.43 0 87.72 39.13 87.99 87.5 0-.17.01-.33.01-.5 0-48.6-39.4-88-88-88S8 47.4 8 96c0 .17.01.33.01.5C8.28 48.13 47.57 9 96 9z"
                                        fill-opacity=".2"
                                    />
                                    <path
                                        fill="#3e2723"
                                        d="M96 183c48.43 0 87.72-39.13 87.99-87.5 0 .17.01.33.01.5 0 48.6-39.4 88-88 88S8 144.6 8 96c0-.17.01-.33.01-.5C8.28 143.87 47.57 183 96 183z"
                                        fill-opacity=".15"
                                    />
                                </g>
                                <radialGradient
                                    r="176.75"
                                    gradientTransform="translate(-8 -8)"
                                    cx="34.286"
                                    cy="32.014"
                                    gradientUnits="userSpaceOnUse"
                                    id="u"
                                >
                                    <stop
                                        offset="0"
                                        stop-opacity=".1"
                                        stop-color="#fff"
                                    />
                                    <stop
                                        offset="1"
                                        stop-opacity="0"
                                        stop-color="#fff"
                                    />
                                </radialGradient>
                                <circle fill="url(#u)" r="88" cx="88" cy="88" />
                            </svg>
                        </div>
                        <h1
                            class="mt-5 md:mt-3 text-xl md:text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Chrome
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            Web Browser and Devtool
                        </p>
                    </div>
                    <!-- END card ITEM -->

                    <!--Card Item-->
                    <div class="py-2">
                        <svg
                            class="w-16 md:mt-3 mx-auto text-zinc-300 fill-gray-600 dark:fill-white"
                            viewBox="0 0 100 100"
                        >
                            <rect
                                class="cls-1"
                                x="31.5"
                                y="9"
                                width="37"
                                height="37"
                                rx="4.85"
                                ry="4.85"
                            />
                            <rect
                                class="cls-1"
                                x="8"
                                y="54.5"
                                width="37"
                                height="37"
                                rx="4.85"
                                ry="4.85"
                            />
                            <rect
                                class="cls-1"
                                x="55"
                                y="54.5"
                                width="37"
                                height="37"
                                rx="4.85"
                                ry="4.85"
                            />
                        </svg>
                        <h1
                            class="mt-5 md:mt-3 text-xl md:text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            OOP
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            Think in objects
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="bg-cover grayscale h-18 w-16 md:w-16 md:mt-3 mx-auto dark:grayscale-0"
                        >
                            <img
                                v-bind:src="'/images/icons/' + 'mvc.svg'"
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-5 md:mt-3 text-xl md:text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            MVC
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            Design Pattern
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <svg
                            class="w-16 md:mt-3 mx-auto fill-zinc-600 dark:fill-gray-300"
                            viewBox="0 0 100 100"
                        >
                            <path
                                class="cls-1"
                                d="M55.74,93a.35.35,0,0,0-.33,0,2.8,2.8,0,0,1-1.79.21,2.17,2.17,0,0,0-1.27,0c-1.64.73-3.34,1.29-5,1.91-.13,0-.29,0-.38.21.78.27,1.57.4,2.33.72a42.45,42.45,0,0,1,5,2.48.46.46,0,0,0,.67-.07c.94-.88,1.93-1.7,2.94-2.51.55-.44,1.1-.88,1.7-1.39Z"
                            />
                            <path
                                class="cls-1"
                                d="M60.85,95.35a27.43,27.43,0,0,0-2.73,2.42l.48,1.52a1.06,1.06,0,0,0,.24-.09l4.93-3-2.54-1C61,95.13,61,95.26,60.85,95.35Z"
                            />
                            <path
                                class="cls-1"
                                d="M51.29,92.13A11.86,11.86,0,0,0,49.54,92a11,11,0,0,0-1.79.14,11.4,11.4,0,0,1-1.61.15h-.06a5.93,5.93,0,0,1-1.19-.08.32.32,0,0,1-.31-.33c0-.15,0-.23.2-.26h0l.07,0,1-.23,1.16-.26a12.46,12.46,0,0,1,2.24-.31h.1c.07,0,.13,0,.14-.05s-.09-.11-.16-.11h-.1a5.47,5.47,0,0,1-1.88-.87,7,7,0,0,1-3-3,10.6,10.6,0,0,0-1.14-1.53h0l-.07-.08c-.23.7-.39,1.32-.64,1.91a2.42,2.42,0,0,0,0,2.21.81.81,0,0,1-.2,1L41.1,91.74c-.1.11-.22.2-.17.37.12.44,0,1,.48,1.27.14.1.09.26.09.4v2.06c0,.15,0,.32.1.4a2.84,2.84,0,0,0,1.21.39s0,0,.07,0h0c.23,0,.25-.33.39-.5s.1-.2.16-.27c.87-.47,1.58-1.2,2.5-1.58C47.71,93.55,49.33,92.44,51.29,92.13Z"
                            />
                            <path
                                class="cls-1"
                                d="M64.37,86.35a.5.5,0,0,0-.23-.34l0,0-.05,0-.22.36L62,88.57a4.54,4.54,0,0,1-.34.31,21.58,21.58,0,0,1-3.24,1.85l.68,0a12.74,12.74,0,0,1,4.43,1.06c.57.26.61.74.66,1.23,0,.21,0,.35-.17.37a.89.89,0,0,1-.2-.05,53.54,53.54,0,0,0-6.5-1.8c-.08,0-.2-.09-.28-.07s-.17,0-.21.17-.07.45.26.52a7,7,0,0,1,.82.26c1.91.68,3.94,1.07,5.65,2.25a.57.57,0,0,0,.4.13,1,1,0,0,0,.55-.16,1.48,1.48,0,0,0,.83-2,2.29,2.29,0,0,1,.35-2.23.61.61,0,0,0,0-.68C65.27,88.61,64.83,87.47,64.37,86.35Z"
                            />
                            <path
                                class="cls-1"
                                d="M48.78,97.47c-.86-.4-1.69-.9-2.59-1.25-.55-.21-.87,0-1.32.36l3.92,1a.13.13,0,0,0,.05.05h.08s0,0,0,0v0s0,0,0-.05A.19.19,0,0,0,48.78,97.47Z"
                            />
                            <path
                                class="cls-1"
                                d="M89.47,38.7l.2-2.44c.09-1.1.19-2.2.28-3.37h0v0l-.27.07L70.31,38.61c-.33.09-.28.21-.15.44q1.52,2.67,3,5.35c.11.2.2.27.36.25l.17,0Q81.37,41.92,89,39.29A.57.57,0,0,0,89.47,38.7Z"
                            />
                            <path
                                class="cls-1"
                                d="M87.41,42.2l-.2-.14c-.49-.68-1.08-.91-1.8-.36-.49.11-.93.36-1.47.54-.11.09-.44.16-.55.25a1.61,1.61,0,0,0-.27.09,15,15,0,0,0-2,.76H81L79,44.11l-.25.1-.09,0-.34.13c-.54.16-1.86.67-2,.71-.62.23-.64.24-.46.86a1.18,1.18,0,0,1-.23,1.15c-.33.41-.6.86-.9,1.29l0,0-.09.1-.07.12a1.28,1.28,0,0,0-.05.2s0,0,0,0h0l0,.08s0,0,0,0,0,.05,0,.08l.08.17a5.44,5.44,0,0,0,1,1.62s0,0,0,0a.16.16,0,0,1,.07.05c.1.2.2.38.27.58a1.49,1.49,0,0,1,.12.47,1.21,1.21,0,0,1-.24.84s0,0,0,0l0,0s0,0,0,0A17.38,17.38,0,0,0,75.08,55h0s0,.05,0,.08-.11.33-.15.49a2.3,2.3,0,0,0-.09.37s0,.08,0,.12a1.93,1.93,0,0,0,0,.25,1.68,1.68,0,0,0,.26.76c0,.11,0,.17.08.26a16.45,16.45,0,0,1,.57,2s0,0,0,0,.08.27.11.4l.07.28.07.27a2.66,2.66,0,0,1,.05.28,4.4,4.4,0,0,1,.05,1,.62.62,0,0,0,0,.28s0,0,0,.05a.36.36,0,0,0,.12.16.5.5,0,0,0,.33.13h.08s0,0,.07,0l2,.73.16.09.44.28c.14.1.29.25.44.25s.11.07.16.1a5.28,5.28,0,0,0,1,.78,3.74,3.74,0,0,0,.27.29c.28.32.54.68.86,1,0,.05.05.11.09.16.17.23.33.46.49.69s.19.19.11.29-.21,0-.29-.05a6.21,6.21,0,0,0-1.27-.49v0s-.05,0-.08,0a8.06,8.06,0,0,0-2-.51h0v.05a33.78,33.78,0,0,0-4.19-.16c0,.17.15.11.24.22.48.33.88.79,1.43,1.16.11,0,.09.05.11.08s.05,0,.09.08a3.83,3.83,0,0,0,.78.67c0,.11.09.11.13.15l0,0a12.54,12.54,0,0,1,1,1.27h0s0,0,0,0v-.08l.17.28a1.17,1.17,0,0,0,.25.37.47.47,0,0,0,.16.28,10.05,10.05,0,0,1,.78,1.9,1.29,1.29,0,0,0,0,.17,7.8,7.8,0,0,1,.49,2.06c0,.05,0,.05,0,.16h0c-.11.38.17.76.05,1.17a.31.31,0,0,1-.19-.11.39.39,0,0,1-.08-.11l-.09-.19c-.05-.12-.1-.25-.15-.38a1.58,1.58,0,0,0-.2-.38c0-.11,0-.09,0-.13l0-.14a4.92,4.92,0,0,0-.76-1.46,1.41,1.41,0,0,0-.26-.47,1.15,1.15,0,0,0-.24-.22,5.64,5.64,0,0,0-1.7-1.63h0l-.08-.05,0,0a2.29,2.29,0,0,0-.32-.25L76.12,70l-.23-.14a.35.35,0,0,0-.19-.08c-.09,0-.13.08-.15.23,0,.36-.1.73-.15,1.09s-.11.75-.16,1.08a.62.62,0,0,0,0,.08A7.17,7.17,0,0,0,75,74.41s0,.05,0,.09,0,.32,0,.47a5.12,5.12,0,0,0,0,1.53.43.43,0,0,0,0,.15s0,.05,0,.08a12.32,12.32,0,0,0,.09,1.89,1.13,1.13,0,0,0,0,.12.45.45,0,0,0,0,.12c.07.49.12,1,.19,1.5a3.77,3.77,0,0,1,0,.49s.05.05.05.05c0,.22.05.42.08.61s0,.4.08.63c-.28-.28-.52-.49-.75-.71l-.19-.24a2.83,2.83,0,0,0-.25-.27c0-.05-.07-.11-.1-.16l-.12-.16a1.19,1.19,0,0,1-.13-.26l-.1-.28c-.14-.46-.32-.91-.48-1.35a.19.19,0,0,0,0-.08A13.66,13.66,0,0,1,73,75.09h-.11c-.13.71-.26,1.46-.39,2.12h-.07a16.53,16.53,0,0,0-.16,4.28c0,.13.05.26.07.39l.1.79c0,.13,0,.26.05.39a.62.62,0,0,1,0,.13.16.16,0,0,0,0,.12c0,.11,0,.23.05.34s0,.23.05.34a1.31,1.31,0,0,1,0,.22s0,.08,0,.11a1.75,1.75,0,0,0,.05.23c0,.07,0,.15.07.23a2,2,0,0,0,.14.36s.05,0,.09.11c-.16.22-.22,0-.33,0v-.09h0a4.33,4.33,0,0,1-.34-.4c-.37-.6-.74-1.23-1.11-1.78h0a14.84,14.84,0,0,0-.79-2.06c-.11-.37-.19-.73-.27-1.1a2.63,2.63,0,0,0-.16-.86c0-.05,0-.12,0-.17,0-.38-.1-.76-.15-1.15a4,4,0,0,1,0-1.49c0-.13.08-.34-.1-.38h-.05c-.12,0-.19.15-.26.25-.23.31-.41.62-.62.93a2.69,2.69,0,0,1-.15.23c-.11.15-.22.31-.34.45a1,1,0,0,0-.2.22c-.05,0-.11.07-.22.1h0c-.22.23-.59.37-.67.76,0,0,0,.05,0,.08-.26.64-.48,1.32-.68,2a1.23,1.23,0,0,0-.09.26c-.22.38-.33.76-.5,1.09s-.14.35-.22.52l-.22.52a7.05,7.05,0,0,0-.34.63s0,.05,0,.08l0,.15a.78.78,0,0,0,0,.32,5.93,5.93,0,0,0,.36.92c.11.46.27.91.43,1.37h0l0,.08s0,.07,0,.09,0,.05,0,.08a1.49,1.49,0,0,0,.16.45c0,.07.05,0,.08.15.11.33.21.69.33,1s.15.74.48,1c.11.51.22.54.72.34a8.11,8.11,0,0,0,.81-.35c.55-.25,1.15-.57,1.73-.79,0,0,.05,0,.08,0l1.9-.83,1.2-.51a8.51,8.51,0,0,1,1.12-.5s.09,0,.09,0c.66-.31,1.38-.62,2.06-.93l.16-.1a2.89,2.89,0,0,0,1-.42l.43-.17.6-.25.05,0v0a3,3,0,0,0,.45-.15l.27-.11.51-.22.26-.1a.36.36,0,0,0,.26-.41A29.13,29.13,0,0,1,81,80.36c0-.11,0-.22,0-.33v-.16a.82.82,0,0,0,0-.16.82.82,0,0,1,0-.16l0-.15s0-.05,0-.08a.75.75,0,0,1,.05-.14l0-.07a21.09,21.09,0,0,0,.94-2,11.11,11.11,0,0,0,1-2.18c.26-1,.31-2.15.48-3.22s.28-2.29.54-3.43L85,64.1A.33.33,0,0,0,85,64c.05-.17.1-.37.15-.55a2,2,0,0,0,.16-.87s0,0,0-.07,0,0,0,0l0-.07c.07-.25.12-.51.19-.78.28-.72.58-1.51.86-2.16a.32.32,0,0,1,.08-.16,8.7,8.7,0,0,0,.85-2,1.18,1.18,0,0,0,.26-.6l0,0s0,0,0,0,0,0,0,0v0s.05-.08.05-.11a14.68,14.68,0,0,0,.59-1.35.58.58,0,0,1,.09-.19c.25-.66.79-1.22.78-2a.58.58,0,0,0,.09-.35l.33-1.41a3.94,3.94,0,0,0,.09-.47.67.67,0,0,0-.26-.69,20.62,20.62,0,0,0-3.09-1.58,1.29,1.29,0,0,1-.76-.43.26.26,0,0,0,0-.09A1.15,1.15,0,0,1,87,47.82a1.29,1.29,0,0,0,.54.09s.05,0,.09,0,.05,0,.09,0l1.15.35h0l.13,0h0s.05,0,.07-.1c.08-.58.44-1.16,0-1.74a.34.34,0,0,0-.07-.16,1.23,1.23,0,0,1,0-1.89v0h0a0,0,0,0,0,0,0s0,0,0,0h0l0-.07a.19.19,0,0,0,.07-.07.11.11,0,0,0,0-.1.29.29,0,0,0-.07-.11c-.47-.5-1-1-1.41-1.52C87.54,42.38,87.51,42.28,87.41,42.2Z"
                            />
                            <path
                                class="cls-1"
                                d="M55.58,91.17a.55.55,0,0,0-.19,0,5.19,5.19,0,0,1-1.08.11H53.12a.47.47,0,0,0-.17,0c-.09,0-.17,0-.19.12a.34.34,0,0,0,.29.39,5.58,5.58,0,0,0,1.27.14,8,8,0,0,0,1.25-.1c.32,0,.27-.22.27-.42S55.72,91.15,55.58,91.17Z"
                            />
                            <path
                                class="cls-1"
                                d="M25.84,62.87l-.11.08v0l.12-.09,0,.17a7.35,7.35,0,0,0,.59-.45,11.68,11.68,0,0,1,4.37-2.23,22,22,0,0,1,5.64-1.1,47.7,47.7,0,0,0,8-1.41A15.15,15.15,0,0,0,49.16,56a22.54,22.54,0,0,0,2.6-2c.1-.09.17-.13.23-.12s.1.09.12.24a3.32,3.32,0,0,1-.55,2.53,7.8,7.8,0,0,1-3,2.21,32.91,32.91,0,0,1-6.49,2.5c-1.63.45-3.31.69-4.95,1.1-2,.51-4.13.71-6,1.7a5.1,5.1,0,0,0-2.42,2.46,2.4,2.4,0,0,0-.16,1.63.88.88,0,0,0,0,.16A10.61,10.61,0,0,1,29.31,67a4.87,4.87,0,0,1,3.09-1.87c1-.19,2.11-.27,3.16-.4,2.88-.38,5.8-.43,8.67-.85a15.48,15.48,0,0,0,6.54-2.17,24.12,24.12,0,0,0,4.11-2.95,8.6,8.6,0,0,0,2.7-4.49,2.54,2.54,0,0,0-.14-1.88A9.79,9.79,0,0,0,56,50.47l-.06-.06a9.25,9.25,0,0,0-1.65-1.29A9.38,9.38,0,0,0,49,47.64c-1,0-2,.07-3,.08a12.18,12.18,0,0,0-2.6.32A23,23,0,0,0,34,52.68a55.17,55.17,0,0,0-4.65,4.39,1.3,1.3,0,0,0-.19.24Q27.69,59.64,26.22,62A2.73,2.73,0,0,0,25.84,62.87Z"
                            />
                            <path
                                class="cls-1"
                                d="M28.86,13.57c-.85.39-1.46,1.14-2.27,1.59-.22.12-.11.24,0,.37l2.46,2.82a1.45,1.45,0,0,1,.14.23l.21-.09,1.17-.72c.13-.08.12-.17.08-.29-.46-1.26-.83-2.56-1.38-3.78C29.16,13.46,29.08,13.47,28.86,13.57Z"
                            />
                            <path
                                class="cls-1"
                                d="M31.27,61.58c-.82.38-1.64.78-2.46,1.15A1.08,1.08,0,0,0,28.06,64a.22.22,0,0,0,0,.09c0,.1.08.12.2,0a2.6,2.6,0,0,0,.28-.2,11.84,11.84,0,0,1,5-2.22c2.58-.48,5.18-.85,7.72-1.49a5.66,5.66,0,0,0,1.56-.49l-.41.08-2.38.39c-1.81.21-3.61.44-5.42.63A10.53,10.53,0,0,0,31.27,61.58Z"
                            />
                            <path
                                class="cls-1"
                                d="M30,53.87c.74-.61,1.42-1.29,2.11-2l.29-.29,0,0a7.3,7.3,0,0,1,1.1-1A22.63,22.63,0,0,1,38.23,48l.08,0c.28-.1.55-.22.82-.34A7.72,7.72,0,0,1,40.9,47c1-.17,1.91-.33,2.87-.51a17.41,17.41,0,0,1,3.66-.41,18.92,18.92,0,0,1,4.52.7,9.57,9.57,0,0,1,4.74,3.11l1,1.14c.05.07.09.14.15.16s.1,0,.13-.15a7.9,7.9,0,0,0,.44-2.7,12.47,12.47,0,0,0-.59-2.81,7.55,7.55,0,0,0-2.11-3.28,8.83,8.83,0,0,0-.94-.75c-.15-.12-.33-.22-.49-.33l-.51-.29c-.25-.15-.52-.28-.79-.42l-.26-.13c-.36-.17-.72-.33-1.08-.49A7.5,7.5,0,0,0,49,39.07h-.51a11.3,11.3,0,0,0-3.56.52c-.62.2-1.26.35-1.89.54l-.54.16q-.39.13-.79.29l-.13.05-.5.22-.39.23a23.4,23.4,0,0,0-3.63,2.65l-.31.28-.05,0c-.41.33-.73.65-1.08,1l-.12.13a4.17,4.17,0,0,0-.52.45c-.37.44-.75.86-1.14,1.3l-1.12,1.31q-.56.66-1.08,1.34l-.35.46c-.23.31-.45.62-.67.94a21.08,21.08,0,0,0-1.19,2,6.43,6.43,0,0,0-.67,2.15A9.87,9.87,0,0,0,30,53.87Z"
                            />
                            <path
                                class="cls-1"
                                d="M73.91,66.67H74a4.82,4.82,0,0,0-3-.81,10.18,10.18,0,0,1-3.2.2c-.13,0-.25-.05-.38-.07l-.34,0,.16.09h-.08a4.13,4.13,0,0,0,2.05.73,8.15,8.15,0,0,1,1.16.11,14.42,14.42,0,0,0,3.69-.14Z"
                            />
                            <path
                                class="cls-1"
                                d="M17.44,34.41A9,9,0,0,0,16.09,38c-.19.31-.15.49.25.55s.5.11.75.16c2,.54,4,1,6.05,1.52a.71.71,0,0,0,.51.1c.09,0,.08-.11.08-.17a.21.21,0,0,0,0-.09L25,35.94a1,1,0,0,1,.27-.57,2.18,2.18,0,0,0,.86-1.74c0-.27.11-.54.13-.81a.78.78,0,0,1,.49-.72,11.69,11.69,0,0,0,3.89-2.91,3.5,3.5,0,0,0,.67-.94,37.55,37.55,0,0,1,2.84-5,25.15,25.15,0,0,1,4-5,2.53,2.53,0,0,0,.73-1.32,1,1,0,0,0-.36-1,.84.84,0,0,0-1.07,0A27.92,27.92,0,0,1,32,18.78a3.84,3.84,0,0,0-2.23,1.68s-.1.07-.14.1a6,6,0,0,1-2,.74c-.2,0-.39,0-.6.1q-5.86,3.67-11.75,7.31c-.23.14-.27.25-.15.5.72,1.51,1.38,3.06,2.24,4.5A.56.56,0,0,1,17.44,34.41Z"
                            />
                            <path
                                class="cls-1"
                                d="M23.24,47.56,28,48.2H28c.19,0,.22-.17.26-.34l1.27-4.15c.1-.29,0-.38-.27-.46l-8.81-2.32-8.8-2.33-.17,0a.18.18,0,0,0-.17.09.16.16,0,0,1,0,.07s0,.09,0,.14q-.34,3.26-.7,6.5c0,.27,0,.39.23.45l.16,0c3.07.42,6.14.83,9.18,1.27Z"
                            />
                            <path
                                class="cls-1"
                                d="M13.4,49.67a.53.53,0,0,0,0,.39,1.26,1.26,0,0,0,.1-.51s0,0,0-.07A1.34,1.34,0,0,0,13.4,49.67Z"
                            />
                            <path
                                class="cls-1"
                                d="M25.56,20.63A41,41,0,0,1,21.73,18c-.1.45-.2.81-.27,1.17a.28.28,0,0,1-.25.25c-.32,0-.44-.23-.61-.4s-.31-.37-.21-.58c.27-.59.43-1.22.67-1.83s.25-.62.78-.23l.13.11a14.47,14.47,0,0,0,3.93,2.94,1.62,1.62,0,0,0,2-.09.81.81,0,0,1,.14-.09.18.18,0,0,0,.09-.25,2.37,2.37,0,0,0-.45-.87c-.79-.68-1.54-1.4-2.28-2.14a18.64,18.64,0,0,1-2.94-3.35,4.7,4.7,0,0,0-.82-1,.94.94,0,0,0-1.52.22c-.61,1.14-1.42,2.14-2.05,3.27s-1.56,2.36-2.18,3.65a.82.82,0,0,0,0,.73,15.14,15.14,0,0,1,.87,2.24c0,.17.09.33-.15.41s-.28,0-.37-.19c-.45-.75-.92-1.5-1.33-2.26A70,70,0,0,0,10.62,12c-.09-.11-.1-.39-.34-.27a.47.47,0,0,0-.31.51c.17.93.27,1.88.51,2.79,1,3.92,2.35,7.75,3.59,11.61.11.33.22.29.48.15C17.79,25,21,23.17,24.29,21.35Z"
                            />
                            <path
                                class="cls-1"
                                d="M25.4,14.14c.09.11.17.19.33.11A14.07,14.07,0,0,0,28,13.06c1.68-1.34,3.32-2.73,4.89-4.19.25-.23.43-.46.37-.73s.08-.49-.14-.61-.31.1-.45.16L32.15,8a47,47,0,0,1-4.73,2.42c-1.15.46-2.28.93-3.44,1.34-.13.05-.41,0-.21.29Z"
                            />
                            <path
                                class="cls-1"
                                d="M41,88.72c-.09-.44-.2-.87-.32-1.3a2,2,0,0,1,.05-.76,2.72,2.72,0,0,1,.4-.84l0-.08a1.18,1.18,0,0,0,.09-.16,1.08,1.08,0,0,0,.11-.25s.05,0,.08-.07c.62-1,.56-1.37-.31-2.1l0,0L41,83a1.76,1.76,0,0,0-.6-.6c-.05-.11-.12-.12-.17-.17A5.52,5.52,0,0,0,38.29,81l-.35-.22a.61.61,0,0,0-.23-.09h-.07l-.07,0a.34.34,0,0,0-.13.21s0,0,0,.05l-.69.94a7.21,7.21,0,0,1-.69.91.6.6,0,0,0-.26.44v0h0c-.55.69-1.14,1.29-1.73,1.9h0c-.26,0-.21-.11-.17-.23a.29.29,0,0,0,0-.08c.07-.62.26-1.22.27-1.85a7.34,7.34,0,0,0,.17-1.89h0s0,0,0-.05a.2.2,0,0,0,0-.17,7.47,7.47,0,0,0,0-1.91.3.3,0,0,0,0-.14c0-.05,0-.13-.05-.13a5,5,0,0,0-.42-2.07.68.68,0,0,0-.36-.16c-.6-.32-1.17-.62-1.82-.94h0c-.08,0-.16-.08-.25-.11A3.54,3.54,0,0,1,31,75a4.87,4.87,0,0,1-.49-.46l-.23-.25a.57.57,0,0,1-.11-.12,7.41,7.41,0,0,0-.56-.63h0c.11.87,0,1.8.86,2.37.08,0,.17.09.12.19s-.05.05-.09.08l-.12.05c-.23.07-.41-.11-.63-.13V76h0c-.09,0-.17-.11-.26-.11a20.16,20.16,0,0,1-1.62-1.41h0c-.16-.22-.35-.51-.52-.76a5.38,5.38,0,0,1-.74-1.34.46.46,0,0,0,0-.12s0-.05,0-.08c-.08-.67-.22-1.33-.33-2a.74.74,0,0,0,0-.2h0c-.09-.66-.2-1.31-.28-2h0s0-.08,0-.11A16.34,16.34,0,0,1,26,65.84h0a.25.25,0,0,0,0-.07s0-.05,0-.09a.25.25,0,0,1,0-.09s0-.05,0-.09,0,0,0,0a.57.57,0,0,0,0-.13s0,0,0,0a1.84,1.84,0,0,0,0-.24,1,1,0,0,0-.37.29c-.1.1-.22.13-.29.35h0c-.11.19-.24.36-.35.56-.34.5-.67,1.08-1,1.52,0,.11-.1.14-.13.2-.34.5-.63,1-1,1.59a1.65,1.65,0,0,1-.23.59c-.15.28-.26.57-.4.84l-.43.84-.1,0c.05-1.12.12-2.25.17-3.37,0,0,0,0,0,0a.68.68,0,0,0,0-.14.93.93,0,0,0,0-.13s0,0,0,0a.77.77,0,0,1,.09-.25A9.56,9.56,0,0,0,22.81,66a3.44,3.44,0,0,0,.34-1,5.32,5.32,0,0,0,.42-1.21c0-.08.08-.16.11-.25s.17-.31.25-.46a15.46,15.46,0,0,0,.62-1.43h0s0-.1.05-.14,0,0,0,0a7,7,0,0,0,.45-1h0c.14-.34.32-.69.46-1A7.32,7.32,0,0,1,26.34,58a7.8,7.8,0,0,1,.59-.73V57.1c-.11-.62-.23-1.21-.34-1.87v0a.72.72,0,0,1,0-.16c-.1-.5-.19-1-.28-1.51,0-.16-.05-.33-.09-.5s0-.13,0-.21c-.22-1-.36-2.08-.54-3.11a.33.33,0,0,0-.34-.32l-.1,0h-.09a7.05,7.05,0,0,1-1-.14c-.34-.05-.62-.11-1.06-.16v0h.07c-.66-.11-1.26-.16-2-.25,0,0,0,0-.05,0a.73.73,0,0,0-.43-.08c-.66-.11-1.31-.19-2-.27a.34.34,0,0,0-.17,0,9.86,9.86,0,0,0-1.65-.22.33.33,0,0,0-.15,0c-.58-.14-1.18-.15-1.76-.28a1.81,1.81,0,0,1-.43,0c-.35-.12-.44,0-.49.35-.12.64-.24,1.3-.4,1.93a1.2,1.2,0,0,0,.22,1.08c.16.25.32.49.45.74a2.86,2.86,0,0,1,.12.26,2.89,2.89,0,0,1,.22,1.17c-.08,2.72.14,5.43.24,8.15,0,1.3.13,2.6.2,3.9,0,.12,0,.24,0,.36.05.7.06,1.39.15,2.09h0v.28A16.12,16.12,0,0,0,14.8,70a.87.87,0,0,1,0,.16,4.27,4.27,0,0,0-.24,2v0l0,.12,0,.14a.39.39,0,0,0,.19.28c.47.22.94.41,1.41.62a.25.25,0,0,0,.33-.05h0c0-.05.1-.12.15-.17a6.64,6.64,0,0,0,.83-.7h0s0,0,0,0,0,0,0,0l0,0,.07-.09.09-.07A1.41,1.41,0,0,1,18,72a.56.56,0,0,1,.26-.1h0l.08,0,0,0a.45.45,0,0,1,0,.07.84.84,0,0,1,0,.14v.16a9,9,0,0,0-.76,2s0,.07,0,.09a.53.53,0,0,0-.11.24.49.49,0,0,0,0,.12.16.16,0,0,0,0,.07l0,.07a14.33,14.33,0,0,0,1,1.37v-.09a.83.83,0,0,0,.05.17.85.85,0,0,0,.12.2l.1.11.05.05A9.91,9.91,0,0,0,20.72,78l.27.19c.22.2.45.29.71.51a.28.28,0,0,1,.26.11,6.27,6.27,0,0,0,.94.66c.11.05.11.11.17.11h0c.57.44,1.14.83,1.71,1.23v0a1.64,1.64,0,0,0,.5.36c.59.54,1.33,1,1.88,1.44l.27.17c.05.05.13,0,.2.15h0l.34.19a6.45,6.45,0,0,0,1.41,1c.11,0,.12.07.17.17.34.22.7.49,1,.75v0c.11.08.16.13.25.19.73.4.69,1,.51,1.73,0,0,0,.08,0,.12l0,.25s0,.09,0,.13c0,.4-.14.83.2,1.15,0,0,0,0,.1.07s.11.12.16.17a.62.62,0,0,0,.07.12l.25.38c0,.11,0,.13,0,.19a4.18,4.18,0,0,1,0,.52.53.53,0,0,0,.51.68c.42.08.76.19,1.2.27h0a1.12,1.12,0,0,0,.2,0c.61.22,1.26.33,1.89.55a3.13,3.13,0,0,1,.69.16L37,92c.29.12.6.19.93.29h0v0h0l.12.05.05,0,.05,0,.62.22a.75.75,0,0,0,.23.05h0a.21.21,0,0,0,.11-.05l0-.05a.48.48,0,0,0,0-.08s0-.07,0-.11.11-.39.22-.71v-.07h0s0,0,0-.07,0,0,0,0a.88.88,0,0,1,.35-.39l.17-.12.09-.07c.05,0,.07-.1.17-.11h0a1.18,1.18,0,0,0,.76-1.31A6.35,6.35,0,0,0,41,88.72Z"
                            />
                            <path
                                class="cls-1"
                                d="M75.67,35.26c2.2-.67,4.39-1.33,6.59-2,.34-.1.39-.23.27-.56-1-2.51-1.9-5-3-7.44a1.08,1.08,0,0,1-.05-1A6.67,6.67,0,0,0,80,20.71c-.08-.63,0-1.27,0-1.92a44.21,44.21,0,0,0-1.15-5.07,33.58,33.58,0,0,0-2.2-5.35,37.89,37.89,0,0,0-2-3.46c-.38-.67-.83-1.3-1.19-2A3,3,0,0,0,72,1.42c-.19-.09-.42-.25-.56-.07a.83.83,0,0,0-.22.83c.24.58.5,1.16.74,1.74a31.58,31.58,0,0,1,1.9,4.88,14,14,0,0,1,.38,2c0,.25,0,.52-.26.62s-.29-.2-.43-.34c-.49-.54-1.14-1.07-1.9-.75a1.24,1.24,0,0,1-.72.07c-.16,0-.37-.08-.41-.26s.13-.29.27-.39a1.85,1.85,0,0,0,.39-.25c.16-.15.28-.35.11-.57A9,9,0,0,0,70,7.44C69,6.61,67.9,5.8,66.77,5.07l-.49-.31c-2-1.2-4.08-2.32-6.19-3.35a1.65,1.65,0,0,0-.91-.23c-.21,0-.45,0-.55.25a.66.66,0,0,0,.11.69,3.31,3.31,0,0,0,.79.72,24.78,24.78,0,0,1,2.71,1.58C63.88,5.68,65.5,7,67.09,8.27c.5.43,1,.88,1.42,1.35l.82.85a.78.78,0,0,1,.2.33.06.06,0,0,1,0,0,.3.3,0,0,1,0,.1.43.43,0,0,1-.14.25c-.26.26-.52.13-.78,0a1.61,1.61,0,0,1-.27-.27l-.13-.13c-.22-.22-.42-.44-.64-.64l-.28-.23L63.62,7.16,60,4.41a12.51,12.51,0,0,0-2.2-1.33.44.44,0,0,0-.62.11A.73.73,0,0,0,57,4a3.89,3.89,0,0,0,1,1.27,20,20,0,0,1,1.58,1.45c2.29,2.54,4.63,5,6.85,7.66a1.21,1.21,0,0,1,.28.61c.07.44-.15.62-.57.48L66,15.39a89.44,89.44,0,0,1-8.06-4.94,13.58,13.58,0,0,0-2.4-1.33c-.26-.12-.55-.26-.76.07a.75.75,0,0,0,.2.9c1,.74,1.89,1.58,2.82,2.39C59.83,14.3,62,16,63.57,18.34a1.28,1.28,0,0,0,1.41.25,5.27,5.27,0,0,1,3-.91h.26a.3.3,0,0,1,.2.05.38.38,0,0,1,.07.1c.12.26-.16.33-.32.43-1,.64-2,1.27-3,1.92a.82.82,0,0,1-.75.13A5.22,5.22,0,0,0,63.09,20,44.08,44.08,0,0,0,57,20.6a3.66,3.66,0,0,0-1.32.36.61.61,0,0,0-.29.66c0,.21.08.44.38.49,1.27.24,2.52.51,3.79.78a8.52,8.52,0,0,0,1.38.27c1.45.9,2.87,1.83,4.25,2.85a6.5,6.5,0,0,0,2.79,1.24c.48.08,1,.22,1.42.34a5.06,5.06,0,0,1,1.83.52,4.53,4.53,0,0,1,1,1.64c.17.36.39.54.8.44s.47.09.58.39c.51,1.46,1,2.92,1.61,4.4C75.26,35.27,75.36,35.36,75.67,35.26Z"
                            />
                            <path
                                class="cls-1"
                                d="M59.79,48a.36.36,0,0,0,.41.42c.38,0,.78,0,1.16,0a15,15,0,0,1,4.14.19,6.67,6.67,0,0,1,1.51.46,29.36,29.36,0,0,1,3.07,1.62,4.63,4.63,0,0,0,.84.47h0l.15.06c-.81-1.28-1.67-2.4-2.53-3.52a9.23,9.23,0,0,0-2-1.85,1.27,1.27,0,0,0-.51-.35,24.94,24.94,0,0,0-3.51-1.18l-.07,0a4.32,4.32,0,0,0-2.73.14c-.19.07-.32.15-.25.37A10.44,10.44,0,0,1,59.79,48Z"
                            />
                            <path class="cls-1" d="M67.51,53.47l.07,0h0Z" />
                            <path
                                class="cls-1"
                                d="M63.49,52h0c0-.07.1-.05.15-.09h0l-.13,0S63.48,51.95,63.49,52Z"
                            />
                            <path
                                class="cls-1"
                                d="M72.69,72.15a7.61,7.61,0,0,0,.87-1.7,2.49,2.49,0,0,0,.11-.25,3.48,3.48,0,0,0,.33-1.1v0c0-.12.05-.28-.08-.33a2.08,2.08,0,0,0-.63-.1l-.25,0-.12,0-.07,0s0,0,0,0,.09.27,0,.4,0,.26,0,.38a4,4,0,0,1-.14.38,4.76,4.76,0,0,1-.25.54,7.4,7.4,0,0,1-1.33,1.71,1.42,1.42,0,0,1,0-1.19l.05-.12c.11-.24.25-.47.38-.7,0-.08.11-.14.15-.22s0,0,0,0a.34.34,0,0,0,0-.11,2.07,2.07,0,0,0-.68-1,1.87,1.87,0,0,0-.31-.23.89.89,0,0,0-.27-.11l-.42,0a7.7,7.7,0,0,1-1.14-.17l-.1,0c-.59-.19-1.16-.39-1.73-.63l-.56-.25a14.63,14.63,0,0,1-2.13-1.21l-1.5-1-1-.7c-.49-.36-1-.72-1.45-1.1l-.1-.08L60.15,63l-.21-.15a1.09,1.09,0,0,1-.27-.27l-.13-.17-.13-.17a7.61,7.61,0,0,1-1.7-2.61,11,11,0,0,1-1.27,2.2,8.36,8.36,0,0,1-.63.74,7.52,7.52,0,0,1-3.32,2,9.61,9.61,0,0,1-2.72.36l.75-.62.23-.21A17.44,17.44,0,0,0,53,62l.1-.07a.27.27,0,0,0,.09-.15v-.05h0a.43.43,0,0,0-.25.15c-.63.37-1.29.71-1.94,1.06l-.28.15-.5.25-.84.38A15.94,15.94,0,0,1,45,64.88l-2.46.25q-1.23.11-2.46.2l-1.64.09h-.72l-.48,0c-.16,0-.33,0-.48.07l-.24.05A18.72,18.72,0,0,0,32.68,67c-.34.17-.67.36-1,.56s-.43.27-.63.43l-.31.23a2.09,2.09,0,0,0-.58.64.66.66,0,0,0-.05.13s0,0,0,.07l0,.14a1.58,1.58,0,0,0,0,.23,1.74,1.74,0,0,0,.08.48l.16.39c.12.29.23.59.33.89a24.09,24.09,0,0,0,1.75,3,3.9,3.9,0,0,0,.27.41l.11.07a2.08,2.08,0,0,0,.6.38h0a2.86,2.86,0,0,0,1.15.22,1,1,0,0,1,1,.56l0,.09a7.18,7.18,0,0,0,2.82,3.37l.27.17.27.16a12.67,12.67,0,0,1,1.1.71l.35.25a12.68,12.68,0,0,1,1.31,1.12L42,82c.4.4.8.83,1.18,1.26.1.1.19.21.28.32s.38.43.57.64a12.37,12.37,0,0,1,1.26,1.67c0,.08.1.15.14.24a8.18,8.18,0,0,1,.41.88,2.87,2.87,0,0,0,1.06,1.27,8.48,8.48,0,0,0,.73.48q.29.18.59.33c.28.14.55.31.83.46a3.09,3.09,0,0,0,.66.27l.13,0,.1,0a9.81,9.81,0,0,0,2.65.08l.8-.11.74-.12h.09L55,89.6c.62-.13,1.24-.28,1.86-.47l.59-.19.17-.05.56-.21.2-.08.24-.1.29-.13c.26-.12.51-.24.78-.38s.63-.36,1-.56l.47-.33a7.69,7.69,0,0,0,1.15-1c.16-.17.32-.35.47-.55a17.13,17.13,0,0,0,1.85-3c.1-.19.2-.37.28-.57s.27-.58.4-.87l.1-.24a14,14,0,0,0,.38-1.55l-.47.19c-.23.1-.45.2-.67.27a2.78,2.78,0,0,1-.68.15h-.19a.51.51,0,0,1-.54-.36c-.09-.25,0-.35.21-.42l.14,0,.09,0,.15-.07.16-.07A8.87,8.87,0,0,0,66,78c.39-.29.78-.6,1.14-.93.14-.13.28-.26.41-.4A7,7,0,0,0,69,74.46l0-.08c.09-.17.19-.33.26-.5a.39.39,0,0,1,.39-.26c.17,0,.35-.05.52-.05h.28A2.85,2.85,0,0,0,72.69,72.15ZM33.9,73.6c-.24.05-.25-.26-.33-.43a2.22,2.22,0,0,0-1-1,2.24,2.24,0,0,1-1.27-2.51.71.71,0,0,1,.51-.52c.2-.08.27.16.38.27a3.29,3.29,0,0,1,.61,1.4,1.59,1.59,0,0,0,.63.92A1.48,1.48,0,0,1,34,73.13C33.94,73.25,34.14,73.55,33.9,73.6Zm3.59-4.1-.09,0a7.16,7.16,0,0,1,2.2-2.13c.11-.09.24-.05.37,0,2.62.15,5.22.42,7.82.82a1.84,1.84,0,0,0,1.9-.7,16.29,16.29,0,0,0,.94-1.33c.12-.22.29-.49.57-.4s.34.37.31.71a4.28,4.28,0,0,1-1.86,3.19c-.15.11-.15.17,0,.29A6.46,6.46,0,0,1,51,73.82a3.31,3.31,0,0,1-.37,1.88.46.46,0,0,0,.14.66,10.51,10.51,0,0,1,.81.76.49.49,0,0,0,.72,0,2.91,2.91,0,0,0,.51-.52,7.35,7.35,0,0,1,1.74-1.7A1,1,0,0,1,55.8,75c.14.17.33.38-.1.52A3.27,3.27,0,0,0,54.22,77c-.28.41-.54.85-.8,1.28a1.72,1.72,0,0,1-2.66.37,7.3,7.3,0,0,1-1-1A2,2,0,0,0,48,76.95a2.53,2.53,0,0,1,.91-1.27A1.89,1.89,0,0,0,49.55,74a8.53,8.53,0,0,0-.47-2.57,2.29,2.29,0,0,0-1-1.32,2,2,0,0,0-.71-.16c-1.8-.25-3.59-.61-5.41-.76a12.81,12.81,0,0,0-4.19.33Zm6.35,3.27a2.31,2.31,0,0,1-2.38-.39,2.12,2.12,0,0,0-2.25-.44.62.62,0,0,1-.63-.14c-.33-.25-.31-.46.07-.63a8.9,8.9,0,0,1,1.61-.48,11.21,11.21,0,0,1,1.18.14,9.51,9.51,0,0,0,4,0,3.73,3.73,0,0,1,2,.07.74.74,0,0,1,.32.12c.15.14.4.27.36.49s-.32.14-.49.16c-.64.09-1.3.17-2,.24a1.45,1.45,0,0,0-.51.19A8.51,8.51,0,0,1,43.84,72.77ZM56,83.63a.36.36,0,0,1-.28-.05,6.57,6.57,0,0,0-2.85-.67.84.84,0,0,0-.46.05c-.79.31-1.57.61-2.35.94A2.22,2.22,0,0,0,48.8,85.5a9.11,9.11,0,0,1-.37,1.32c-.05.13-.12.29-.32.31s-.22-.16-.29-.27a3,3,0,0,1-.34-1.28,14.17,14.17,0,0,1,.39-1.74c.44-1,1.38-1.17,2.22-1.45a10.94,10.94,0,0,1,3.2-.56,3.29,3.29,0,0,1,2.89,1.35C56.37,83.44,56.34,83.55,56,83.63Zm1.51-3.47c-.41.16-.83.45-1.27,0-.14-.12-.29-.07-.45,0a13.51,13.51,0,0,0-3,1,2.08,2.08,0,0,1-2.18-.21,2,2,0,0,0-2.36-.14,3.23,3.23,0,0,1-2.56.36.78.78,0,0,1-.31-.14c-.39-.32-.39-.36,0-.64a3.45,3.45,0,0,0,.46-.32.83.83,0,0,1,.86-.17A1.53,1.53,0,0,0,48,79.56a2.52,2.52,0,0,1,2.84,0,.36.36,0,0,1,.11.07c.63.5,1.24.8,2,.09.29-.29.8-.17,1.2-.23a7.39,7.39,0,0,0,2.78-.62.22.22,0,0,1,.35.1c.15.27.42.47.45.82C57.71,80,57.69,80.09,57.52,80.16ZM63.58,73a.81.81,0,0,1-.73.23c-.38-.07-.78-.08-1.16-.11a2.65,2.65,0,0,1-1.45-.45,2,2,0,0,0-1.1-.31,3.76,3.76,0,0,1-1.65-.67.88.88,0,0,1-.37-.78c-.07-.73-.07-.74-.78-.91A3.83,3.83,0,0,1,54,68.51a2.9,2.9,0,0,1-.51-1.4c-.05-.46-.08-.92-.09-1.38,0-.13,0-.32.16-.36a.4.4,0,0,1,.41.17,1.69,1.69,0,0,1,.43.78,7.14,7.14,0,0,0,.23.83c.32,1,1.19,1.07,2,1.22a25.59,25.59,0,0,0,8.51.21.65.65,0,0,1,.67.15c.17.19.12.25-.08.32l-1.29.47a15.48,15.48,0,0,1-4.08,1,9.39,9.39,0,0,1-1.74-.25,1,1,0,0,0-.47,0,1.31,1.31,0,0,0,.67.92,3.09,3.09,0,0,0,1.67.59,18.34,18.34,0,0,0,3.29-.34,1.43,1.43,0,0,0,.51-.22c.61-.36,1.25-.7,1.89-1a.41.41,0,0,1,.54.05C65.73,71.21,64.66,72.12,63.58,73Z"
                            />
                            <path class="cls-1" d="M30.63,71.22v-.06Z" />
                            <path
                                class="cls-1"
                                d="M58.47,58.59v0a4.56,4.56,0,0,0,.92,1.28l.26.25a14,14,0,0,0,3.92,2.68,24.38,24.38,0,0,0,4,1.44,4.49,4.49,0,0,0,1.53.12,32.39,32.39,0,0,1,4.37-.31,33.25,33.25,0,0,1,4,.21l-.11-.09h0a3.28,3.28,0,0,0-1.7-.71,64,64,0,0,1-7.16-1.16A6.89,6.89,0,0,1,65.8,61q-1.88-1.59-3.72-3.24c-.59-.54-1.2-1-1.77-1.58a7,7,0,0,1-1.37-1.81c0-.07-.07-.1-.1-.11h0c-.06,0-.12,0-.15.14-.1.32-.2.63-.28,1A4.87,4.87,0,0,0,58.47,58.59Z"
                            />
                            <path
                                class="cls-1"
                                d="M59.5,52.82h0a.07.07,0,0,0,0,0s0,0,0,0,.08.19.11.27l.16.43c.09.23.19.47.28.7a1.55,1.55,0,0,0,.36.48A35.38,35.38,0,0,0,65,58.49a12.66,12.66,0,0,0,3,1.88c.93.34,1.83.74,2.8,1.08l.75.24h0a11.38,11.38,0,0,0,2.77.5c.14,0,.39.13.41-.19,0,0,0-.07,0-.1a.57.57,0,0,0-.08-.44l0-.07c0-.07,0-.13,0-.2a9,9,0,0,0-3.51-5.32L69.86,55a14.09,14.09,0,0,0-2-1.32l-.28-.14h0c-1.28-.59-3-.92-4.06-1.44l-.09,0a.63.63,0,0,1-.19-.15l-.05-.07c-.05-.05-.1-.1-.08-.11l.69.15a9.13,9.13,0,0,1,1.47.35l.45.12a21.65,21.65,0,0,1,4.94,2L72,55a.33.33,0,0,0,.23.06h0a.17.17,0,0,0,.09-.07c.08-.1,0-.19-.07-.26l-1-1.43a1.77,1.77,0,0,0-.54-.49c-1-.61-2-1.23-3-1.83a12.68,12.68,0,0,0-1.27-.66A4.58,4.58,0,0,0,64,49.6a10.15,10.15,0,0,0-1.74-.11l-.56,0-.34,0c-.37,0-.74,0-1.11,0s-.5.13-.49.5v1.21a.18.18,0,0,0,0,.08.14.14,0,0,0,0,.07s0,.05,0,.08,0,0,0,.07,0,.05,0,.08,0,0,0,.07,0,.05,0,.08,0,0,0,.07,0,.05,0,.08,0,0,0,.07,0,.05,0,.08,0,0,0,.07a.69.69,0,0,1,0,.08s0,0,0,.07l0,.09a.76.76,0,0,0,0,.47S59.5,52.81,59.5,52.82Z"
                            />
                            <path
                                class="cls-1"
                                d="M71.72,74.76c-.16-.13-.48.15-.73.24s-.32.11-.31.35A24.13,24.13,0,0,0,71,78.56a1,1,0,0,0,.05-.11l0,.2a2,2,0,0,0,.22-.75c.13-.76.25-1.52.39-2.28.05-.26.28-.61.09-.76l0,0Z"
                            />
                            <path
                                class="cls-1"
                                d="M35.31,82.11l1-2a.22.22,0,0,0-.05-.27l-.07-.07h0l-.51-.5c-.11-.1-.21-.12-.23.07A25.41,25.41,0,0,1,35.21,82s0,0,0,.05Z"
                            />
                            <path
                                class="cls-2"
                                d="M45.68,71.91c.66-.07,1.31-.15,2-.24.17,0,.45,0,.49-.16s-.21-.35-.36-.49a.74.74,0,0,0-.32-.12,3.73,3.73,0,0,0-2-.07,9.51,9.51,0,0,1-4,0,11.21,11.21,0,0,0-1.18-.14,8.9,8.9,0,0,0-1.61.48c-.37.17-.39.38-.07.63a.62.62,0,0,0,.63.14,2.12,2.12,0,0,1,2.25.44,2.31,2.31,0,0,0,2.38.39,8.51,8.51,0,0,0,1.33-.68A1.45,1.45,0,0,1,45.68,71.91Z"
                            />
                            <path
                                class="cls-2"
                                d="M88.29,40.61c.63-.22,1.26-.49,1.9-.69a.61.61,0,0,0,.48-.64c.21-2.75.42-5.52.63-8.27,0-.38,0-.46-.43-.34-2.06.66-4.13,1.28-6.2,1.92-.63.2-.64.2-.93-.43-1-2.36-1.87-4.81-2.73-7.23a1.79,1.79,0,0,1,0-1.44,6.82,6.82,0,0,0,.09-2.58.55.55,0,0,1,0-.13,41.72,41.72,0,0,0-1.16-7A27.39,27.39,0,0,0,77.68,8c-1-2-2.15-3.91-3.35-5.8a4.59,4.59,0,0,0-2-1.94,3.19,3.19,0,0,0-1-.22.92.92,0,0,0-.9.43,1.89,1.89,0,0,0-.32,2c.86,1.87,1.65,3.78,2.4,5.69,0,.09.1.17.17.31a.31.31,0,0,1-.28-.2,30.57,30.57,0,0,0-4.54-3.66A58.26,58.26,0,0,0,61,.56a2.63,2.63,0,0,0-1-.29L58.33.08a1.32,1.32,0,0,0-1.62,1.33c0,.49-.21.6-.61.63a1.23,1.23,0,0,0-.9.87,3.16,3.16,0,0,0,1,2.82c2,1.89,4,3.84,5.93,5.8l.07,0a.43.43,0,0,1,.13.17h-.09a.26.26,0,0,1-.16-.1s0,0,0,0c-.28-.16-.58-.32-.85-.5-1.37-.91-2.71-1.83-4.07-2.72a4.29,4.29,0,0,0-2.1-.78,2.06,2.06,0,0,0-1.78.66,1.28,1.28,0,0,0-.4,1.15,2,2,0,0,0,1,1.42,37.16,37.16,0,0,1,6.21,5.34,5.74,5.74,0,0,0,.52.51,5.13,5.13,0,0,1,1.19,1.62c.15.27.1.34-.2.34a27.55,27.55,0,0,0-5.67.93,2.07,2.07,0,0,0-1.79,1.28c-.29,1-.44,1.49.73,1.78A43.54,43.54,0,0,1,61.68,25a2.16,2.16,0,0,1,.54.35,15,15,0,0,0,1.65,1.38,17.69,17.69,0,0,0,5.55,2.65c.24.05.46.17.69.23a.54.54,0,0,1,.43.43,1.79,1.79,0,0,0,1.39,1.5c.1,0,.17.1.27.13a.65.65,0,0,1,.43.49c.31,1.09.62,2.17,1,3.25.12.36,0,.46-.32.56-1.69.49-3.37,1-5.06,1.52-.6.19-.61.2-.31.74L72,45.66c.58,1,.6,1,1.66.5.11-.05.26-.24.36-.07s.27.4.11.59a20.41,20.41,0,0,0-1.3,1.91.41.41,0,0,0,0,.54c.46.75.92,1.52,1.37,2.28.05.09.15.2.13.26-.17.56-.37,1.11-.56,1.67a11.54,11.54,0,0,0-1.44-3.25,45.76,45.76,0,0,0-2.82-3.69c-.15-.19-.33-.35-.5-.52a14.76,14.76,0,0,0-3.18-2.17,4.67,4.67,0,0,0-1.55-.58,9.92,9.92,0,0,0-5.09,0,.57.57,0,0,1-.74-.27,8,8,0,0,0-1.31-1.69,14.91,14.91,0,0,0-4.49-2.65,13.42,13.42,0,0,0-3.93-.76,19.43,19.43,0,0,0-2.11.08,11.07,11.07,0,0,0-5.19,1.33c-.32.2-.68.31-1,.49a19.76,19.76,0,0,0-4.62,3.09C34.39,44.14,33,45.53,31.71,47a27.73,27.73,0,0,0-3.56,5.77.73.73,0,0,1-.32.44c-.19-1.16-.37-2.27-.55-3.39,0-.21.1-.2.24-.17.4,0,.8.07,1.2.12s.47,0,.55-.36.21-.94.31-1.42c.37-1.8.91-3.55,1.38-5.32.09-.34,0-.46-.32-.55-1.74-.42-3.47-.87-5.21-1.29-.33-.08-.48-.2-.38-.55a41.28,41.28,0,0,1,1.1-4.1.81.81,0,0,1,.25-.39,1.55,1.55,0,0,0,.73-1.38.92.92,0,0,1,.63-1c.83-.39,1.63-.85,2.41-1.31a3.82,3.82,0,0,0,1.49-1.52,84.32,84.32,0,0,1,4.46-8.23,4.89,4.89,0,0,1,.46-.68,43,43,0,0,1,3.51-3.55,1.62,1.62,0,0,0,.52-1.3,2.12,2.12,0,0,0-.69-1.39,1.42,1.42,0,0,0-1.27-.67,1.82,1.82,0,0,1-.4-.07c.09-.17.23-.22.35-.29l4.62-3c1.87-1.2,3.72-2.41,5.6-3.62.24-.15.35-.27.09-.5a1.42,1.42,0,0,1-.16-.2c-.38-.45-.38-.45-.91-.13L32.18,16.79c-.46.28-.46.28-.69-.23a36.06,36.06,0,0,1-1.19-3.68.5.5,0,0,1,.21-.62c1.31-1,2.51-2.23,3.72-3.37a2.75,2.75,0,0,0,.85-1.68c.1-.78-.42-1.18-1.11-.9a7.77,7.77,0,0,0-1,.48,47.41,47.41,0,0,1-9.77,3.86c-.2.05-.37.12-.54-.09a6,6,0,0,0-1.27-1,.33.33,0,0,0-.28-.07,1.93,1.93,0,0,0-1.21.67c-.72,1.06-1.63,2-2.3,3.1-.78,1.28-1.52,2.56-2.39,3.77-.16.23-.23.26-.38,0L11.93,12a12.91,12.91,0,0,0-1-1.54,1.72,1.72,0,0,0-1.63-.72c-.12,0-.27,0-.32.16A5,5,0,0,0,8.7,11.4a29.78,29.78,0,0,0,.68,3.67c.52,2.09,1.11,4.15,1.74,6.2s1.28,4,1.93,6c.05.17.15.33-.09.47s-.8.26-.85.57.23.69.36,1l0,.08c.11.26.16.66.36.75s.5-.23.74-.37.29-.1.39.13c.57,1.33,1.15,2.65,1.73,4a.82.82,0,0,1,0,.62,18.82,18.82,0,0,0-.87,3.28c-.05.32-.17.32-.41.25l-3.79-1c-.56-.14-.56-.14-.62.43v0q-.41,4.54-.83,9.08c0,.27,0,.38.31.41.88.11,1.76.25,2.63.38.16,0,.31,0,.26.27-.2,1-.35,2.06-.57,3.08a.81.81,0,0,0,.15.74c.31.39.6.8.91,1.2a.87.87,0,0,1,.17,1,.91.91,0,0,0-.15.54c0,1.89,0,3.78.12,5.67,0,.92,0,1.83.05,2.75,0,2.44.19,4.86.27,7.3,0,1.19-.16,2.37-.11,3.56,0,.29.08.46.38.56.72.23,1.42.52,2.15.75a1.27,1.27,0,0,1,.84.71,2,2,0,0,1,.17,1,.75.75,0,0,0,.37.71c1.12.81,2.24,1.64,3.36,2.47,3,2.18,5.92,4.38,8.89,6.55.27.21.34.37.17.67s-.25.61-.4.9a.41.41,0,0,0,.14.61,13.5,13.5,0,0,1,1.07.85.9.9,0,0,1,.22,1c-.07.22-.39,0-.6,0s-.28,0-.43-.07c-1.41-.23-2.81-.59-4.24-.71a62.62,62.62,0,0,0-6.87-.32c-.12,0-.31-.11-.34.13s-.08.4.14.54a2,2,0,0,0,.35.16,21.82,21.82,0,0,1,3.67,1.77A14.61,14.61,0,0,0,24.7,93c.15.05.31.17.49,0l-3.79-3a.53.53,0,0,1,.45-.07,29.6,29.6,0,0,1,4.5.68q4.87,1.16,9.65,2.61a10.85,10.85,0,0,1,3.1,1.1.6.6,0,0,1,.34.59c.05.07.12.15,0,.21s-.16-.05-.23-.11c-.74-.07-1.49-.12-2.22-.2a49.06,49.06,0,0,0-6.33-.44c-1.59,0-3.19-.07-4.77,0-2.25.15-4.5.45-6.74.69-.11,0-.28,0-.28.12a.36.36,0,0,0,.27.39,2.63,2.63,0,0,0,.51.05c1.14,0,2.26,0,3.4.05,2.82.07,5.65-.05,8.46.19,1,.09,2,0,3,.23,4.69.87,9.35,1.79,14,2.81a7,7,0,0,1,1.64.47c-.25.23-.58.29-.72.62l12.92-.22a10.25,10.25,0,0,0-.81-.88l.17-.12a59.75,59.75,0,0,1,11.26-4.87c4.73-1.63,9.56-2.93,14.39-4.17l-.34-.08-.94.09a23.19,23.19,0,0,0-4,.61l-.08,0a1,1,0,0,1-.43.07h-.22c.29-.28,1.15-1.2,1.38-1.14v0h0s.09-.1.09-.1a.42.42,0,0,1,.34-.23,3.16,3.16,0,0,1,.9-.85,5.22,5.22,0,0,1,.73-.39h0c.73,0,1.45-.88,2.21-1.19,0,0,0,0-.06-.08a14.85,14.85,0,0,0-3.21.72c-2.24.83-4.55,1.47-6.74,2.44-3.37,1.47-6.74,2.95-10,4.71l-.35.16c-.09-.79-.16-1.54-.25-2.29,0-.15.05-.22.19-.28,2.87-1.52,5.76-3,8.76-4.27,2.47-1,4.91-2.14,7.39-3.15,0,0,0,0,0,0h0a.08.08,0,0,1,0,.12l0,0h0a15.28,15.28,0,0,0-1.69,3,.27.27,0,0,0,.31-.08c.51-.55,1-1.08,1.53-1.63A18.87,18.87,0,0,1,86.25,83c.08-.05.21-.1.15-.22s-.21-.07-.31,0c-1.12.23-2.25.44-3.36.7-.37.09-.35,0-.36-.31,0-.9.12-1.77.15-2.66a2.87,2.87,0,0,1,.26-1.12c.45-1,.9-2,1.35-3.07a6.39,6.39,0,0,0,.45-1.61c.14-.87.25-1.76.34-2.64.14-1.35.62-2.63.85-4A25.85,25.85,0,0,1,87,63c.57-1.44,1.11-2.88,1.69-4.31a38.66,38.66,0,0,0,2.29-5.86,3,3,0,0,0,0-2.09,9,9,0,0,1-.37-1.23,1.78,1.78,0,0,1-.05-.93,4.48,4.48,0,0,0-.28-3.25c-.16-.28,0-.46.2-.63.4-.42.43-.6.08-1s-.8-1-1.23-1.49-.7-.8-1.06-1.19C88,40.81,88,40.71,88.29,40.61Zm-14.73-10c-.11-.31-.24-.47-.58-.39s-.62-.08-.8-.44a4.53,4.53,0,0,0-1-1.64,5.06,5.06,0,0,0-1.83-.52c-.47-.12-.94-.26-1.42-.34A6.5,6.5,0,0,1,65.15,26c-1.38-1-2.8-2-4.25-2.85a8.52,8.52,0,0,1-1.38-.27c-1.27-.26-2.52-.54-3.79-.78-.31-.05-.36-.28-.38-.49a.61.61,0,0,1,.29-.66A3.66,3.66,0,0,1,57,20.6,44.08,44.08,0,0,1,63.09,20a5.22,5.22,0,0,1,1.42.29.82.82,0,0,0,.75-.13c1-.66,2-1.28,3-1.92.15-.1.44-.16.32-.43a.38.38,0,0,0-.07-.1.3.3,0,0,0-.2-.05H68a5.27,5.27,0,0,0-3,.91,1.28,1.28,0,0,1-1.41-.25c-1.55-2.35-3.75-4-5.83-5.86-.93-.81-1.83-1.65-2.82-2.39a.75.75,0,0,1-.2-.9c.22-.33.5-.19.76-.07a13.58,13.58,0,0,1,2.4,1.33A89.44,89.44,0,0,0,66,15.39l.23.12c.42.14.63,0,.57-.48a1.21,1.21,0,0,0-.28-.61c-2.22-2.61-4.55-5.11-6.85-7.66A20,20,0,0,0,58,5.32,3.89,3.89,0,0,1,57,4a.73.73,0,0,1,.11-.86.44.44,0,0,1,.62-.11A12.51,12.51,0,0,1,60,4.41l3.66,2.75L67.28,9.9l.28.23c.23.21.43.43.64.64l.13.13a1.61,1.61,0,0,0,.27.27c.25.15.51.28.78,0a.43.43,0,0,0,.14-.25.3.3,0,0,0,0-.1.06.06,0,0,0,0,0,.78.78,0,0,0-.2-.33l-.82-.85c-.46-.47-.92-.93-1.42-1.35C65.5,7,63.88,5.68,62.24,4.43a24.78,24.78,0,0,0-2.71-1.58,3.31,3.31,0,0,1-.79-.72.66.66,0,0,1-.11-.69c.1-.24.34-.23.55-.25a1.65,1.65,0,0,1,.91.23c2.11,1,4.18,2.15,6.19,3.35l.49.31C67.9,5.8,69,6.61,70,7.44a9,9,0,0,1,1.29,1.5c.17.22.05.41-.11.57a1.85,1.85,0,0,1-.39.25c-.14.1-.33.19-.27.39s.25.23.41.26a1.24,1.24,0,0,0,.72-.07c.76-.32,1.41.22,1.9.75.13.14.19.43.43.34s.28-.37.26-.62a14,14,0,0,0-.38-2A31.58,31.58,0,0,0,72,3.92c-.24-.58-.5-1.16-.74-1.74a.83.83,0,0,1,.22-.83c.14-.19.37,0,.56.07a3,3,0,0,1,1.42,1.51c.36.69.81,1.32,1.19,2a37.89,37.89,0,0,1,2,3.46,33.58,33.58,0,0,1,2.2,5.35A44.21,44.21,0,0,1,80,18.79c.08.66,0,1.29,0,1.92a6.67,6.67,0,0,1-.56,3.63,1.08,1.08,0,0,0,.05,1c1.15,2.42,2.1,4.93,3,7.44.12.33.07.46-.27.56-2.2.64-4.39,1.31-6.59,2-.32.1-.42,0-.51-.27C74.6,33.5,74.07,32,73.55,30.59ZM59.77,44.43a4.32,4.32,0,0,1,2.73-.14l.07,0a24.94,24.94,0,0,1,3.51,1.18,1.27,1.27,0,0,1,.51.35,9.23,9.23,0,0,1,2,1.85c.86,1.11,1.73,2.24,2.53,3.52l-.15-.06h0a4.63,4.63,0,0,1-.84-.47A29.36,29.36,0,0,0,67,49.05a6.67,6.67,0,0,0-1.51-.46,15,15,0,0,0-4.14-.19c-.38,0-.78,0-1.16,0a.36.36,0,0,1-.41-.42,10.44,10.44,0,0,0-.27-3.19C59.45,44.59,59.59,44.5,59.77,44.43Zm-.28,7.88,0-.09s0,0,0-.07a.69.69,0,0,0,0-.08s0,0,0-.07,0-.05,0-.08,0,0,0-.07,0-.05,0-.08,0,0,0-.07,0-.05,0-.08,0,0,0-.07,0-.05,0-.08,0,0,0-.07,0-.05,0-.08a.14.14,0,0,1,0-.07.18.18,0,0,1,0-.08V50c0-.37.12-.51.49-.5s.74,0,1.11,0l.34,0,.56,0A10.15,10.15,0,0,1,64,49.6a4.58,4.58,0,0,1,2.5.74,12.68,12.68,0,0,1,1.27.66c1,.6,2,1.22,3,1.83a1.77,1.77,0,0,1,.54.49l1,1.43c.05.08.14.16.07.26a.17.17,0,0,1-.09.07h0A.33.33,0,0,1,72,55l-1.35-.74a21.65,21.65,0,0,0-4.94-2l-.45-.12a9.13,9.13,0,0,0-1.47-.35l-.69-.15s0,.05.08.11l.05.07a.63.63,0,0,0,.19.15l.09,0c1,.52,2.78.85,4.06,1.44h0l-.07,0-.43-.2L67,53.21h0l.12.05.43.2.05,0h0l.28.14a14.09,14.09,0,0,1,2,1.32l1.22.94a9,9,0,0,1,3.51,5.32c0,.07,0,.13,0,.2l0,.07a.57.57,0,0,1,.08.44s0,.07,0,.1c0,.32-.27.19-.41.19a11.38,11.38,0,0,1-2.77-.5h0l-.75-.24c-1-.34-1.87-.74-2.8-1.08a12.66,12.66,0,0,1-3-1.88,35.38,35.38,0,0,1-4.55-3.71,1.55,1.55,0,0,1-.36-.48c-.1-.23-.2-.47-.28-.7l-.16-.43c0-.09-.07-.17-.11-.27s0,0,0,0a.07.07,0,0,1,0,0h0s0,0,0,0A.76.76,0,0,1,59.49,52.31Zm6.87.67-.1,0h0Zm-.14-.05h0L66,52.84l-.09,0,.09,0,.22.08Zm-2.17-.71-.07,0Zm-.4-.26c-.05,0-.13,0-.15.09h0c0-.09,0-.12,0-.13l.13,0Zm-4.47-7.2a.39.39,0,0,0,0,.14A.39.39,0,0,1,59.18,44.75Zm-.5,9.67c0-.1.09-.16.15-.14h0s.07,0,.1.11a7,7,0,0,0,1.37,1.81c.57.55,1.18,1,1.77,1.58Q63.91,59.44,65.8,61a6.89,6.89,0,0,0,2.82,1.31,64,64,0,0,0,7.16,1.16,3.28,3.28,0,0,1,1.7.71h0l.11.09a33.25,33.25,0,0,0-4-.21,32.39,32.39,0,0,0-4.37.31,4.49,4.49,0,0,1-1.53-.12,24.38,24.38,0,0,1-4-1.44,14,14,0,0,1-3.92-2.68l-.26-.25a4.56,4.56,0,0,1-.92-1.28v0a4.87,4.87,0,0,1-.07-3.22C58.48,55,58.58,54.73,58.68,54.42ZM70.53,73.56h-.28c-.17,0-.35,0-.52.05a.39.39,0,0,0-.39.26c-.08.17-.17.33-.26.5l0,.08a7,7,0,0,1-1.44,2.18c-.13.14-.27.27-.41.4-.36.33-.74.63-1.14.93a8.87,8.87,0,0,1-2.13,1l-.16.07-.15.07-.09,0-.14,0c-.16.07-.29.16-.21.42a.51.51,0,0,0,.54.36h.19a2.78,2.78,0,0,0,.68-.15c.22-.08.44-.17.67-.27l.47-.19a14,14,0,0,1-.38,1.55l-.1.24c-.13.29-.26.58-.4.87s-.19.38-.28.57a17.13,17.13,0,0,1-1.85,3c-.15.2-.31.37-.47.55a7.69,7.69,0,0,1-1.15,1l-.47.33q-.48.29-1,.56c-.26.14-.51.26-.78.38l-.29.13-.24.1-.2.08-.56.21-.17.05-.59.19c-.61.19-1.23.34-1.86.47l-.74.14h-.09l-.74.12-.8.11a9.81,9.81,0,0,1-2.65-.08l-.1,0-.13,0a3.09,3.09,0,0,1-.66-.27c-.28-.15-.55-.32-.83-.46s-.39-.21-.59-.33a8.48,8.48,0,0,1-.73-.48A2.87,2.87,0,0,1,45.84,87a8.18,8.18,0,0,0-.41-.88c0-.09-.1-.16-.14-.24A12.37,12.37,0,0,0,44,84.25c-.19-.22-.37-.44-.57-.64s-.19-.22-.28-.32c-.38-.43-.78-.85-1.18-1.26l-.31-.31a12.68,12.68,0,0,0-1.31-1.12L40,80.35a12.67,12.67,0,0,0-1.1-.71l-.27-.16-.27-.17a7.18,7.18,0,0,1-2.82-3.37l0-.09a1,1,0,0,0-1-.56,2.86,2.86,0,0,1-1.15-.22h0a2.08,2.08,0,0,1-.6-.38l-.11-.07a3.9,3.9,0,0,1-.27-.41,24.09,24.09,0,0,1-1.75-3v0l0-.06v0c-.1-.3-.21-.6-.33-.89l-.16-.39a1.74,1.74,0,0,1-.08-.48,1.58,1.58,0,0,1,0-.23l0-.14s0,0,0-.07a.66.66,0,0,1,.05-.13,2.09,2.09,0,0,1,.58-.64L31,68c.21-.15.43-.28.63-.43s.66-.38,1-.56a18.72,18.72,0,0,1,3.9-1.43l.24-.05c.15,0,.32,0,.48-.07l.48,0h.72l1.64-.09q1.23-.08,2.46-.2L45,64.88a15.94,15.94,0,0,0,4.28-1.09l.84-.38.5-.25L51,63c.66-.35,1.31-.69,1.94-1.06a.43.43,0,0,1,.25-.15h0v.05a.27.27,0,0,1-.09.15L53,62a17.44,17.44,0,0,1-2.26,2l-.23.21-.75.62a9.61,9.61,0,0,0,2.72-.36,7.52,7.52,0,0,0,3.32-2,8.36,8.36,0,0,0,.63-.74,11,11,0,0,0,1.27-2.2,7.61,7.61,0,0,0,1.7,2.61l.13.17.13.17a1.09,1.09,0,0,0,.27.27l.21.15.21.15.1.08c.48.38,1,.74,1.45,1.1l1,.7,1.5,1a14.63,14.63,0,0,0,2.13,1.21l.56.25c.57.24,1.14.45,1.73.63l.1,0a7.7,7.7,0,0,0,1.14.17l.42,0a.89.89,0,0,1,.27.11,1.87,1.87,0,0,1,.31.23,2.07,2.07,0,0,1,.68,1,.34.34,0,0,1,0,.11s0,0,0,0-.11.14-.15.22c-.13.23-.27.46-.38.7L71.1,71a1.42,1.42,0,0,0,0,1.19,7.4,7.4,0,0,0,1.33-1.71,4.76,4.76,0,0,0,.25-.54,4,4,0,0,0,.14-.38c0-.12,0-.26,0-.38s-.11-.32,0-.4,0,0,0,0l.07,0,.12,0,.25,0a2.08,2.08,0,0,1,.63.1c.13,0,.09.21.08.33v0a3.48,3.48,0,0,1-.33,1.1,2.49,2.49,0,0,1-.11.25,7.61,7.61,0,0,1-.87,1.7A2.85,2.85,0,0,1,70.53,73.56Zm1.19,2.05c-.14.76-.26,1.52-.39,2.28a2,2,0,0,1-.22.75l0-.2a1,1,0,0,1-.05.11,24.13,24.13,0,0,1-.34-3.21c0-.24.15-.29.31-.35s.57-.37.73-.24l.05.07,0,0C72,75,71.77,75.35,71.72,75.61ZM55.57,91.82a8,8,0,0,1-1.25.1,5.58,5.58,0,0,1-1.27-.14.34.34,0,0,1-.29-.39c0-.12.1-.12.19-.12a.47.47,0,0,1,.17,0h1.19a5.19,5.19,0,0,0,1.08-.11.55.55,0,0,1,.19,0c.14,0,.25,0,.26.24S55.88,91.78,55.57,91.82ZM35.21,82h0a25.41,25.41,0,0,0,.25-2.73c0-.19.12-.16.23-.07l.51.5h0l.07.07a.22.22,0,0,1,.05.27l-1,2-.11,0s0,0,0-.05ZM70.36,66.89a8.15,8.15,0,0,0-1.16-.11A4.13,4.13,0,0,1,67.15,66h.08L67.07,66l.34,0c.13,0,.25,0,.38.07a10.18,10.18,0,0,0,3.2-.2,4.82,4.82,0,0,1,3,.81h-.05l.14.08A14.42,14.42,0,0,1,70.36,66.89Zm-40.9-14a21.08,21.08,0,0,1,1.19-2c.22-.32.44-.63.67-.94l.35-.46q.52-.69,1.08-1.34l1.13-1.31c.38-.44.76-.86,1.14-1.3a4.17,4.17,0,0,1,.52-.45l.12-.13c.36-.31.67-.63,1.08-1l.05,0,.31-.28a23.4,23.4,0,0,1,3.63-2.65l.39-.23.5-.22.13-.05q.39-.16.79-.29l.54-.16c.63-.19,1.27-.34,1.89-.54a11.3,11.3,0,0,1,3.56-.52H49a7.5,7.5,0,0,1,2.59.75c.36.16.72.32,1.08.49l.26.13c.26.13.54.26.79.42l.51.29c.16.11.34.21.49.33a8.83,8.83,0,0,1,.94.75,7.55,7.55,0,0,1,2.11,3.28,12.47,12.47,0,0,1,.59,2.81A7.9,7.9,0,0,1,58,51c0,.13-.09.16-.13.15s-.1-.1-.15-.16l-1-1.14A9.57,9.57,0,0,0,52,46.76a18.92,18.92,0,0,0-4.52-.7,17.41,17.41,0,0,0-3.66.41c-1,.19-1.92.34-2.87.51a7.72,7.72,0,0,0-1.76.64c-.27.12-.54.24-.82.34l-.08,0a22.63,22.63,0,0,0-4.66,2.6,7.3,7.3,0,0,0-1.1,1l0,0-.29.29c-.69.67-1.37,1.34-2.11,2a9.87,9.87,0,0,1-1.22,1.21A6.43,6.43,0,0,1,29.47,52.93Zm-.3,4.38a1.3,1.3,0,0,1,.19-.24A55.17,55.17,0,0,1,34,52.68,23,23,0,0,1,43.35,48a12.18,12.18,0,0,1,2.6-.32c1,0,2,0,3-.08a9.38,9.38,0,0,1,5.31,1.47,9.25,9.25,0,0,1,1.65,1.29l.06.06a9.79,9.79,0,0,1,1.46,1.87,2.54,2.54,0,0,1,.14,1.88,8.6,8.6,0,0,1-2.7,4.49,24.12,24.12,0,0,1-4.11,2.95,15.48,15.48,0,0,1-6.54,2.17c-2.87.43-5.79.47-8.67.85-1,.13-2.11.22-3.16.4A4.87,4.87,0,0,0,29.31,67a10.61,10.61,0,0,0-.73,1.38.88.88,0,0,1,0-.16,2.4,2.4,0,0,1,.16-1.63,5.1,5.1,0,0,1,2.42-2.46c1.89-1,4-1.19,6-1.7,1.64-.41,3.32-.66,4.95-1.1a32.91,32.91,0,0,0,6.49-2.5,7.8,7.8,0,0,0,3-2.21A3.32,3.32,0,0,0,52.1,54c0-.15-.07-.23-.12-.24s-.13,0-.23.12a22.54,22.54,0,0,1-2.6,2,15.15,15.15,0,0,1-4.72,1.91,47.7,47.7,0,0,1-8,1.41,22,22,0,0,0-5.64,1.1,11.68,11.68,0,0,0-4.37,2.23,7.35,7.35,0,0,1-.59.45l0-.17-.12.09v0l.11-.08a2.73,2.73,0,0,1,.38-.91Q27.68,59.64,29.16,57.31Zm10.9,2.87,2.38-.39.41-.08a5.66,5.66,0,0,1-1.56.49c-2.54.63-5.14,1-7.72,1.49a11.84,11.84,0,0,0-5,2.22,2.6,2.6,0,0,1-.28.2c-.12.08-.17.05-.2,0a.22.22,0,0,1,0-.09,1.08,1.08,0,0,1,.75-1.25c.82-.37,1.64-.76,2.46-1.15a10.53,10.53,0,0,1,3.37-.76C36.44,60.62,38.25,60.39,40.06,60.18ZM40,60.09h0ZM30.64,17.48c0,.12.05.22-.08.29l-1.17.72-.21.09a1.45,1.45,0,0,0-.14-.23l-2.46-2.82c-.11-.13-.22-.25,0-.37.81-.46,1.42-1.2,2.27-1.59.22-.1.29-.11.4.13C29.81,14.93,30.19,16.22,30.64,17.48ZM24,11.74c1.16-.42,2.29-.88,3.44-1.34A47,47,0,0,0,32.15,8l.48-.28c.14-.07.26-.26.45-.16s.14.35.14.61-.12.5-.37.73c-1.57,1.46-3.21,2.85-4.89,4.19a14.07,14.07,0,0,1-2.23,1.19c-.15.08-.24,0-.33-.11L23.78,12C23.57,11.78,23.85,11.79,24,11.74ZM14.08,26.68c-1.25-3.86-2.56-7.69-3.59-11.61-.24-.91-.34-1.86-.51-2.79a.47.47,0,0,1,.31-.51c.24-.12.25.16.34.27a70,70,0,0,1,4.28,7.59c.42.76.88,1.51,1.33,2.26.09.14.15.26.37.19s.2-.24.15-.41a15.14,15.14,0,0,0-.87-2.24.82.82,0,0,1,0-.73c.62-1.29,1.5-2.41,2.18-3.65s1.44-2.13,2.05-3.27a.94.94,0,0,1,1.52-.22,4.7,4.7,0,0,1,.82,1A18.64,18.64,0,0,0,25.4,16c.74.74,1.5,1.46,2.28,2.14a2.37,2.37,0,0,1,.45.87.18.18,0,0,1-.09.25.81.81,0,0,0-.14.09,1.62,1.62,0,0,1-2,.09A14.47,14.47,0,0,1,22,16.45l-.13-.11c-.52-.39-.55-.37-.78.23s-.39,1.25-.67,1.83c-.1.21.05.43.21.58s.29.45.61.4a.28.28,0,0,0,.25-.25c.08-.36.17-.72.27-1.17a41,41,0,0,0,3.82,2.65l-1.27.72C21,23.17,17.79,25,14.56,26.83,14.3,27,14.19,27,14.08,26.68Zm1.14,2.53c-.12-.25-.08-.36.15-.5q5.88-3.64,11.75-7.31c.21-.13.4-.05.6-.1a6,6,0,0,0,2-.74s.12-.05.14-.1A3.84,3.84,0,0,1,32,18.78a27.92,27.92,0,0,0,5.41-2.88.84.84,0,0,1,1.07,0,1,1,0,0,1,.36,1,2.53,2.53,0,0,1-.73,1.32,25.15,25.15,0,0,0-4,5,37.55,37.55,0,0,0-2.84,5,3.5,3.5,0,0,1-.67.94,11.69,11.69,0,0,1-3.89,2.91.78.78,0,0,0-.49.72c0,.27-.11.54-.13.81a2.18,2.18,0,0,1-.86,1.74,1,1,0,0,0-.27.57L23.74,40.1a.21.21,0,0,1,0,.09c0,.07,0,.14-.08.17a.71.71,0,0,1-.51-.1c-2-.47-4-1-6.05-1.52-.25-.05-.49-.13-.75-.16s-.44-.24-.25-.55a9,9,0,0,1,1.35-3.63.56.56,0,0,0,0-.7C16.59,32.27,15.93,30.72,15.21,29.21ZM11,45.86l-.16,0c-.2-.05-.26-.17-.23-.45q.36-3.24.7-6.5c0-.05,0-.1,0-.14a.16.16,0,0,0,0-.07.18.18,0,0,1,.17-.09l.17,0,8.8,2.33,8.81,2.32c.28.08.37.16.27.46l-1.27,4.15c0,.16-.08.34-.26.34H28l-4.72-.64-3.07-.43C17.12,46.69,14.06,46.28,11,45.86Zm2.41,4.19a.53.53,0,0,1,0-.39,1.34,1.34,0,0,1,.08-.19s0,0,0,.07A1.26,1.26,0,0,1,13.4,50.06Zm27,40.77h0c-.11,0-.12.08-.17.11l-.09.07-.17.12a.88.88,0,0,0-.35.39s0,0,0,0,0,.07,0,.07h0v.07c-.11.32-.16.55-.22.71s0,.08,0,.11a.48.48,0,0,1,0,.08l0,.05a.21.21,0,0,1-.11.05h0a.75.75,0,0,1-.23-.05l-.62-.22-.05,0-.05,0L38,92.31h0v0h0c-.33-.11-.63-.17-.93-.29l-.55-.2a3.13,3.13,0,0,0-.69-.16c-.63-.22-1.28-.33-1.89-.55a1.12,1.12,0,0,1-.2,0h0c-.44-.09-.79-.2-1.2-.27a.53.53,0,0,1-.51-.68,4.18,4.18,0,0,0,0-.52c0-.05,0-.08,0-.19L31.76,89a.62.62,0,0,1-.07-.12c-.05-.05-.16-.11-.16-.17s-.07,0-.1-.07c-.34-.32-.24-.74-.2-1.15,0,0,0-.09,0-.13l0-.25s0-.09,0-.12c.17-.68.22-1.32-.51-1.73-.09-.05-.14-.11-.25-.19v0c-.33-.26-.69-.54-1-.75-.05-.11-.07-.13-.17-.17a6.45,6.45,0,0,1-1.41-1L27.59,83h0c-.07-.11-.14-.1-.2-.15l-.27-.17c-.55-.47-1.29-.91-1.88-1.44a1.64,1.64,0,0,1-.5-.36v0c-.58-.4-1.15-.8-1.71-1.23h0c-.07,0-.07-.05-.17-.11a6.27,6.27,0,0,1-.94-.66.28.28,0,0,0-.26-.11c-.26-.22-.49-.32-.71-.51L20.72,78a9.91,9.91,0,0,1-1.8-1.31l-.05-.05-.1-.11a.85.85,0,0,1-.12-.2.83.83,0,0,1-.05-.17v.09a14.33,14.33,0,0,1-1-1.37l0-.07a.16.16,0,0,1,0-.07.49.49,0,0,1,0-.12.53.53,0,0,1,.11-.24s0-.05,0-.09a9,9,0,0,1,.76-2v-.16a.84.84,0,0,0,0-.14.45.45,0,0,0,0-.07l0,0-.08,0h0A.56.56,0,0,0,18,72a1.41,1.41,0,0,0-.25.2l-.09.07-.07.09,0,0s0,0,0,0,0,0,0,0h0a6.64,6.64,0,0,1-.83.7c-.05.05-.15.12-.15.17h0a.25.25,0,0,1-.33.05c-.47-.21-.94-.4-1.41-.62a.39.39,0,0,1-.19-.28l0-.14,0-.12v0a4.27,4.27,0,0,1,.24-2,.87.87,0,0,0,0-.16,16.12,16.12,0,0,1,.34-1.92v-.28h0c-.1-.7-.1-1.39-.15-2.09,0-.12,0-.24,0-.36-.07-1.3-.15-2.6-.2-3.9-.1-2.72-.32-5.43-.24-8.15a2.89,2.89,0,0,0-.22-1.17,2.86,2.86,0,0,0-.12-.26c-.13-.25-.28-.49-.45-.74a1.2,1.2,0,0,1-.22-1.08c.16-.63.28-1.29.4-1.93.05-.31.14-.47.49-.35a1.81,1.81,0,0,0,.43,0c.58.13,1.18.14,1.76.28a.33.33,0,0,1,.15,0,9.86,9.86,0,0,1,1.65.22.34.34,0,0,1,.17,0c.66.09,1.31.16,2,.27a.73.73,0,0,1,.43.08s.05,0,.05,0c.76.09,1.37.14,2,.25H23v0c.44.05.72.11,1.06.16a7.05,7.05,0,0,0,1,.14h.09l.1,0a.33.33,0,0,1,.34.32c.17,1,.32,2.08.54,3.11,0,.08,0,.14,0,.21s.05.34.09.5c.1.5.19,1,.28,1.51a.72.72,0,0,0,0,.16v0c.11.66.23,1.24.34,1.87v.21a7.8,7.8,0,0,0-.59.73,7.32,7.32,0,0,0-.78,1.37c-.14.34-.32.69-.46,1h0a7,7,0,0,1-.45,1s0,0,0,0,0,.11-.05.14h0a15.46,15.46,0,0,1-.62,1.43c-.08.15-.16.31-.25.46s-.11.17-.11.25A5.32,5.32,0,0,1,23.15,65a3.44,3.44,0,0,1-.34,1,9.56,9.56,0,0,1-.59,1.79.77.77,0,0,0-.09.25s0,0,0,0a.93.93,0,0,1,0,.13.68.68,0,0,1,0,.14s0,0,0,0c-.05,1.13-.12,2.25-.17,3.37l.1,0,.43-.84c.14-.27.25-.56.4-.84a1.65,1.65,0,0,0,.23-.59c.33-.55.62-1.09,1-1.59,0-.05.1-.09.13-.2.28-.44.61-1,1-1.52.12-.19.25-.36.35-.56h0c.08-.22.2-.25.29-.35a1,1,0,0,1,.37-.29,1.84,1.84,0,0,1,0,.24s0,0,0,0a.57.57,0,0,1,0,.13s0,0,0,0,0,.05,0,.09a.25.25,0,0,0,0,.09s0,.05,0,.09a.25.25,0,0,1,0,.07h0a16.34,16.34,0,0,0-.11,2.09s0,.09,0,.11h0c.09.66.2,1.31.28,2h0a.74.74,0,0,1,0,.2c.11.66.25,1.32.33,2,0,0,0,.05,0,.08a.46.46,0,0,1,0,.12,5.38,5.38,0,0,0,.74,1.34c.17.25.36.55.52.76h0a20.16,20.16,0,0,0,1.62,1.41c.09,0,.17.11.26.11h0v.05c.22,0,.4.2.63.13l.12-.05s.08,0,.09-.08,0-.15-.12-.19c-.9-.57-.75-1.5-.86-2.37h0a7.41,7.41,0,0,1,.56.63.57.57,0,0,0,.11.12l.23.25A4.87,4.87,0,0,0,31,75a3.54,3.54,0,0,0,.57.4c.09,0,.17.11.25.11h0c.66.32,1.22.62,1.82.94a.68.68,0,0,1,.36.16,5,5,0,0,1,.42,2.07s0,.08.05.13a.3.3,0,0,1,0,.14,7.47,7.47,0,0,1,0,1.91.2.2,0,0,1,0,.17s0,0,0,.05h0A7.34,7.34,0,0,1,34.19,83c0,.62-.21,1.22-.27,1.85a.29.29,0,0,1,0,.08c0,.12-.09.26.17.23h0c.59-.61,1.18-1.21,1.73-1.9h0v0a.6.6,0,0,1,.26-.44,7.21,7.21,0,0,0,.69-.91l.69-.94s0,0,0-.05a.34.34,0,0,1,.13-.21l.07,0h.07a.61.61,0,0,1,.23.09l.35.22a5.52,5.52,0,0,1,1.89,1.22c.05.05.12.07.17.17a1.76,1.76,0,0,1,.6.6l.17.16,0,0c.86.73.93,1.12.31,2.1,0,0-.05.07-.08.07a1.08,1.08,0,0,1-.11.25,1.18,1.18,0,0,1-.09.16l0,.08a2.72,2.72,0,0,0-.4.84,2,2,0,0,0-.05.76c.12.43.23.86.32,1.3a6.35,6.35,0,0,1,.13.8A1.18,1.18,0,0,1,40.38,90.83Zm2.91,5.32c-.14.17-.16.54-.39.5h0s0,0-.07,0a2.84,2.84,0,0,1-1.21-.39c-.13-.09-.1-.25-.1-.4V93.79c0-.14.05-.31-.09-.4-.48-.31-.36-.83-.48-1.27,0-.17.08-.26.17-.37l1.27-1.41a.81.81,0,0,0,.2-1,2.42,2.42,0,0,1,0-2.21c.25-.59.42-1.21.64-1.91l.07.08h0a10.6,10.6,0,0,1,1.14,1.53,7,7,0,0,0,3,3,5.47,5.47,0,0,0,1.88.87h.1c.08,0,.18,0,.16.11s-.08.07-.14.05h-.1a12.46,12.46,0,0,0-2.24.31l-1.16.26-1,.23-.07,0h0c-.15,0-.22.11-.2.26a.32.32,0,0,0,.31.33,5.93,5.93,0,0,0,1.19.08h.06a11.4,11.4,0,0,0,1.61-.15A11,11,0,0,1,49.54,92a11.86,11.86,0,0,1,1.75.13c-2,.32-3.57,1.42-5.34,2.16-.92.38-1.63,1.11-2.5,1.58C43.38,95.95,43.35,96.07,43.28,96.14Zm5.66,1.44s0,0,0,0h-.08a.13.13,0,0,1-.05-.05l-3.92-1c.45-.36.78-.57,1.32-.36.9.35,1.73.84,2.59,1.25a.19.19,0,0,1,.13,0s0,0,0,.05Zm6,.88a.46.46,0,0,1-.67.07,42.45,42.45,0,0,0-5-2.48c-.75-.32-1.55-.45-2.33-.72.09-.16.25-.16.38-.21,1.67-.62,3.37-1.18,5-1.91a2.17,2.17,0,0,1,1.27,0A2.8,2.8,0,0,0,55.41,93a.35.35,0,0,1,.33,0l3.84,1.58c-.6.5-1.16,1-1.7,1.39C56.88,96.77,55.88,97.59,54.94,98.47Zm3.9.73a1.06,1.06,0,0,1-.24.09l-.48-1.52a27.43,27.43,0,0,1,2.73-2.42c.11-.09.2-.22.37-.15l2.54,1Zm6.86-8.79a2.29,2.29,0,0,0-.35,2.23,1.48,1.48,0,0,1-.83,2,1,1,0,0,1-.55.16.57.57,0,0,1-.4-.13c-1.7-1.18-3.73-1.57-5.65-2.25a7,7,0,0,0-.82-.26c-.33-.08-.31-.29-.26-.52s.12-.19.21-.17.21,0,.28.07a53.54,53.54,0,0,1,6.5,1.8.89.89,0,0,0,.2.05c.15,0,.2-.16.17-.37,0-.49-.09-1-.66-1.23a12.74,12.74,0,0,0-4.43-1.06l-.68,0a21.58,21.58,0,0,0,3.24-1.85,4.54,4.54,0,0,0,.34-.31l1.81-2.2.22-.36.05,0,0,0a.5.5,0,0,1,.23.34c.46,1.13.91,2.26,1.37,3.39A.61.61,0,0,1,65.7,90.41ZM89.06,44a.29.29,0,0,1,.07.11.11.11,0,0,1,0,.1.19.19,0,0,1-.07.07l0,.07h0s0,0,0,0a0,0,0,0,1,0,0h0v0a1.23,1.23,0,0,0,0,1.89.34.34,0,0,1,.07.16c.44.58.08,1.16,0,1.74,0,.05,0,.08-.07.1h0l-.13,0h0L87.66,48s-.05,0-.09,0-.05,0-.09,0a1.29,1.29,0,0,1-.54-.09,1.15,1.15,0,0,0-1.33.23.26.26,0,0,1,0,.09,1.29,1.29,0,0,0,.76.43,20.62,20.62,0,0,1,3.09,1.58.67.67,0,0,1,.26.69,3.94,3.94,0,0,1-.09.47l-.33,1.41a.58.58,0,0,1-.09.35c0,.76-.52,1.33-.78,2a.58.58,0,0,0-.09.19,14.68,14.68,0,0,1-.59,1.35s0,.08-.05.11v0s0,0,0,0,0,0,0,0l0,0a1.18,1.18,0,0,1-.26.6,8.7,8.7,0,0,1-.85,2,.32.32,0,0,0-.08.16c-.28.66-.58,1.44-.86,2.16-.07.26-.12.52-.19.78l0,.07s0,0,0,0,0,0,0,.07a2,2,0,0,1-.16.87c-.05.17-.1.37-.15.55a.33.33,0,0,1,0,.09l-.92,4.15c-.25,1.14-.35,2.29-.54,3.43s-.22,2.17-.48,3.22a11.11,11.11,0,0,1-1,2.18,21.09,21.09,0,0,1-.94,2l0,.07a.75.75,0,0,0-.05.14s0,.05,0,.08l0,.15a.82.82,0,0,0,0,.16.82.82,0,0,1,0,.16V80c0,.11,0,.22,0,.33a29.13,29.13,0,0,0-.19,3.52.36.36,0,0,1-.26.41l-.26.1-.51.22-.27.11a3,3,0,0,1-.45.15v0l-.05,0-.6.25L78,85.3a2.89,2.89,0,0,1-1,.42l-.16.1c-.69.31-1.41.62-2.06.93,0,0-.07,0-.09,0a8.51,8.51,0,0,0-1.12.5l-1.2.51-1.9.83s-.05,0-.08,0c-.58.22-1.18.54-1.73.79a8.11,8.11,0,0,1-.81.35c-.5.2-.61.17-.72-.34-.33-.24-.36-.64-.48-1s-.22-.69-.33-1c0-.11-.08-.09-.08-.15a1.49,1.49,0,0,1-.16-.45s0-.05,0-.08,0-.05,0-.09l0-.08h0c-.15-.46-.32-.91-.43-1.37a5.93,5.93,0,0,1-.36-.92.78.78,0,0,1,0-.32l0-.15s0-.05,0-.08a7.05,7.05,0,0,1,.34-.63l.22-.52c.08-.17.14-.31.22-.52s.28-.71.5-1.09a1.23,1.23,0,0,1,.09-.26c.2-.67.41-1.34.68-2,0,0,0-.05,0-.08.08-.39.45-.54.67-.76h0c.11,0,.16-.1.22-.1a1,1,0,0,1,.2-.22c.12-.14.23-.29.34-.45a2.69,2.69,0,0,0,.15-.23c.21-.31.39-.62.62-.93.08-.1.14-.25.26-.25h.05c.17,0,.12.25.1.38a4,4,0,0,0,0,1.49c.05.38.12.76.15,1.15,0,.05,0,.12,0,.17a2.63,2.63,0,0,1,.16.86c.09.37.16.73.27,1.1A14.84,14.84,0,0,1,71.28,83h0c.37.55.74,1.18,1.11,1.78a4.33,4.33,0,0,0,.34.4h0v.09c.11,0,.16.24.33,0,0-.11-.05-.11-.09-.11a2,2,0,0,1-.14-.36c0-.08-.05-.16-.07-.23a1.75,1.75,0,0,1-.05-.23s0-.08,0-.11a1.31,1.31,0,0,0,0-.22c0-.11,0-.22-.05-.34s0-.23-.05-.34a.16.16,0,0,1,0-.12.62.62,0,0,0,0-.13c0-.13,0-.26-.05-.39l-.1-.79c0-.13-.05-.26-.07-.39a16.53,16.53,0,0,1,.16-4.28h.07c.13-.66.26-1.41.39-2.12H73a13.66,13.66,0,0,0,.34,3.53.19.19,0,0,1,0,.08c.16.45.34.9.48,1.35l.1.28a1.19,1.19,0,0,0,.13.26l.12.16c0,.05.1.11.1.16a2.83,2.83,0,0,1,.25.27l.19.24c.23.22.47.43.75.71,0-.23-.05-.43-.08-.63s-.05-.39-.08-.61c0,0-.05,0-.05-.05a3.77,3.77,0,0,0,0-.49c-.07-.5-.12-1-.19-1.5a.45.45,0,0,1,0-.12,1.13,1.13,0,0,1,0-.12A12.32,12.32,0,0,1,75,76.73s0-.05,0-.08a.43.43,0,0,1,0-.15A5.12,5.12,0,0,1,75,75c0-.15,0-.32,0-.47s0-.05,0-.09a7.17,7.17,0,0,1,.25-2.15.62.62,0,0,1,0-.08c.05-.33.11-.72.16-1.08s.11-.73.15-1.09c0-.15.07-.23.15-.23a.35.35,0,0,1,.19.08l.23.14.34.22a2.29,2.29,0,0,1,.32.25l0,0,.08.05h0a5.64,5.64,0,0,1,1.7,1.63,1.15,1.15,0,0,1,.24.22,1.41,1.41,0,0,1,.26.47,4.92,4.92,0,0,1,.76,1.46l0,.14s0,0,0,.13a1.58,1.58,0,0,1,.2.38c.05.13.1.26.15.38l.09.19a.39.39,0,0,0,.08.11.31.31,0,0,0,.19.11c.12-.4-.16-.79-.05-1.17h0c0-.11,0-.11,0-.16a7.8,7.8,0,0,0-.49-2.06,1.29,1.29,0,0,1,0-.17,10.05,10.05,0,0,0-.78-1.9.47.47,0,0,1-.16-.28,1.17,1.17,0,0,1-.25-.37l-.17-.28v.08s0,0,0,0h0a12.54,12.54,0,0,0-1-1.27l0,0s-.09,0-.13-.15a3.83,3.83,0,0,1-.78-.67s-.07,0-.09-.08,0,0-.11-.08c-.55-.37-1-.83-1.43-1.16-.09-.11-.2,0-.24-.22a33.78,33.78,0,0,1,4.19.16v-.05h0a8.06,8.06,0,0,1,2,.51s0,0,.08,0v0a6.21,6.21,0,0,1,1.27.49c.09,0,.2.19.29.05s0-.21-.11-.29-.32-.46-.49-.69c0-.05-.09-.11-.09-.16-.33-.32-.58-.68-.86-1a3.74,3.74,0,0,1-.27-.29,5.28,5.28,0,0,1-1-.78c-.05,0-.11-.1-.16-.1s-.29-.15-.44-.25l-.44-.28L78.76,63l-2-.73s-.07,0-.07,0h-.08a.5.5,0,0,1-.33-.13.36.36,0,0,1-.12-.16s0,0,0-.05a.62.62,0,0,1,0-.28,4.4,4.4,0,0,0-.05-1,2.66,2.66,0,0,0-.05-.28l-.07-.27-.07-.28c0-.13-.08-.29-.11-.4s0,0,0,0a16.45,16.45,0,0,0-.57-2c0-.09,0-.15-.08-.26a1.68,1.68,0,0,1-.26-.76,1.93,1.93,0,0,1,0-.25s0-.09,0-.12a2.3,2.3,0,0,1,.09-.37c0-.16.1-.33.15-.49s0-.08,0-.08h0a17.38,17.38,0,0,1,.67-2.13s0,0,0,0l0,0s0,0,0,0a1.21,1.21,0,0,0,.24-.84,1.49,1.49,0,0,0-.12-.47c-.08-.2-.17-.38-.27-.58a.16.16,0,0,0-.07-.05s0,0,0,0a5.44,5.44,0,0,1-1-1.62L74.57,49s0,0,0-.08,0,0,0,0l0-.08h0s0,0,0,0a1.28,1.28,0,0,1,.05-.2l.07-.12.09-.1,0,0c.29-.43.57-.87.9-1.29a1.18,1.18,0,0,0,.23-1.15c-.19-.62-.16-.63.46-.86.11,0,1.43-.55,2-.71l.34-.13.09,0,.25-.1L81,43.34h.08a15,15,0,0,1,2-.76,1.61,1.61,0,0,1,.27-.09c.11-.09.44-.16.55-.25.55-.17,1-.43,1.47-.54.72-.55,1.31-.32,1.8.36l.2.14c.1.09.13.19.24.29C88.1,43,88.59,43.51,89.06,44Zm-15.35.6-.17,0c-.16,0-.25-.05-.36-.25q-1.49-2.69-3-5.35c-.13-.23-.17-.35.15-.44l19.35-5.67.27-.07v0h0c-.1,1.17-.2,2.27-.28,3.37l-.2,2.44a.57.57,0,0,1-.43.59Q81.37,41.93,73.71,44.61Z"
                            />
                            <path
                                class="cls-2"
                                d="M41.94,69.14c1.81.15,3.6.51,5.41.76a2,2,0,0,1,.71.16,2.29,2.29,0,0,1,1,1.32A8.53,8.53,0,0,1,49.55,74a1.89,1.89,0,0,1-.66,1.73A2.53,2.53,0,0,0,48,76.95a2,2,0,0,1,1.76.71,7.3,7.3,0,0,0,1,1,1.72,1.72,0,0,0,2.66-.37c.26-.43.51-.86.8-1.28a3.27,3.27,0,0,1,1.47-1.45c.43-.14.24-.35.1-.52a1,1,0,0,0-1.28-.09,7.35,7.35,0,0,0-1.74,1.7,2.91,2.91,0,0,1-.51.52.49.49,0,0,1-.72,0,10.51,10.51,0,0,0-.81-.76.46.46,0,0,1-.14-.66A3.31,3.31,0,0,0,51,73.82a6.46,6.46,0,0,0-1.37-3.94c-.11-.12-.11-.19,0-.29A4.28,4.28,0,0,0,51.5,66.4c0-.34,0-.61-.31-.71s-.45.19-.57.4a16.29,16.29,0,0,1-.94,1.33,1.84,1.84,0,0,1-1.9.7c-2.6-.4-5.2-.67-7.82-.82-.13,0-.26,0-.37,0a7.16,7.16,0,0,0-2.2,2.13l.09,0,.25,0A12.81,12.81,0,0,1,41.94,69.14Z"
                            />
                            <path
                                class="cls-2"
                                d="M66.21,70.15c-.64.32-1.28.66-1.89,1a1.43,1.43,0,0,1-.51.22,18.34,18.34,0,0,1-3.29.34,3.09,3.09,0,0,1-1.67-.59,1.31,1.31,0,0,1-.67-.92,1,1,0,0,1,.47,0,9.39,9.39,0,0,0,1.74.25,15.48,15.48,0,0,0,4.08-1l1.29-.47c.2-.07.25-.13.08-.32a.65.65,0,0,0-.67-.15,25.59,25.59,0,0,1-8.51-.21c-.82-.15-1.69-.21-2-1.22a7.14,7.14,0,0,1-.23-.83,1.69,1.69,0,0,0-.43-.78.4.4,0,0,0-.41-.17c-.17,0-.16.23-.16.36,0,.46,0,.92.09,1.38a2.9,2.9,0,0,0,.51,1.4A3.83,3.83,0,0,0,56.34,70c.71.16.71.17.78.91a.88.88,0,0,0,.37.78,3.76,3.76,0,0,0,1.65.67,2,2,0,0,1,1.1.31,2.65,2.65,0,0,0,1.45.45c.38,0,.78,0,1.16.11a.81.81,0,0,0,.73-.23c1.08-.9,2.15-1.8,3.17-2.81A.41.41,0,0,0,66.21,70.15Z"
                            />
                            <path
                                class="cls-2"
                                d="M56.9,78.88a7.39,7.39,0,0,1-2.78.62c-.4.05-.91-.07-1.2.23-.72.71-1.33.41-2-.09a.36.36,0,0,0-.11-.07,2.52,2.52,0,0,0-2.84,0,1.53,1.53,0,0,1-1.21.31.83.83,0,0,0-.86.17,3.45,3.45,0,0,1-.46.32c-.43.28-.43.33,0,.64a.78.78,0,0,0,.31.14,3.23,3.23,0,0,0,2.56-.36,2,2,0,0,1,2.36.14,2.08,2.08,0,0,0,2.18.21,13.51,13.51,0,0,1,3-1c.15,0,.31-.08.45,0,.44.4.85.12,1.27,0,.16-.07.19-.2.17-.36,0-.35-.29-.55-.45-.82A.22.22,0,0,0,56.9,78.88Z"
                            />
                            <path
                                class="cls-2"
                                d="M53.28,81.83a10.94,10.94,0,0,0-3.2.56c-.84.28-1.78.48-2.22,1.45a14.17,14.17,0,0,0-.39,1.74,3,3,0,0,0,.34,1.28c.08.11.11.28.29.27s.26-.17.32-.31a9.11,9.11,0,0,0,.37-1.32,2.22,2.22,0,0,1,1.28-1.59c.78-.33,1.56-.63,2.35-.94a.84.84,0,0,1,.46-.05,6.57,6.57,0,0,1,2.85.67.36.36,0,0,0,.28.05c.33-.08.36-.19.16-.45A3.29,3.29,0,0,0,53.28,81.83Z"
                            />
                            <path
                                class="cls-2"
                                d="M34,73.13a1.48,1.48,0,0,0-.58-1.45,1.59,1.59,0,0,1-.63-.92,3.29,3.29,0,0,0-.61-1.4c-.11-.11-.19-.35-.38-.27a.71.71,0,0,0-.51.52,2.24,2.24,0,0,0,1.27,2.51,2.22,2.22,0,0,1,1,1c.08.16.09.48.33.43S33.94,73.25,34,73.13Z"
                            />
                        </svg>
                        <h1
                            class="mt-5 md:mt-3 text-xl md:text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Composer
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            Dependency Manager for PHP
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <svg
                            class="w-16 md:mt-3 mx-auto fill-gray-300 dark:fill-gray-900"
                            viewBox="0 0 100 100"
                        >
                            <path
                                class="cls-1 fill-gray-900 dark:fill-gray-50"
                                d="M44.44,58.33H55.56V36.11H33.33V63.89H44.44Zm0-16.67H50V52.78H44.44Z"
                            />
                            <polygon
                                class="cls-1 fill-gray-900 dark:fill-gray-50"
                                points="16.67 41.67 22.22 41.67 22.22 58.33 27.78 58.33 27.78 36.11 5.56 36.11 5.56 58.33 16.67 58.33 16.67 41.67"
                            />
                            <polygon
                                class="cls-1 fill-gray-900 dark:fill-gray-50"
                                points="72.22 41.67 77.78 41.67 77.78 58.33 83.33 58.33 83.33 41.67 88.89 41.67 88.89 58.33 94.44 58.33 94.44 36.11 61.11 36.11 61.11 58.33 72.22 58.33 72.22 41.67"
                            />
                            <path
                                class="cls-2"
                                d="M0,63.89H27.78v5.56H50V63.89h50V30.56H0ZM61.11,36.11H94.44V58.33H88.89V41.67H83.33V58.33H77.78V41.67H72.22V58.33H61.11Zm-27.78,0H55.56V58.33H44.44v5.56H33.33Zm-27.78,0H27.78V58.33H22.22V41.67H16.67V58.33H5.56Z"
                            />
                            <rect
                                class="cls-2"
                                x="44.44"
                                y="41.67"
                                width="5.56"
                                height="11.11"
                            />
                        </svg>
                        <h1
                            class="mt-5 md:mt-3 text-xl md:text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            NPM
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            Dependency Manager for JavaScript
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="bg-cover grayscale h-18 w-16 md:w-16 md:mt-3 mx-auto dark:grayscale-0"
                        >
                            <img
                                v-bind:src="'/images/icons/' + 'xampp.png'"
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-5 md:mt-3 text-xl md:text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            XAMPP
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            Virtual APACHE server with MYSQL
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <svg
                            class="w-16 md:mt-3 mx-auto dark:fill-cyan-400"
                            viewBox="0 0 100 100"
                        >
                            <path
                                class="cls-1"
                                d="M98.08,45.6,54.42,1.94a6.44,6.44,0,0,0-9.11,0h0L36.24,11l11.5,11.5a7.65,7.65,0,0,1,9.68,9.75L68.51,43.34a7.65,7.65,0,1,1-4.59,4.32L53.58,37.32v27.2a7.65,7.65,0,1,1-6.3-.22V36.85a7.56,7.56,0,0,1-2.51-1.67,7.66,7.66,0,0,1-1.65-8.38L31.79,15.46,1.85,45.4a6.44,6.44,0,0,0,0,9.11h0L45.51,98.16a6.44,6.44,0,0,0,9.11,0h0L98.08,54.71a6.44,6.44,0,0,0,0-9.11h0"
                            />
                        </svg>
                        <h1
                            class="mt-5 md:mt-3 text-xl md:text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            GIT
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            Version control system
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <svg
                            class="w-16 md:mt-3 mx-auto dark:fill-green-300"
                            viewBox="0 0 100 100"
                        >
                            <path
                                class="cls-1"
                                d="M36.13,65.86C26.64,62.31,17,59.06,7.5,55.34c-1.22-.46-2.3-.93-3.37-1.39a7,7,0,0,1-2.92-1.7A5.51,5.51,0,0,1,0,49.17,9.38,9.38,0,0,1,.93,45.6c.93-2.47,1.82-4.94,2.75-7.43.93-2.32,1.54-4.79,2.61-7a5.36,5.36,0,0,0,.46-1.7c.14-.62.46-1.25.62-1.84.46-1.07.93-2.32,1.37-3.4.93-2.47,1.68-4.79,2.61-7.1.46-.93.46-2.16,1.07-3.09a7.58,7.58,0,0,1,1.68-2c1.54-1.25,3.66-.93,5.36-.14,2.44.93,4.74,1.84,7.2,2.63s4.91,1.84,7.35,2.63,4.9,1.84,7.34,2.64,4.6,1.7,6.89,2.63a21,21,0,0,1,3.23,1.39,4.17,4.17,0,0,1,2,2.32,5.45,5.45,0,0,1,.46,1.39,3.56,3.56,0,0,1-.14,1.7,21.45,21.45,0,0,1-1.22,3.4c-.14.31-.14.62-.31.77s-.46.31-.62.46c-.31.14-.46.31-.76.31a6.26,6.26,0,0,1-.76-.14c-.93-.46-1.37-1.54-2.3-2A10.43,10.43,0,0,0,44.9,31a8.62,8.62,0,0,0-3.37.31,6.49,6.49,0,0,0-4.28,4.15,6.42,6.42,0,0,0,1.22,6.18,8.76,8.76,0,0,0,4.91,2.78c.31,0,.62.14.93,0a2.15,2.15,0,0,0,.93-.14c.31,0,.62,0,.76-.14a6.47,6.47,0,0,1,.76.31,2.5,2.5,0,0,1,.93.93c.14.14.14.31.31.62a12.26,12.26,0,0,0-.46,1.25c-.62,2.16-1.37,4.15-2.15,6.18s-1.37,4-2.15,6a18,18,0,0,0-1.07,2.78A4.37,4.37,0,0,1,41,64.33a5.57,5.57,0,0,1-1.82,1.39,10.32,10.32,0,0,1-3,.14C34.89,65.38,36.58,65.86,36.13,65.86ZM15.61,71.73H19.9c.31,0,.14.14.14.31v5.25c0,.14-.14.31.14.31h5c.14,0,.31.14.31-.14V71.74h4.12V73c.15,2.93.15,5.87.15,8.8v6.49c0,.31,0,.31-.31.31h-3.8a.5.5,0,0,1-.14-.31v-6c0-.14,0-.14-.14-.14H20.06v6.5c0,.31-.14.14-.31.14H15.46v-7c.15-3.55.15-6.81.15-10,1.39,0,0,5.73,0,0Zm-14.53,0a12.9,12.9,0,0,0,3.51-.31,10.81,10.81,0,0,1,3.66.14,8.19,8.19,0,0,1,2.92,1.25l.93.93a1.23,1.23,0,0,1,.31.62c.14.14.14.62.31.77s.14.46.14.77v.93a8.06,8.06,0,0,1-.14,1.84A5.28,5.28,0,0,1,11,81.28c-1.68,1.39-3.83,1.54-6,1.39H4.76v3.71c0,.62.31,2.16-.76,2.16H.32c-.31,0-.14-.14-.14-.31V72.62a2.35,2.35,0,0,1,.9-.9C2.92,71.87.31,72,1.08,71.73ZM5.2,75v4.34H7.35a2.23,2.23,0,0,0,1.22-.93,2.09,2.09,0,0,0,0-2.63A2.52,2.52,0,0,0,7.2,75,8.62,8.62,0,0,0,5.2,75Zm32.61,7.75h0l-.46.46v5.27H33.52c-.14,0-.31.14-.31-.14V71.77h.62a8,8,0,0,0,1.82-.14,8.33,8.33,0,0,1,1.82-.31,12.15,12.15,0,0,1,5.81,1.25,5.09,5.09,0,0,1,2.44,4.34,5.32,5.32,0,0,1-2.3,4.63,7.34,7.34,0,0,1-2.61,1.07,12.33,12.33,0,0,1-3,.09m-.46-3.41c1.07,0,2.3.31,3.23-.46a2.23,2.23,0,0,0,.31-2.95,1.6,1.6,0,0,0-1.37-.77H38.13c-.31,0-.77.14-.77.29v3.89m10.72-7.57h3.66V79.6A11.62,11.62,0,0,0,52,82.84c.14.93.46,2.32,1.54,2.78a3.79,3.79,0,0,0,2.61,0,3.3,3.3,0,0,0,1.54-1.7A2.76,2.76,0,0,0,58,82.38c0-.62.14-1.39.14-2,.14-2.63-.14-5.27,0-7.88V72H61.8v7.43a32.9,32.9,0,0,1-.14,3.71,7.72,7.72,0,0,1-1.22,3.09,4.52,4.52,0,0,1-2.61,1.84,7.49,7.49,0,0,1-5.81.14,4.51,4.51,0,0,1-2-1.39,6,6,0,0,1-1.22-2.47,18.92,18.92,0,0,1-.76-6c.05-2.78,0-5,0-6.62ZM70.71,79a2.45,2.45,0,0,0-1.82,1,2.33,2.33,0,0,0-.31,1.39v6.79c0,.14.14.31-.14.31H65c-.14,0-.14,0-.14-.14V79.74a2.56,2.56,0,0,0-.31-1.54,5.74,5.74,0,0,1,0-1.54H67.8a.23.23,0,0,1,.14,0,.21.21,0,0,1,.1.28L68,77v1.25a6.1,6.1,0,0,1,3.83-2h1.68l.23.06h.12a3.33,3.33,0,0,1,1.51,1,3,3,0,0,1,.49,1.05A5.15,5.15,0,0,1,76,79a5,5,0,0,1,.09.62,18.67,18.67,0,0,1,.31,2.78c0,2-.14,4,0,6H72.7c-.14,0-.14,0-.14-.14V84.14c0-.65,0-1.33-.06-2s-.06-1.31-.11-1.95a1.72,1.72,0,0,0-.26-.49A2.09,2.09,0,0,0,70.71,79ZM87,73.89,90.18,73a.63.63,0,0,1,.46.14c.14.14.14.62.14.77v2s-.14.31.14.31h2.15c.14,0,.31-.14.31.14v2.47H91.23c-.14,0-.31-.14-.31.14v5.88l.46.46a.82.82,0,0,0,.62.31h1.53V88.4a6,6,0,0,1-4.6-.14c-.31-.31-.76-.46-.93-.93a5.48,5.48,0,0,1-.62-1.39,25.25,25.25,0,0,1,0-3.24V79.3a1.08,1.08,0,0,0-.93-.46H86c-.14,0-.14,0-.14-.14V76.2h.46c.31,0,.62.14.93-.14A3.23,3.23,0,0,1,87,73.89C88.05,73.58,86.68,74.65,87,73.89Zm-7.54,2.46h3.23s.31-.14.31.14V88.4H79.73s-.31.14-.31-.14V76.34c1.25,0,0,4.2,0,0Z"
                            />
                            <path
                                class="cls-1"
                                d="M47.64,38.76a5.28,5.28,0,0,1-2.15,2.32c-.46.14-.93.31-1.54.46-.14,0-.46.14-.62.14a1,1,0,0,1-.76-.31,3.77,3.77,0,0,1-2.75-3.57,4,4,0,0,1,7.37-2.16c.59.8.45,2,.45,3.13-.48.76,0-.62,0,0Zm-5.81-1.85a3.46,3.46,0,0,0,0,.77,3,3,0,0,0,.26.77,3.27,3.27,0,0,0,1.07.93,1.83,1.83,0,0,0,2.4-1l0-.1a6,6,0,0,1,.14-.62.37.37,0,0,0,0-.22v-.23a1.59,1.59,0,0,0-.08-.34.22.22,0,0,0-.08-.2,2.52,2.52,0,0,0-.42-.62,3.58,3.58,0,0,0-.43-.37,3.15,3.15,0,0,0-.45-.29,2.26,2.26,0,0,0-1.67.26,2,2,0,0,0-.57.57A3.59,3.59,0,0,1,41.83,36.91ZM82.64,71.08a1.88,1.88,0,0,1,.43.71,2.27,2.27,0,0,1,.09.71,3.56,3.56,0,0,1-.09.82,2.4,2.4,0,0,1-.37.82,2.54,2.54,0,0,1-1,.39,2.7,2.7,0,0,1-1.14-.08,2,2,0,0,1-.23-3.66,2.7,2.7,0,0,1,1.17-.12A2.82,2.82,0,0,1,82.64,71.08Zm-6.55-5.9a20.76,20.76,0,0,1,1.82-1.39c.46.77.93,1.54,1.37,2.32,0,.14.29.45.14.45a.74.74,0,0,0-.46.31,7.06,7.06,0,0,1-1.07.77c-.9-.43-1.19-1.51-1.81-2.46.62-.46.62.94,0,0ZM67.84,51.73c-.46.46-.76.77-1.22,1.25-.14.14-.14,0-.31,0L66,52.67,65.38,52l-.63-.62-.31-.31c-.14-.14-.14-.14,0-.31.31-.46.76-.93,1.07-1.39.65.93,2.18,1.07,2.33,2.3-.45.46-.15-1.24,0,0ZM55.59,41.86c.76.46,1.37.93,2.15,1.39.14,0,.14.14.31.14s.14.14,0,.14c-.14.31-.31.46-.46.77A8.3,8.3,0,0,1,57,45.55c-.62-.46-1.37-1.07-2.15-1.54a.79.79,0,0,1-.46-.31c.14-.14.31-.46.46-.62a5.77,5.77,0,0,1,.77-1.22c.77.6-.46.6,0,0ZM73.35,61.18a2.78,2.78,0,0,1-.28-.31,2.87,2.87,0,0,1-.22-.31,1.1,1.1,0,0,1-.25-.43.67.67,0,0,1,0-.19c0-.26.59-.8,1.53-1.33.26.32.53.66.77,1s.53.73.77,1.08a2,2,0,0,1,.22.36.63.63,0,0,1,0,.19c0,.11-.12.14-.32.28a1.94,1.94,0,0,0-.25.2L75,62a5.53,5.53,0,0,1-.76.56ZM48.86,40.77c.31-.46.62-1.07.93-1.54a.63.63,0,0,1,.14-.31c.31,0,.31.14.46.14.31.14.62.31.93.46s.46.31.76.46c.14,0,.31.14.46.14s0,.14,0,.31c-.31.62-.46,1.25-.76,1.84a29.38,29.38,0,0,1-2.92-1.5C49.32,40.15,49.94,41.38,48.86,40.77Zm10.87,6.5c-.14-.93.93-1.07.93-1.84a29.79,29.79,0,0,1,2.61,2c-.31.31-.46.62-.76.93A2.19,2.19,0,0,0,62,49a1,1,0,0,1-.62-.14,6.38,6.38,0,0,1-1.7-1.59C59.57,46.32,60.33,48,59.73,47.27ZM70.6,57.6a29.24,29.24,0,0,0-2-2.32l.93-.93a.82.82,0,0,1,.62-.31c.31,0,.62.46.76.62.14.31.46.46.62.77s.46.46.46.77c0,.14,0,.14-.14.31A7.48,7.48,0,0,1,70.6,57.6C70,56.84,71,57.32,70.6,57.6ZM43,22.67l-.31-.31A.34.34,0,0,0,43,22.67Z"
                            />
                        </svg>
                        <h1
                            class="mt-5 md:mt-3 text-xl md:text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            PHP Unit
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            Unit tests
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="bg-cover grayscale h-18 w-16 md:w-16 md:mt-3 mx-auto dark:grayscale-0"
                        >
                            <img
                                v-bind:src="'/images/icons/' + 'mailtrap.png'"
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-5 md:mt-3 text-xl md:text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            MAIL TRAP
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            Test mailing Platform
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <svg
                            class="w-16 md:mt-3 mx-auto dark:fill-cyan-400"
                            viewBox="0 0 100 100"
                        >
                            <path
                                class="cls-1"
                                d="M.05,54.31c-.38,1.75,1.48,3.7,3.25,2,9-9.55,18.7-9.1,27.54,6.42a1.83,1.83,0,0,0,3.42,0C37.76,56.57,42,50,50,50,60.16,50,65.31,62,65.75,62.72a1.83,1.83,0,0,0,3.42,0C78,47.18,87.76,46.85,96.7,56.29c1.79,1.74,3.63-.23,3.25-2-5-23.66-24-37.88-44.39-40.09V11.12a5.56,5.56,0,0,0-11.11,0v3.11C24,16.43,5.12,30.65.05,54.31Z"
                            />
                            <path
                                class="cls-1"
                                d="M44.44,57.94V80.57a2.78,2.78,0,0,1-5.4.92,5.55,5.55,0,0,0-10.47,3.7,13.89,13.89,0,0,0,27-4.64V57.93A8.52,8.52,0,0,0,50,55.56,8,8,0,0,0,44.44,57.94Z"
                            />
                        </svg>
                        <h1
                            class="mt-5 md:mt-3 text-xl md:text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            DRY
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            Don't repeat yourself
                        </p>
                    </div>
                    <!-- END card ITEM -->
                </div>
                <!--End Card Body -->
            </div>
        </section>
        <!-- other Section-->
        <section id="other" class="pb-28 bg-gray-100 dark:bg-gray-900">
            <div
                class="container px-6 py-10 mx-auto md:mt-1 md:w-4/5 pb-9 w-full"
            >
                <h1 class="text-dark text-3xl text-center dark:text-zinc-200">
                    LAST BUT NOT LEAST
                </h1>
                <h4 class="text-gray-600 text-center dark:text-zinc-300">
                    I'm familiar with…
                </h4>
                <!-- CARD BODY-->
                <div
                    class="grid grid-cols-3 gap-3 md:gap-8 mt-8 xl:mt-12 xl:gap-12 md:grid-cols-4 xl:grid-cols-6 content-center"
                >
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <svg
                                class="mx-auto text-zinc-300 fill-gray-600 dark:fill-white"
                                viewBox="0 0 100 100"
                            >
                                <g>
                                    <path
                                        class="st0"
                                        d="M102.79,7.11l2.59,3.41c0.68,0.9,0.51,2.19-0.39,2.87l-2.75,2.09c0.5,1.33,0.82,2.75,0.95,4.2l3.13,0.43 c1.12,0.15,1.9,1.19,1.75,2.31l-0.58,4.25c-0.15,1.12-1.19,1.91-2.31,1.75l-3.42-0.47c-0.61,1.33-1.39,2.55-2.31,3.64l1.92,2.52 c0.68,0.9,0.5,2.19-0.4,2.87l-3.41,2.59c-0.9,0.68-2.19,0.5-2.87-0.39l-2.09-2.75c-1.34,0.5-2.75,0.82-4.21,0.95l-0.43,3.13 c-0.15,1.12-1.19,1.9-2.31,1.75l-4.25-0.58c-1.12-0.15-1.9-1.19-1.75-2.31l0.47-3.42c-1.32-0.61-2.55-1.39-3.64-2.3l-2.52,1.91 c-0.9,0.68-2.19,0.51-2.87-0.39l-2.59-3.41c-0.68-0.9-0.51-2.19,0.39-2.87l2.75-2.09c-0.5-1.34-0.82-2.75-0.95-4.2l-3.13-0.43 c-1.12-0.15-1.91-1.19-1.75-2.31l0.58-4.25c0.16-1.12,1.19-1.9,2.31-1.75l3.42,0.47c0.61-1.32,1.39-2.55,2.3-3.64l-1.91-2.52 C71.83,7.28,72,5.99,72.9,5.31l3.41-2.59c0.9-0.68,2.19-0.51,2.87,0.39l2.09,2.75c1.33-0.5,2.75-0.82,4.2-0.95l0.43-3.13 c0.15-1.12,1.19-1.91,2.31-1.76l4.25,0.58c1.12,0.15,1.91,1.19,1.75,2.31l-0.47,3.42c1.33,0.61,2.55,1.39,3.65,2.31l2.52-1.91 C100.81,6.04,102.1,6.21,102.79,7.11L102.79,7.11L102.79,7.11z M29.67,67.12v-16.5h8.5c1.58,0,2.78,0.13,3.61,0.41 c0.83,0.27,1.51,0.77,2.01,1.5c0.51,0.74,0.77,1.63,0.77,2.68c0,0.91-0.2,1.71-0.59,2.37c-0.39,0.67-0.93,1.21-1.61,1.62 c-0.43,0.26-1.03,0.48-1.79,0.65c0.61,0.21,1.05,0.4,1.32,0.61c0.19,0.14,0.46,0.43,0.81,0.87c0.35,0.44,0.59,0.79,0.71,1.03 l2.48,4.77h-5.76l-2.72-5.03c-0.35-0.65-0.65-1.08-0.92-1.27c-0.37-0.25-0.79-0.38-1.25-0.38h-0.45v6.68H29.67L29.67,67.12z M47.65,95.85h-9.52l-1.37,4.48h-8.58l10.23-27.19h9.2l10.19,27.19h-8.8L47.65,95.85L47.65,95.85z M45.87,89.96l-2.97-9.78 l-2.98,9.78H45.87L45.87,89.96z M59.78,73.14h13.98c3.05,0,5.33,0.72,6.84,2.17c1.51,1.45,2.27,3.52,2.27,6.19 c0,2.75-0.83,4.9-2.48,6.45c-1.65,1.55-4.18,2.32-7.57,2.32h-4.61v10.06h-8.43V73.14L59.78,73.14z M68.21,84.76h2.07 c1.63,0,2.78-0.28,3.44-0.85c0.66-0.56,0.99-1.29,0.99-2.16c0-0.85-0.29-1.58-0.86-2.17c-0.57-0.59-1.65-0.89-3.23-0.89h-2.41 V84.76L68.21,84.76z M86.27,73.14h8.43v27.19h-8.43V73.14L86.27,73.14z M34.79,57.32h2.15c0.23,0,0.68-0.08,1.35-0.23 c0.34-0.07,0.62-0.24,0.83-0.52c0.22-0.28,0.32-0.6,0.32-0.96c0-0.53-0.17-0.95-0.51-1.23c-0.34-0.29-0.97-0.43-1.9-0.43h-2.24 V57.32L34.79,57.32z M46.87,50.62h13.65v3.52h-8.53v2.63h7.91v3.36h-7.91v3.25h8.78v3.73h-13.9V50.62L46.87,50.62z M61.98,61.66 l4.84-0.3c0.1,0.79,0.32,1.38,0.64,1.79c0.53,0.66,1.28,1,2.25,1c0.72,0,1.29-0.17,1.68-0.51c0.39-0.34,0.59-0.74,0.59-1.19 c0-0.43-0.19-0.81-0.56-1.15c-0.37-0.34-1.24-0.65-2.61-0.96c-2.23-0.5-3.82-1.17-4.78-2c-0.96-0.83-1.44-1.89-1.44-3.18 c0-0.85,0.25-1.65,0.74-2.4c0.49-0.75,1.23-1.35,2.22-1.78c0.99-0.43,2.34-0.64,4.06-0.64c2.11,0,3.71,0.39,4.82,1.18 c1.1,0.79,1.76,2.03,1.97,3.75l-4.79,0.29c-0.13-0.75-0.4-1.3-0.8-1.63c-0.41-0.34-0.98-0.51-1.69-0.51 c-0.59,0-1.04,0.13-1.34,0.38c-0.3,0.25-0.45,0.56-0.45,0.92c0,0.26,0.13,0.49,0.37,0.71c0.24,0.21,0.8,0.42,1.7,0.61 c2.23,0.48,3.83,0.97,4.79,1.46c0.96,0.49,1.67,1.1,2.1,1.83c0.44,0.72,0.66,1.54,0.66,2.44c0,1.06-0.29,2.03-0.88,2.92 c-0.58,0.89-1.4,1.57-2.45,2.03c-1.05,0.46-2.37,0.69-3.97,0.69c-2.8,0-4.75-0.54-5.83-1.62C62.74,64.69,62.13,63.32,61.98,61.66 L61.98,61.66z M77.69,50.62h15.51v4.08H88v12.42H82.9V54.7h-5.21V50.62L77.69,50.62z M60.53,11.46c-1.83-0.14-3.68-0.12-5.51,0.06 c-5.63,0.54-11.1,2.59-15.62,6.1c-5.23,4.05-9.2,10.11-10.73,18.14l-0.48,2.51l-2.5,0.44c-2.45,0.43-4.64,1.02-6.56,1.77 c-1.86,0.72-3.52,1.61-4.97,2.66c-1.16,0.84-2.16,1.78-3.01,2.8c-2.63,3.15-3.85,7.1-3.82,11.1c0.03,4.06,1.35,8.16,3.79,11.53 c0.91,1.25,1.96,2.4,3.16,3.4c1.22,1.01,2.59,1.85,4.13,2.48c0.87,0.36,1.8,0.66,2.77,0.9v7.49c-2-0.36-3.84-0.9-5.56-1.61 c-2.27-0.94-4.28-2.15-6.05-3.63c-1.68-1.4-3.15-2.99-4.4-4.72C1.84,68.28,0.04,62.66,0,57.06c-0.04-5.66,1.72-11.29,5.52-15.85 c1.23-1.48,2.68-2.84,4.34-4.04c1.93-1.4,4.14-2.58,6.64-3.55c1.72-0.67,3.56-1.23,5.5-1.68c2.2-8.74,6.89-15.47,12.92-20.14 c5.64-4.37,12.43-6.92,19.42-7.59c3.67-0.35,7.39-0.19,11.03,0.49c-0.08,0.33-0.15,0.66-0.19,1l-0.01,0.06 c-0.07,0.57-0.1,1.14-0.07,1.72c-0.77,0.3-1.49,0.71-2.14,1.21l-0.03,0.02C61.96,9.44,61.14,10.38,60.53,11.46L60.53,11.46z M113.44,30.66c0.56,0.51,1.1,1.04,1.63,1.61c1.07,1.15,2.08,2.45,3.03,3.9c3.2,4.92,4.84,11.49,4.77,17.92 c-0.07,6.31-1.77,12.59-5.25,17.21c-2.27,3.01-5.18,5.47-8.67,7.42c-2.39,1.34-5.08,2.45-8.01,3.35v-7.75 c1.58-0.59,3.05-1.25,4.4-2c2.63-1.47,4.78-3.26,6.39-5.41c2.5-3.33,3.73-8.04,3.78-12.87c0.06-5.07-1.18-10.16-3.59-13.86 c-0.69-1.07-1.45-2.03-2.25-2.89c-0.31-0.33-0.62-0.64-0.94-0.94c0.05-0.5,0.07-1.01,0.04-1.52c0.77-0.3,1.49-0.71,2.14-1.21 l0.03-0.02C111.97,32.81,112.83,31.81,113.44,30.66L113.44,30.66z M88.08,12.8c4.61,0.63,7.83,4.88,7.2,9.49 c-0.63,4.61-4.88,7.84-9.49,7.21c-4.61-0.63-7.84-4.88-7.2-9.49C79.23,15.4,83.47,12.17,88.08,12.8L88.08,12.8L88.08,12.8z"
                                    />
                                </g>
                            </svg>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            REST API
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fas fa-database"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            SQL
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fas fa-table"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            CRUD
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-python"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Python
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-linux"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Linux
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-github"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Github
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-font-awesome-alt"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Font Awesome
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fas fa-server"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Server
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-gofore"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            GoDaddy
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-wordpress"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            WordPress
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-css3-alt"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            CSS
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-node-js"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            JavaScript
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-sass"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            SCSS
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-less"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Less
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-cpanel"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Cpanel
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fas fa-file-code"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            XML
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fas fa-sync"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            SDLC
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-npm"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            NPM
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fas fa-terminal"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            BASH Terminal
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-vuejs"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            VUE
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-gitlab"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Gitlab
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 grayscale text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 1333.34 1300.01"
                                shape-rendering="geometricPrecision"
                                text-rendering="geometricPrecision"
                                image-rendering="optimizeQuality"
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                            >
                                <g fill-rule="nonzero">
                                    <path
                                        fill="#1c0a00"
                                        d="M55.55 55.55h1222.23v1188.9H55.55z"
                                    />
                                    <path
                                        d="M55.55 55.55h1222.23v1188.9H55.55V55.55zM0 1300.01h1333.34V0H0v1300.01zm873.33-836.68c0-4.44 1.67-6.67 6.67-6.67h87.22c4.44 0 6.67 1.67 6.67 6.67v438.34c0 4.44-1.11 6.67-6.67 6.67h-86.11c-5.56 0-7.22-2.78-7.22-7.22V463.34h-.56zm-6.11-126.11c0-35.56 25-56.67 56.67-56.67 33.89 0 56.67 22.78 56.67 56.67 0 36.67-23.89 56.67-57.78 56.67-32.22 0-55.56-20-55.56-56.67zm-250 308.89C601.67 584.44 565 450 551.11 385H550c-11.67 65-41.11 175-64.45 261.11h131.67zm-154.45 90l-43.89 166.67c-1.11 4.44-2.78 5.55-8.33 5.55h-81.67c-5.56 0-6.67-1.67-5.56-8.33L481.1 347.77c2.78-10 4.44-18.89 5.56-46.11 0-3.89 1.67-5.56 4.44-5.56h116.67c3.89 0 5.56 1.11 6.67 5.56l176.67 599.45c1.11 4.44 0 7.22-4.44 7.22h-92.22c-4.44 0-7.22-1.11-8.33-5l-45.56-167.22H462.78z"
                                        fill="#ff7f18"
                                    />
                                </g>
                            </svg>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Illustrator
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 grayscale text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 1333.34 1300.01"
                                shape-rendering="geometricPrecision"
                                text-rendering="geometricPrecision"
                                image-rendering="optimizeQuality"
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                            >
                                <g fill-rule="nonzero">
                                    <path
                                        fill="#0c0824"
                                        d="M55.55 55.55h1222.23v1188.9H55.55z"
                                    />
                                    <path
                                        d="M55.55 55.55h1222.23v1188.9H55.55V55.55zM0 1300.01h1333.34V0H0v1300.01zm898.89-766.68c-43.89 0-58.89 22.22-58.89 40.56 0 20 10 33.89 68.89 64.45 87.22 42.22 114.45 82.78 114.45 142.22 0 88.89-67.78 136.67-159.45 136.67-48.33 0-90-10-113.89-23.89-3.89-1.67-4.44-4.44-4.44-8.89v-81.67c0-5.56 2.78-7.22 6.67-4.44 35 22.78 75 32.78 111.67 32.78 43.89 0 62.22-18.33 62.22-43.33 0-20-12.78-37.78-68.89-66.67-78.89-37.78-111.67-76.11-111.67-140 0-71.67 56.11-131.11 153.34-131.11 47.78 0 81.11 7.22 99.44 15.56 4.44 2.78 5.56 7.22 5.56 11.11v76.11c0 4.44-2.78 7.22-8.33 5.55-24.44-15.55-60.55-25-96.66-25zm-477.78 66.11c12.78 1.11 22.78 1.11 45 1.11 65 0 126.11-22.78 126.11-111.11 0-70.56-43.89-106.11-117.78-106.11-22.22 0-43.33 1.11-53.33 1.67v214.45zm-98.89-295c0-3.89 7.78-6.67 12.22-6.67 35.56-1.67 88.33-2.78 143.33-2.78 153.89 0 213.89 84.45 213.89 192.22 0 141.11-102.22 201.67-227.78 201.67-21.11 0-28.33-1.11-43.33-1.11v213.34c0 4.44-1.67 6.67-6.67 6.67h-85c-4.44 0-6.67-1.67-6.67-6.67V304.44z"
                                        fill="#31c5f0"
                                    />
                                </g>
                            </svg>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Photoshop
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 grayscale text-5xl h-18 w-12 mx-auto dark:fill-zinc-50"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 1321.45 1333.33"
                                shape-rendering="geometricPrecision"
                                text-rendering="geometricPrecision"
                                image-rendering="optimizeQuality"
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                            >
                                <path
                                    d="M221.37 618.44h757.94V405.15H755.14c-23.5 0-56.32-12.74-71.82-28.24-15.5-15.5-25-43.47-25-66.97V82.89H88.39c-1.99 0-3.49 1-4.49 2-1.5 1-2 2.5-2 4.5v1155.04c0 1.5 1 3.5 2 4.5 1 1.49 3 1.99 4.49 1.99H972.8c2 0 1.89-.99 2.89-1.99 1.5-1 3.61-3 3.61-4.5v-121.09H221.36c-44.96 0-82-36.9-82-81.99V700.44c0-45.1 36.9-82 82-82zm126.51 117.47h75.24v146.61c0 30.79-2.44 54.23-7.33 70.31-4.92 16.03-14.8 29.67-29.65 40.85-14.86 11.12-33.91 16.72-57.05 16.72-24.53 0-43.51-3.71-56.94-11.06-13.5-7.36-23.89-18.1-31.23-32.3-7.35-14.14-11.69-31.67-12.99-52.53l71.5-10.81c.11 11.81 1.07 20.61 2.81 26.33 1.76 5.78 4.75 10.37 9 13.95 2.87 2.33 6.94 3.46 12.25 3.46 8.4 0 14.58-3.46 18.53-10.37 3.9-6.92 5.87-18.6 5.87-35V735.92zm112.77 180.67l71.17-4.97c1.54 12.81 4.69 22.62 9.44 29.28 7.74 10.88 18.74 16.34 33.09 16.34 10.68 0 18.93-2.76 24.68-8.36 5.81-5.58 8.7-12.07 8.7-19.41 0-6.97-2.71-13.26-8.2-18.79-5.47-5.53-18.23-10.68-38.28-15.65-32.89-8.17-56.27-19.1-70.26-32.74-14.12-13.57-21.18-30.92-21.18-52.03 0-13.83 3.61-26.89 10.85-39.21 7.22-12.38 18.07-22.06 32.59-29.09 14.52-7.04 34.4-10.56 59.65-10.56 31 0 54.62 6.41 70.88 19.29 16.28 12.81 25.92 33.24 29.04 61.27l-70.5 4.65c-1.87-12.25-5.81-21.17-11.81-26.7-6.05-5.6-14.35-8.36-24.9-8.36-8.71 0-15.31 2.07-19.73 6.16-4.4 4.09-6.59 9.12-6.59 15.02 0 4.27 1.81 8.11 5.37 11.57 3.45 3.59 11.8 6.85 25.02 9.93 32.75 7.86 56.2 15.84 70.31 23.87 14.18 8.05 24.52 17.98 30.96 29.92 6.44 11.88 9.66 25.2 9.66 39.96 0 17.29-4.3 33.24-12.88 47.89-8.63 14.58-20.61 25.7-36.08 33.24-15.41 7.54-34.85 11.31-58.33 11.31-41.24 0-69.81-8.86-85.68-26.52-15.88-17.65-24.85-40.09-26.96-67.3zm248.74-45.5c0-44.05 11.02-78.36 33.09-102.87 22.09-24.57 52.82-36.82 92.24-36.82 40.38 0 71.5 12.07 93.34 36.13 21.86 24.13 32.77 57.94 32.77 101.37 0 31.54-4.75 57.36-14.3 77.54-9.54 20.18-23.37 35.89-41.4 47.13-18.07 11.24-40.55 16.84-67.48 16.84-27.33 0-49.99-4.83-67.94-14.52-17.92-9.74-32.49-25.07-43.62-46.06-11.13-20.92-16.72-47.19-16.72-78.74zm74.89.19c0 27.21 4.57 46.81 13.68 58.68 9.13 11.88 21.57 17.85 37.26 17.85 16.1 0 28.65-5.84 37.45-17.47 8.87-11.68 13.28-32.54 13.28-62.77 0-25.39-4.63-43.92-13.84-55.61-9.26-11.76-21.75-17.6-37.56-17.6-15.13 0-27.34 5.97-36.49 17.85-9.21 11.88-13.78 31.61-13.78 59.07zm209.08-135.36h69.99l90.98 149.05V735.91h70.83v269.96h-70.83l-90.48-148.24v148.24h-70.49V735.91zm67.71-117.47h178.37c45.1 0 82 37.04 82 82v340.91c0 44.96-37.03 81.99-82 81.99h-178.37v147c0 17.5-6.99 32.99-18.5 44.5-11.5 11.49-27 18.5-44.5 18.5H62.97c-17.5 0-32.99-7-44.5-18.5-11.49-11.5-18.5-27-18.5-44.5V63.49c0-17.5 7-33 18.5-44.5S45.97.49 62.97.49H700.1c1.5-.5 3-.5 4.5-.5 7 0 14 3 19 7.49h1c1 .5 1.5 1 2.5 2l325.46 329.47c5.5 5.5 9.5 13 9.5 21.5 0 2.5-.5 4.5-1 7v250.98zM732.61 303.47V96.99l232.48 235.47H761.6c-7.99 0-14.99-3.5-20.5-8.49-4.99-5-8.49-12.5-8.49-20.5z"
                                />
                            </svg>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            AJAX
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                </div>
                <!--End Card Body -->
            </div>
        </section>
        <!-- Contact Section -->
        <section class="md:-mt-32 -mt-20">
            <div
                class="container px-6 py-10 mx-auto shadow-lg md:mt-11 bg-[#141c3a] rounded-2xl w-4/5 pb-9"
            >
                <div
                    class="md:h-20 relative flex flex-col md:flex-row md:space-x-5 space-y-5 md:space-y-0 p-3 mx-auto"
                >
                    <div class="w-full md:w-1/3 grid place-items-center">
                        <p class="text-3xl font-semibold text-white">
                            Start a project
                        </p>
                    </div>
                    <div class="w-full md:w-1/3 grid place-items-center">
                        <p class="text-white">
                            Interested in working together? We should queue up a
                            chat. I’ll buy the coffee.
                        </p>
                    </div>
                    <div class="w-full md:w-1/3 grid place-items-center">
                        <div
                            class="md:space-x-20 space-y-10 md:space-y-0 mx-auto items-center"
                        >
                            <button
                                @click="sayHello"
                                class="py-3 px-6 text-white rounded-full border-2 border-[#7510F7] shadow-lg block md:inline-block hover:bg-[#7510F7]"
                            >
                                Let's do this
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Footer Section -->
        <footer class="bg-gray-200 h-24">
            <div class="bg-gray-200">
                <div
                    class="w-full mx-auto font-semibold text-gray-900 py-10 dark:bg-slate-800"
                >
                    <div class="text-center">
                        <!-- Footer logo -->
                        <div class="footer-logo w-24 mx-auto">
                            <img
                                v-bind:src="'/images/' + 'LOGO_T_256.png'"
                                alt="Logo of Takinur"
                                class="bg-cover"
                            />
                        </div>
                        <p
                            class="font-semibold mt-5 text-xl md:text-2xl dark:text-zinc-100"
                        >
                            Living, learning, & leveling up one day at a time.
                        </p>
                    </div>
                    <div
                        class="mt-24 md:justify-center items-center text-center text-sm text-gray-400"
                    >
                        <p class="mt-8 md:mt-0">
                            HandCrafted by Me &copy;{{
                                new Date().getFullYear()
                            }}
                        </p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Modal for Contact -->
        <div
            v-show="contactModal"
            @close="closeModal"
            class="min-w-screen h-screen transition-all animated fadeIn faster fixed left-0 top-0 flex justify-center items-center inset-0 z-50 outline-none focus:outline-none bg-no-repeat bg-center bg-cover"
            style="
                transition-duration: 500ms;
                background-image: url(https://images.unsplash.com/photo-1623600989906-6aae5aa131d4?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1582&q=80);
            "
            id="modal-id"
        >
            <div
                @click="closeModal"
                class="absolute bg-black opacity-80 inset-0 z-0"
            ></div>
            <div
                class="w-full max-w-2xl p-5 relative mx-auto my-auto rounded-xl shadow-lg bg-white"
            >
                <!--content-->
                <div class="">
                    <!--body-->
                    <div class="p-5 justify-center">
                        <h2 class="text-3xl font-bold py-2 text-center">
                            Thanks for taking the time to reach out. How can I
                            help you today?
                        </h2>
                        <div class="mt-8">
                            <div class="">
                                <jet-label for="name" value="Name" />
                                <jet-input
                                    id="name"
                                    type="text"
                                    class="mt-1 block w-full"
                                    v-model="form.name"
                                    required
                                    autofocus
                                    autocomplete="name"
                                />
                                <jet-input-error
                                    :message="form.errors.name"
                                    class="mt-2"
                                />
                            </div>

                            <div class="mt-4">
                                <jet-label for="email" value="Email" />
                                <jet-input
                                    id="email"
                                    type="email"
                                    class="mt-1 block w-full"
                                    v-model="form.email"
                                    required
                                />
                                <jet-input-error
                                    :message="form.errors.email"
                                    class="mt-2"
                                />
                            </div>
                            <div>
                                <div class="w-full flex flex-col mt-8">
                                    <label
                                        class="font-medium text-sm text-gray-700 leading-none"
                                        >Message</label
                                    >
                                    <textarea
                                        type="text"
                                        v-model="form.message"
                                        required
                                        class="h-40 text-base leading-none text-gray-900 p-3 focus:oultine-none focus:border-blue-700 mt-4 bg-gray-100 border rounded border-gray-200"
                                    ></textarea>
                                    <jet-input-error
                                        :message="form.errors.message"
                                        class="mt-2"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--footer-->
                    <div class="p-3 mt-2 text-center space-x-4 md:block">
                        <button
                            @click="closeModal"
                            class="mb-2 md:mb-0 bg-white px-5 py-2 text-sm shadow-sm font-medium tracking-wider border text-gray-600 rounded-full hover:shadow-lg hover:bg-gray-100"
                        >
                            Cancel
                        </button>
                        <button
                            @click="saveContact"
                            class="mb-2 md:mb-0 bg-white border border-[#7510F7] px-5 py-2 text-sm shadow-sm font-medium tracking-wider text-[#7510F7] rounded-full hover:shadow-lg hover:bg-[#7510F7] hover:text-white"
                        >
                            Submit
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end Main Wrapper -->
</template>

<style scoped>
.slide-fade-enter-active {
    transition: all 0.5s ease 0s;
    -webkit-transition: all 0.5s ease 0s;
}

.slide-fade-leave-active {
    transition: all 0.5s ease 0s;
    transform: translate3d(0px, 0px, 0px);
    -webkit-transition: all 0.5s ease 0s;
}

.slide-fade-enter-from,
.slide-fade-leave-to {
    transform: translate3d(-100%, 0px, 0px);
    opacity: 0;
}

/* Toggle DARK MODE */
#toggleDark:checked ~ .dot {
    transform: translateX(36px);
    background-color: #48bb78;
    transition: transform 0.3s linear;
}
</style>

<script>
import { defineComponent } from "vue";
import { Head } from "@inertiajs/inertia-vue3";
import JetInput from "@/Jetstream/Input.vue";
import JetInputError from "@/Jetstream/InputError.vue";
import JetLabel from "@/Jetstream/Label.vue";

export default defineComponent({
    components: {
        Head,
        JetInput,
        JetInputError,
        JetLabel,
    },

    props: {
        // canLogin: Boolean,
        // canRegister: Boolean,
        // isOpen: Boolean,
        errors: Object,
    },
    data() {
        return {
            showNav: false,
            isDark: false,
            isSucceed: false,

            contactModal: false,
            form: this.$inertia.form({
                name: "",
                email: "",
                message: "",
            }),
        };
    },
    mounted() {
        //Vanila JS

        // // Dark Mode Toggler
        const checkbox = document.querySelector("#toggleDark");
        const html = document.querySelector("html");
        const toggleDarkMode = function () {
            if (checkbox.checked) {
                html.classList.add("dark");
            } else {
                html.classList.remove("dark");
            }
        };
        //calling the function directly
        toggleDarkMode();
        checkbox.addEventListener("click", toggleDarkMode);
    },
    methods: {
        toggleNav: function () {
            this.showNav = !this.showNav;
        },
        isMobile() {
            if (
                /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
                    navigator.userAgent
                )
            ) {
                return true;
            } else {
                return false;
            }
        },
        sayHello() {
            this.contactModal = true;
            // setTimeout(() => this.$refs.email.focus(), 250);
        },
        saveContact() {
            this.form.post(route("saveContact"), {
                preserveScroll: true,
                onSuccess: () => this.closeModal(),
                // onError: () => this.$refs.email.focus(),
                // onFinish: () => this.form.reset(),
            });
        },
        closeModal() {
            this.contactModal = false;

            // this.form.reset();
        },
    },
});
</script>
