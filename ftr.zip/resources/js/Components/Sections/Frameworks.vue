<template>
   <section id="frameworks" class="pb-20 pt-6 bg-gray-100 dark:bg-gray-700">
            <div
                class="container px-6 py-10 mx-auto md:mt-11 bg-gray-100 rounded-2xl w-4/5 pb-9 dark:bg-gray-700"
            >
                <h1 class="text-dark text-3xl text-center dark:text-zinc-50">
                    FRAMEWORKS
                </h1>
                <h4 class="text-gray-600 text-center dark:text-zinc-200">
                    On the shoulders of giants
                </h4>
                <!-- CARD BODY-->
                <div
                    class="grid grid-cols-2 gap-8 mt-8 xl:mt-12 xl:gap-12 md:grid-cols-4 xl:grid-cols-6 content-center"
                >
                    <!--Card Item-->
                    <div
                        class="py-2 rounded-xl bg-white shadow-2xl dark:bg-gray-900"
                        data-aos="flip-left"
                        data-aos-once="false"
                        data-aos-delay="50"
                        data-aos-duration="2000"
                        Fdata-aos-easing="ease-in-out"
                    >
                        <div
                            class="bg-cover h-18 w-16 md:w-16 md:mt-3 mx-auto md:grayscale hover:grayscale-0 dark:grayscale-0"
                        >
                            <img
                                v-bind:src="'/images/icons/' + 'laravel.svg'"
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-5 md:mt-3 text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Laravel
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            PHP Framework
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div
                        class="py-2 rounded-xl bg-white shadow-2xl dark:bg-gray-900"
                        data-aos="flip-left"
                        data-aos-once="false"
                        data-aos-delay="50"
                        data-aos-duration="2000"
                        Fdata-aos-easing="ease-in-out"
                    >
                        <div
                            class="bg-cover h-18 w-28 mx-auto md:mt-3 md:grayscale hover:grayscale-0 dark:grayscale-0"
                        >
                            <img
                                v-bind:src="
                                    '/images/icons/' + 'tailwindcss.svg'
                                "
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Tailwind CSS
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            CSS Framework
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div
                        class="py-2 rounded-xl bg-white shadow-2xl dark:bg-gray-900"
                        data-aos="flip-left"
                        data-aos-once="false"
                        data-aos-delay="50"
                        data-aos-duration="2000"
                        Fdata-aos-easing="ease-in-out"
                    >
                        <div
                            class="bg-cover h-18 w-20 md:w-20 mx-auto md:mt-2 md:grayscale hover:grayscale-0 dark:grayscale-0"
                        >
                            <img
                                v-bind:src="
                                    '/images/icons/' + 'bootstrap-icon.svg'
                                "
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-3 text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Bootstrap
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            HTML, CSS library
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div
                        class="py-2 rounded-xl bg-white shadow-2xl dark:bg-gray-900"
                        data-aos="flip-left"
                        data-aos-once="false"
                        data-aos-delay="50"
                        data-aos-duration="2000"
                        Fdata-aos-easing="ease-in-out"
                    >
                        <div
                            class="bg-cover mt-2 h-18 w-20 md:w-16 mx-auto md:grayscale hover:grayscale-0 dark:grayscale-0"
                        >
                            <img
                                v-bind:src="'/images/icons/' + 'jquery.png'"
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-7 text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            JQuery
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            JavaScript library
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div
                        class="py-2 rounded-xl bg-white shadow-2xl dark:bg-gray-900"
                        data-aos="flip-left"
                        data-aos-once="false"
                        data-aos-delay="50"
                        data-aos-duration="2000"
                        Fdata-aos-easing="ease-in-out"
                    >
                        <div
                            class="bg-cover h-18 w-20 md:mt-4 mx-auto md:grayscale hover:grayscale-0 dark:grayscale-0"
                        >
                            <img
                                v-bind:src="'/images/icons/' + 'vue-js-1.svg'"
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-3 text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            VUE JS
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            JavaScript Framework
                        </p>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div
                        class="py-2 rounded-xl bg-white shadow-2xl dark:bg-gray-900"
                        data-aos="flip-left"
                        data-aos-once="false"
                        data-aos-delay="50"
                        data-aos-duration="2000"
                        Fdata-aos-easing="ease-in-out"
                    >
                        <div
                            class="bg-cover h-18 w-20 md:mt-4 mx-auto md:grayscale hover:grayscale-0 dark:grayscale-0"
                        >
                            <img
                                v-bind:src="'/images/icons/' + 'Nuxt.png'"
                                alt=""
                            />
                        </div>
                        <h1
                            class="mt-3 text-2xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Nuxt.JS
                        </h1>
                        <p
                            class="text-gray-500 dark:text-gray-300 text-center text-sm"
                        >
                            Vue Framework
                        </p>
                    </div>
                    <!-- END card ITEM -->

                </div>
                <!--End Card Body -->
            </div>
        </section>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
    props: [],

    methods: {},
});
</script>
