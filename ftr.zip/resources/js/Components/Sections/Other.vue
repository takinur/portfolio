<template>
    <section id="other" class="pb-28 bg-gray-100 dark:bg-gray-900">
            <div
                class="container px-6 py-10 mx-auto md:mt-1 md:w-4/5 pb-9 w-full"
            >
                <h1 class="text-dark text-3xl text-center dark:text-zinc-200">
                    LAST BUT NOT LEAST
                </h1>
                <h4 class="text-gray-600 text-center dark:text-zinc-300">
                    I'm familiar with…
                </h4>
                <!-- CARD BODY-->
                <div
                    class="grid grid-cols-3 gap-3 md:gap-8 mt-8 xl:mt-12 xl:gap-12 md:grid-cols-4 xl:grid-cols-6 content-center"
                >
                        <!--Card Item-->
                        <div class="py-2">
                            <div
                                class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                            >
                             <i class="fab fa-docker"></i>
                            </div>
                            <h1
                                class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                            >
                                Docker
                            </h1>
                        </div>
                        <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <svg
                                class="mx-auto text-zinc-300 fill-gray-600 dark:fill-white"
                                viewBox="0 0 100 100"
                            >
                                <g>
                                    <path
                                        class="st0"
                                        d="M102.79,7.11l2.59,3.41c0.68,0.9,0.51,2.19-0.39,2.87l-2.75,2.09c0.5,1.33,0.82,2.75,0.95,4.2l3.13,0.43 c1.12,0.15,1.9,1.19,1.75,2.31l-0.58,4.25c-0.15,1.12-1.19,1.91-2.31,1.75l-3.42-0.47c-0.61,1.33-1.39,2.55-2.31,3.64l1.92,2.52 c0.68,0.9,0.5,2.19-0.4,2.87l-3.41,2.59c-0.9,0.68-2.19,0.5-2.87-0.39l-2.09-2.75c-1.34,0.5-2.75,0.82-4.21,0.95l-0.43,3.13 c-0.15,1.12-1.19,1.9-2.31,1.75l-4.25-0.58c-1.12-0.15-1.9-1.19-1.75-2.31l0.47-3.42c-1.32-0.61-2.55-1.39-3.64-2.3l-2.52,1.91 c-0.9,0.68-2.19,0.51-2.87-0.39l-2.59-3.41c-0.68-0.9-0.51-2.19,0.39-2.87l2.75-2.09c-0.5-1.34-0.82-2.75-0.95-4.2l-3.13-0.43 c-1.12-0.15-1.91-1.19-1.75-2.31l0.58-4.25c0.16-1.12,1.19-1.9,2.31-1.75l3.42,0.47c0.61-1.32,1.39-2.55,2.3-3.64l-1.91-2.52 C71.83,7.28,72,5.99,72.9,5.31l3.41-2.59c0.9-0.68,2.19-0.51,2.87,0.39l2.09,2.75c1.33-0.5,2.75-0.82,4.2-0.95l0.43-3.13 c0.15-1.12,1.19-1.91,2.31-1.76l4.25,0.58c1.12,0.15,1.91,1.19,1.75,2.31l-0.47,3.42c1.33,0.61,2.55,1.39,3.65,2.31l2.52-1.91 C100.81,6.04,102.1,6.21,102.79,7.11L102.79,7.11L102.79,7.11z M29.67,67.12v-16.5h8.5c1.58,0,2.78,0.13,3.61,0.41 c0.83,0.27,1.51,0.77,2.01,1.5c0.51,0.74,0.77,1.63,0.77,2.68c0,0.91-0.2,1.71-0.59,2.37c-0.39,0.67-0.93,1.21-1.61,1.62 c-0.43,0.26-1.03,0.48-1.79,0.65c0.61,0.21,1.05,0.4,1.32,0.61c0.19,0.14,0.46,0.43,0.81,0.87c0.35,0.44,0.59,0.79,0.71,1.03 l2.48,4.77h-5.76l-2.72-5.03c-0.35-0.65-0.65-1.08-0.92-1.27c-0.37-0.25-0.79-0.38-1.25-0.38h-0.45v6.68H29.67L29.67,67.12z M47.65,95.85h-9.52l-1.37,4.48h-8.58l10.23-27.19h9.2l10.19,27.19h-8.8L47.65,95.85L47.65,95.85z M45.87,89.96l-2.97-9.78 l-2.98,9.78H45.87L45.87,89.96z M59.78,73.14h13.98c3.05,0,5.33,0.72,6.84,2.17c1.51,1.45,2.27,3.52,2.27,6.19 c0,2.75-0.83,4.9-2.48,6.45c-1.65,1.55-4.18,2.32-7.57,2.32h-4.61v10.06h-8.43V73.14L59.78,73.14z M68.21,84.76h2.07 c1.63,0,2.78-0.28,3.44-0.85c0.66-0.56,0.99-1.29,0.99-2.16c0-0.85-0.29-1.58-0.86-2.17c-0.57-0.59-1.65-0.89-3.23-0.89h-2.41 V84.76L68.21,84.76z M86.27,73.14h8.43v27.19h-8.43V73.14L86.27,73.14z M34.79,57.32h2.15c0.23,0,0.68-0.08,1.35-0.23 c0.34-0.07,0.62-0.24,0.83-0.52c0.22-0.28,0.32-0.6,0.32-0.96c0-0.53-0.17-0.95-0.51-1.23c-0.34-0.29-0.97-0.43-1.9-0.43h-2.24 V57.32L34.79,57.32z M46.87,50.62h13.65v3.52h-8.53v2.63h7.91v3.36h-7.91v3.25h8.78v3.73h-13.9V50.62L46.87,50.62z M61.98,61.66 l4.84-0.3c0.1,0.79,0.32,1.38,0.64,1.79c0.53,0.66,1.28,1,2.25,1c0.72,0,1.29-0.17,1.68-0.51c0.39-0.34,0.59-0.74,0.59-1.19 c0-0.43-0.19-0.81-0.56-1.15c-0.37-0.34-1.24-0.65-2.61-0.96c-2.23-0.5-3.82-1.17-4.78-2c-0.96-0.83-1.44-1.89-1.44-3.18 c0-0.85,0.25-1.65,0.74-2.4c0.49-0.75,1.23-1.35,2.22-1.78c0.99-0.43,2.34-0.64,4.06-0.64c2.11,0,3.71,0.39,4.82,1.18 c1.1,0.79,1.76,2.03,1.97,3.75l-4.79,0.29c-0.13-0.75-0.4-1.3-0.8-1.63c-0.41-0.34-0.98-0.51-1.69-0.51 c-0.59,0-1.04,0.13-1.34,0.38c-0.3,0.25-0.45,0.56-0.45,0.92c0,0.26,0.13,0.49,0.37,0.71c0.24,0.21,0.8,0.42,1.7,0.61 c2.23,0.48,3.83,0.97,4.79,1.46c0.96,0.49,1.67,1.1,2.1,1.83c0.44,0.72,0.66,1.54,0.66,2.44c0,1.06-0.29,2.03-0.88,2.92 c-0.58,0.89-1.4,1.57-2.45,2.03c-1.05,0.46-2.37,0.69-3.97,0.69c-2.8,0-4.75-0.54-5.83-1.62C62.74,64.69,62.13,63.32,61.98,61.66 L61.98,61.66z M77.69,50.62h15.51v4.08H88v12.42H82.9V54.7h-5.21V50.62L77.69,50.62z M60.53,11.46c-1.83-0.14-3.68-0.12-5.51,0.06 c-5.63,0.54-11.1,2.59-15.62,6.1c-5.23,4.05-9.2,10.11-10.73,18.14l-0.48,2.51l-2.5,0.44c-2.45,0.43-4.64,1.02-6.56,1.77 c-1.86,0.72-3.52,1.61-4.97,2.66c-1.16,0.84-2.16,1.78-3.01,2.8c-2.63,3.15-3.85,7.1-3.82,11.1c0.03,4.06,1.35,8.16,3.79,11.53 c0.91,1.25,1.96,2.4,3.16,3.4c1.22,1.01,2.59,1.85,4.13,2.48c0.87,0.36,1.8,0.66,2.77,0.9v7.49c-2-0.36-3.84-0.9-5.56-1.61 c-2.27-0.94-4.28-2.15-6.05-3.63c-1.68-1.4-3.15-2.99-4.4-4.72C1.84,68.28,0.04,62.66,0,57.06c-0.04-5.66,1.72-11.29,5.52-15.85 c1.23-1.48,2.68-2.84,4.34-4.04c1.93-1.4,4.14-2.58,6.64-3.55c1.72-0.67,3.56-1.23,5.5-1.68c2.2-8.74,6.89-15.47,12.92-20.14 c5.64-4.37,12.43-6.92,19.42-7.59c3.67-0.35,7.39-0.19,11.03,0.49c-0.08,0.33-0.15,0.66-0.19,1l-0.01,0.06 c-0.07,0.57-0.1,1.14-0.07,1.72c-0.77,0.3-1.49,0.71-2.14,1.21l-0.03,0.02C61.96,9.44,61.14,10.38,60.53,11.46L60.53,11.46z M113.44,30.66c0.56,0.51,1.1,1.04,1.63,1.61c1.07,1.15,2.08,2.45,3.03,3.9c3.2,4.92,4.84,11.49,4.77,17.92 c-0.07,6.31-1.77,12.59-5.25,17.21c-2.27,3.01-5.18,5.47-8.67,7.42c-2.39,1.34-5.08,2.45-8.01,3.35v-7.75 c1.58-0.59,3.05-1.25,4.4-2c2.63-1.47,4.78-3.26,6.39-5.41c2.5-3.33,3.73-8.04,3.78-12.87c0.06-5.07-1.18-10.16-3.59-13.86 c-0.69-1.07-1.45-2.03-2.25-2.89c-0.31-0.33-0.62-0.64-0.94-0.94c0.05-0.5,0.07-1.01,0.04-1.52c0.77-0.3,1.49-0.71,2.14-1.21 l0.03-0.02C111.97,32.81,112.83,31.81,113.44,30.66L113.44,30.66z M88.08,12.8c4.61,0.63,7.83,4.88,7.2,9.49 c-0.63,4.61-4.88,7.84-9.49,7.21c-4.61-0.63-7.84-4.88-7.2-9.49C79.23,15.4,83.47,12.17,88.08,12.8L88.08,12.8L88.08,12.8z"
                                    />
                                </g>
                            </svg>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            REST API
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fas fa-database"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            SQL
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fas fa-table"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            CRUD
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-python"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Python
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-linux"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Linux
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-github"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Github
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-font-awesome-alt"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Font Awesome
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fas fa-server"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Server
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-gofore"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            GoDaddy
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-wordpress"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            WordPress
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-css3-alt"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            CSS
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-node-js"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            JavaScript
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-sass"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            SCSS
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-less"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Less
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-cpanel"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Cpanel
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fas fa-file-code"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            XML
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fas fa-sync"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            SDLC
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-npm"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            NPM
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fas fa-terminal"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            BASH Terminal
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-vuejs"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            VUE
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <i class="fab fa-gitlab"></i>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Gitlab
                        </h1>
                    </div>
                    <!-- END card ITEM -->

                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 grayscale text-5xl h-18 w-12 mx-auto dark:text-zinc-50"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 1333.34 1300.01"
                                shape-rendering="geometricPrecision"
                                text-rendering="geometricPrecision"
                                image-rendering="optimizeQuality"
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                            >
                                <g fill-rule="nonzero">
                                    <path
                                        fill="#0c0824"
                                        d="M55.55 55.55h1222.23v1188.9H55.55z"
                                    />
                                    <path
                                        d="M55.55 55.55h1222.23v1188.9H55.55V55.55zM0 1300.01h1333.34V0H0v1300.01zm898.89-766.68c-43.89 0-58.89 22.22-58.89 40.56 0 20 10 33.89 68.89 64.45 87.22 42.22 114.45 82.78 114.45 142.22 0 88.89-67.78 136.67-159.45 136.67-48.33 0-90-10-113.89-23.89-3.89-1.67-4.44-4.44-4.44-8.89v-81.67c0-5.56 2.78-7.22 6.67-4.44 35 22.78 75 32.78 111.67 32.78 43.89 0 62.22-18.33 62.22-43.33 0-20-12.78-37.78-68.89-66.67-78.89-37.78-111.67-76.11-111.67-140 0-71.67 56.11-131.11 153.34-131.11 47.78 0 81.11 7.22 99.44 15.56 4.44 2.78 5.56 7.22 5.56 11.11v76.11c0 4.44-2.78 7.22-8.33 5.55-24.44-15.55-60.55-25-96.66-25zm-477.78 66.11c12.78 1.11 22.78 1.11 45 1.11 65 0 126.11-22.78 126.11-111.11 0-70.56-43.89-106.11-117.78-106.11-22.22 0-43.33 1.11-53.33 1.67v214.45zm-98.89-295c0-3.89 7.78-6.67 12.22-6.67 35.56-1.67 88.33-2.78 143.33-2.78 153.89 0 213.89 84.45 213.89 192.22 0 141.11-102.22 201.67-227.78 201.67-21.11 0-28.33-1.11-43.33-1.11v213.34c0 4.44-1.67 6.67-6.67 6.67h-85c-4.44 0-6.67-1.67-6.67-6.67V304.44z"
                                        fill="#31c5f0"
                                    />
                                </g>
                            </svg>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            Photoshop
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                    <!--Card Item-->
                    <div class="py-2">
                        <div
                            class="text-gray-600 grayscale text-5xl h-18 w-12 mx-auto dark:fill-zinc-50"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 1321.45 1333.33"
                                shape-rendering="geometricPrecision"
                                text-rendering="geometricPrecision"
                                image-rendering="optimizeQuality"
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                            >
                                <path
                                    d="M221.37 618.44h757.94V405.15H755.14c-23.5 0-56.32-12.74-71.82-28.24-15.5-15.5-25-43.47-25-66.97V82.89H88.39c-1.99 0-3.49 1-4.49 2-1.5 1-2 2.5-2 4.5v1155.04c0 1.5 1 3.5 2 4.5 1 1.49 3 1.99 4.49 1.99H972.8c2 0 1.89-.99 2.89-1.99 1.5-1 3.61-3 3.61-4.5v-121.09H221.36c-44.96 0-82-36.9-82-81.99V700.44c0-45.1 36.9-82 82-82zm126.51 117.47h75.24v146.61c0 30.79-2.44 54.23-7.33 70.31-4.92 16.03-14.8 29.67-29.65 40.85-14.86 11.12-33.91 16.72-57.05 16.72-24.53 0-43.51-3.71-56.94-11.06-13.5-7.36-23.89-18.1-31.23-32.3-7.35-14.14-11.69-31.67-12.99-52.53l71.5-10.81c.11 11.81 1.07 20.61 2.81 26.33 1.76 5.78 4.75 10.37 9 13.95 2.87 2.33 6.94 3.46 12.25 3.46 8.4 0 14.58-3.46 18.53-10.37 3.9-6.92 5.87-18.6 5.87-35V735.92zm112.77 180.67l71.17-4.97c1.54 12.81 4.69 22.62 9.44 29.28 7.74 10.88 18.74 16.34 33.09 16.34 10.68 0 18.93-2.76 24.68-8.36 5.81-5.58 8.7-12.07 8.7-19.41 0-6.97-2.71-13.26-8.2-18.79-5.47-5.53-18.23-10.68-38.28-15.65-32.89-8.17-56.27-19.1-70.26-32.74-14.12-13.57-21.18-30.92-21.18-52.03 0-13.83 3.61-26.89 10.85-39.21 7.22-12.38 18.07-22.06 32.59-29.09 14.52-7.04 34.4-10.56 59.65-10.56 31 0 54.62 6.41 70.88 19.29 16.28 12.81 25.92 33.24 29.04 61.27l-70.5 4.65c-1.87-12.25-5.81-21.17-11.81-26.7-6.05-5.6-14.35-8.36-24.9-8.36-8.71 0-15.31 2.07-19.73 6.16-4.4 4.09-6.59 9.12-6.59 15.02 0 4.27 1.81 8.11 5.37 11.57 3.45 3.59 11.8 6.85 25.02 9.93 32.75 7.86 56.2 15.84 70.31 23.87 14.18 8.05 24.52 17.98 30.96 29.92 6.44 11.88 9.66 25.2 9.66 39.96 0 17.29-4.3 33.24-12.88 47.89-8.63 14.58-20.61 25.7-36.08 33.24-15.41 7.54-34.85 11.31-58.33 11.31-41.24 0-69.81-8.86-85.68-26.52-15.88-17.65-24.85-40.09-26.96-67.3zm248.74-45.5c0-44.05 11.02-78.36 33.09-102.87 22.09-24.57 52.82-36.82 92.24-36.82 40.38 0 71.5 12.07 93.34 36.13 21.86 24.13 32.77 57.94 32.77 101.37 0 31.54-4.75 57.36-14.3 77.54-9.54 20.18-23.37 35.89-41.4 47.13-18.07 11.24-40.55 16.84-67.48 16.84-27.33 0-49.99-4.83-67.94-14.52-17.92-9.74-32.49-25.07-43.62-46.06-11.13-20.92-16.72-47.19-16.72-78.74zm74.89.19c0 27.21 4.57 46.81 13.68 58.68 9.13 11.88 21.57 17.85 37.26 17.85 16.1 0 28.65-5.84 37.45-17.47 8.87-11.68 13.28-32.54 13.28-62.77 0-25.39-4.63-43.92-13.84-55.61-9.26-11.76-21.75-17.6-37.56-17.6-15.13 0-27.34 5.97-36.49 17.85-9.21 11.88-13.78 31.61-13.78 59.07zm209.08-135.36h69.99l90.98 149.05V735.91h70.83v269.96h-70.83l-90.48-148.24v148.24h-70.49V735.91zm67.71-117.47h178.37c45.1 0 82 37.04 82 82v340.91c0 44.96-37.03 81.99-82 81.99h-178.37v147c0 17.5-6.99 32.99-18.5 44.5-11.5 11.49-27 18.5-44.5 18.5H62.97c-17.5 0-32.99-7-44.5-18.5-11.49-11.5-18.5-27-18.5-44.5V63.49c0-17.5 7-33 18.5-44.5S45.97.49 62.97.49H700.1c1.5-.5 3-.5 4.5-.5 7 0 14 3 19 7.49h1c1 .5 1.5 1 2.5 2l325.46 329.47c5.5 5.5 9.5 13 9.5 21.5 0 2.5-.5 4.5-1 7v250.98zM732.61 303.47V96.99l232.48 235.47H761.6c-7.99 0-14.99-3.5-20.5-8.49-4.99-5-8.49-12.5-8.49-20.5z"
                                />
                            </svg>
                        </div>
                        <h1
                            class="mt-3 md:mt-3 text-xl text-center font-semibold text-gray-900 capitalize dark:text-white"
                        >
                            AJAX
                        </h1>
                    </div>
                    <!-- END card ITEM -->
                </div>
                <!--End Card Body -->
            </div>
        </section>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
    props: [],

    methods: {},
});
</script>
